import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { LineChart, Line, Area, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import { ArrowLeft, Download, Info, Copy } from 'lucide-react';
// Browser-native screenshot functionality



export default function ROIAnalysisScreen({ onBack, formData }: { onBack: () => void; formData?: any }) {
  // ROI kalkulacija state
  const [electricityPrice, setElectricityPrice] = useState(15.8); // RSD/kWh
  const [eurRate, setEurRate] = useState(117.0); // RSD/EUR
  const [degradationAfter30, setDegradationAfter30] = useState(
    formData?.degradacijaNakon30 ? parseFloat(formData.degradacijaNakon30) : 20
  ); // % degradacije nakon 30 godina
  
  // Get system cost from formData, with fallback
  const getSystemCostEUR = () => {
    if (formData?.cenaSaSubvencijom && parseFloat(formData.cenaSaSubvencijom) > 0) {
      return parseFloat(formData.cenaSaSubvencijom);
    } else if (formData?.cenaSaPDV && parseFloat(formData.cenaSaPDV) > 0) {
      return parseFloat(formData.cenaSaPDV);
    } else if (formData?.cenaBezPDV && parseFloat(formData.cenaBezPDV) > 0) {
      return parseFloat(formData.cenaBezPDV);
    }
    return 24900; // fallback value
  };
  
  const [systemCostEUR] = useState(getSystemCostEUR()); // readonly iz postojećeg polja
  const systemCostRSD = systemCostEUR * eurRate;


  const analysisRef = useRef<HTMLDivElement>(null);

  // Mesečna proizvodnja data (predefinisano iz postojećeg programa)
  const monthlyProduction = [2850, 3420, 4680, 5820, 6750, 7200, 7350, 6890, 5420, 3950, 2810, 2200];
  const totalAnnualProduction = monthlyProduction.reduce((sum, prod) => sum + prod, 0); // 58,350 kWh

  // ROI kalkulacija
  const calculateROI = () => {
    const data = [];
    let cumulativeCashFlow = -systemCostRSD; // Početna investicija
    let breakEvenMonth = 0;
    
    for (let month = 1; month <= 360; month++) { // 30 godina
      const year = Math.ceil(month / 12);
      const monthIndex = (month - 1) % 12;
      
      // Degradacija: 100% prva godina, zatim linearno do (100 - degradationAfter30)% u 30. godini
      const maxDegradation = degradationAfter30 / 100; // Convert to decimal
      const degradationFactor = year === 1 ? 1.0 : 1.0 - (maxDegradation * (year - 1) / 29);
      
      // Mesečna proizvodnja sa degradacijom
      const monthlyProductionWithDegradation = monthlyProduction[monthIndex] * degradationFactor;
      
      // Mesečna ušteda
      const monthlySavings = monthlyProductionWithDegradation * electricityPrice;
      
      cumulativeCashFlow += monthlySavings;
      
      // Pronađi break-even tačku
      if (breakEvenMonth === 0 && cumulativeCashFlow >= 0) {
        breakEvenMonth = month;
      }
      
      data.push({
        month,
        year: Math.ceil(month / 12),
        monthName: `Godina ${Math.ceil(month / 12)}, Mesec ${((month - 1) % 12) + 1}`,
        cumulativeCashFlow: Math.round(cumulativeCashFlow),
        monthlySavings: Math.round(monthlySavings)
      });
    }
    
    return { data, breakEvenMonth };
  };

  const { data: roiData, breakEvenMonth } = calculateROI();
  
  // Rezime kalkulacija
  const breakEvenYears = Math.floor(breakEvenMonth / 12);
  const breakEvenMonths = breakEvenMonth % 12;
  const totalSavings30Years = roiData[359]?.cumulativeCashFlow || 0;
  const totalProduction30Years = totalAnnualProduction * 30 * 0.913; // Sa degradacijom



  const copyTooltipText = "Degradacija: Linearna degradacija panela sa 100% performansi u prvoj godini do 87.4% u 30. godini. Formula: 1.0 - (0.126 * (godina - 1) / 29)";

  // Export funkcija
  const exportToPNG = async () => {
    try {
      // Koristimo window.print sa CSS optimizacijom za PNG
      const printWindow = window.open('', '_blank');
      if (printWindow && analysisRef.current) {
        printWindow.document.write(`
          <html>
            <head>
              <title>ROI Analiza - ${new Date().toLocaleDateString('sr-RS')}</title>
              <style>
                body { 
                  margin: 0; 
                  padding: 20px; 
                  font-family: Inter, sans-serif; 
                  background: white;
                  width: 800px;
                }
                * { box-sizing: border-box; }
              </style>
            </head>
            <body>
              ${analysisRef.current.outerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 1000);
      }
    } catch (error) {
      console.error('Greška pri eksportovanju:', error);
      // Fallback: kopiranje sadržaja u clipboard
      if (analysisRef.current) {
        const range = document.createRange();
        range.selectNode(analysisRef.current);
        const selection = window.getSelection();
        if (selection) {
          selection.removeAllRanges();
          selection.addRange(range);
          document.execCommand('copy');
          selection.removeAllRanges();
          alert('Sadržaj kopiran u clipboard! Možete ga nalepiti u bilo koji editor slike.');
        }
      }
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50 print:hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <div className="h-8 w-32 bg-gradient-to-r from-purple-600 to-purple-800 rounded flex items-center justify-center text-white font-bold text-sm">
                LuminOne
              </div>
              <Button
                variant="ghost"
                onClick={onBack}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="h-4 w-4" />
                Nazad na ponudu
              </Button>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={exportToPNG}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white rounded-md"
              >
                <Download className="h-4 w-4" />
                Izvezi PNG
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-5xl mx-auto">
          {/* ROI Analysis Section */}
          <div className="space-y-8" ref={analysisRef}>
            {/* Header traka */}
            <div className="text-center space-y-2">
              <h1 className="text-purple-700 mb-2">ROI – Povrat investicije</h1>
              <p className="text-gray-600">Kumulativna ušteda po mesecima u narednih 30 godina</p>
              <Badge className="bg-purple-100 text-purple-800 border-purple-300">
                Degradacija panela do {(100 - degradationAfter30)}% u 30 god. (linearno)
              </Badge>
            </div>

            {/* Ulazi karta */}
            <Card className="border-purple-200 shadow-lg" style={{ borderRadius: '16px' }}>
              <CardHeader>
                <CardTitle className="text-purple-700">Ulazi</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="electricityPrice">Cena struje (RSD/kWh)</Label>
                    <Input
                      id="electricityPrice"
                      type="number"
                      step="0.1"
                      value={electricityPrice}
                      onChange={(e) => setElectricityPrice(parseFloat(e.target.value) || 0)}
                      className="bg-input-background"
                    />
                  </div>
                  <div>
                    <Label htmlFor="eurRate">Srednji kurs (RSD/EUR)</Label>
                    <Input
                      id="eurRate"
                      type="number"
                      step="0.1"
                      value={eurRate}
                      onChange={(e) => setEurRate(parseFloat(e.target.value) || 0)}
                      className="bg-input-background"
                    />
                  </div>
                  <div>
                    <Label htmlFor="eurPrice">Cena sistema (EUR)</Label>
                    <Input
                      id="eurPrice"
                      type="number"
                      value={systemCostEUR}
                      readOnly
                      className="bg-gray-100 text-gray-600"
                    />
                  </div>
                  <div>
                    <Label htmlFor="rsdPrice">Cena sistema (RSD)</Label>
                    <Input
                      id="rsdPrice"
                      type="number"
                      value={Math.round(systemCostRSD)}
                      readOnly
                      className="bg-gray-100 text-gray-600"
                    />
                  </div>
                  <div>
                    <Label htmlFor="degradationAfter30">Degradacija nakon 30g (%)</Label>
                    <Input
                      id="degradationAfter30"
                      type="number"
                      step="0.1"
                      value={degradationAfter30}
                      onChange={(e) => setDegradationAfter30(parseFloat(e.target.value) || 20)}
                      className="bg-input-background"
                    />
                  </div>
                  <div className="col-span-2">
                    <div className="p-3 bg-teal-50 rounded-lg border border-teal-200">
                      <Badge className="bg-teal-100 text-teal-800 mb-2">povučeno iz postojećeg programa</Badge>
                      <p className="text-sm text-gray-700">
                        Prosečna mesečna proizvodnja (kWh, Jan–Dec): {monthlyProduction.join(', ')}
                      </p>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200 flex items-center gap-2">
                  <Info className="h-4 w-4 text-blue-600" />
                  <span className="text-sm text-blue-800">
                    Degradacija: 100% → {(100 - degradationAfter30)}% za 30 godina
                  </span>
                  <TooltipProvider>
                    <Tooltip>
                      <TooltipTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 text-blue-600 hover:text-blue-800"
                        >
                          <Copy className="h-3 w-3" />
                        </Button>
                      </TooltipTrigger>
                      <TooltipContent className="max-w-xs">
                        <p className="text-xs">{copyTooltipText}</p>
                      </TooltipContent>
                    </Tooltip>
                  </TooltipProvider>
                  <span className="text-xs text-blue-600 ml-auto">linearno, primenjuje se po godini</span>
                </div>
              </CardContent>
            </Card>

            {/* Moderne ROI Dashboard */}
            <div className="relative">
              {/* Pozadinski gradijent */}
              <div className="absolute inset-0 bg-gradient-to-br from-purple-50 via-white to-teal-50 rounded-3xl"></div>
              
              {/* Glavni sadržaj */}
              <div className="relative bg-white/80 backdrop-blur-sm border border-purple-200/50 shadow-2xl rounded-3xl overflow-hidden">
                {/* Header sa animiranim gradijentom */}
                <div className="bg-gradient-to-r from-purple-600 via-purple-700 to-teal-600 p-6 text-white relative overflow-hidden">
                  <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-teal-600/20 animate-pulse"></div>
                  <div className="relative z-10">
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="text-2xl font-bold mb-2">ROI Analiza Sistema</h3>
                        <p className="text-purple-100">Detaljaan pregled profitabilnosti kroz 30 godina</p>
                      </div>
                      <div className="text-right">
                        <div className="bg-white/20 backdrop-blur rounded-2xl p-3 border border-white/30">
                          <div className="text-3xl font-bold text-teal-200">
                            {Math.ceil(breakEvenMonth / 12)}
                          </div>
                          <div className="text-sm text-purple-200">godina povrata</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  {/* KPI Kartice */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                    <div className="bg-gradient-to-br from-purple-500 to-purple-600 text-white p-4 rounded-2xl shadow-lg transform hover:scale-105 transition-transform">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-purple-200 text-sm">Ukupna ušteda</div>
                          <div className="text-2xl font-bold">
                            {(totalSavings30Years / 1000000).toFixed(1)}M RSD
                          </div>
                        </div>
                        <div className="text-purple-200 text-3xl">💰</div>
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-br from-teal-500 to-teal-600 text-white p-4 rounded-2xl shadow-lg transform hover:scale-105 transition-transform">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-teal-200 text-sm">Godišnja proizvodnja</div>
                          <div className="text-2xl font-bold">
                            {(totalAnnualProduction / 1000).toFixed(0)}k kWh
                          </div>
                        </div>
                        <div className="text-teal-200 text-3xl">⚡</div>
                      </div>
                    </div>
                    
                    <div className="bg-gradient-to-br from-green-500 to-green-600 text-white p-4 rounded-2xl shadow-lg transform hover:scale-105 transition-transform">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-green-200 text-sm">30-god degradacija</div>
                          <div className="text-2xl font-bold">{degradationAfter30}%</div>
                        </div>
                        <div className="text-green-200 text-3xl">📉</div>
                      </div>
                    </div>
                  </div>

                  {/* Glavni grafikon sa naprednim styling-om */}
                  <div className="bg-gradient-to-br from-gray-50 to-purple-50/30 p-6 rounded-2xl border border-purple-100">
                    <div className="mb-6">
                      <h4 className="text-2xl font-bold bg-gradient-to-r from-purple-700 to-teal-600 bg-clip-text text-transparent mb-2">
                        Kumulativni Povrat Investicije
                      </h4>
                      <p className="text-gray-600">Praćenje profitabilnosti kroz vreme sa tačkom break-even-a</p>
                    </div>
                    
                    <div className="h-[500px] relative bg-white rounded-xl shadow-inner border border-gray-100 p-4">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart 
                          data={roiData} 
                          margin={{ top: 30, right: 50, left: 80, bottom: 80 }}
                        >
                          <defs>
                            <linearGradient id="roiAreaGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="0%" stopColor="#7C3AED" stopOpacity={0.4}/>
                              <stop offset="50%" stopColor="#8B5CF6" stopOpacity={0.2}/>
                              <stop offset="100%" stopColor="#1CD4D4" stopOpacity={0.1}/>
                            </linearGradient>
                            <linearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
                              <stop offset="0%" stopColor="#7C3AED"/>
                              <stop offset="50%" stopColor="#8B5CF6"/>
                              <stop offset="100%" stopColor="#1CD4D4"/>
                            </linearGradient>
                            <filter id="dropShadow">
                              <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#7C3AED" floodOpacity="0.3"/>
                            </filter>
                          </defs>
                          
                          <CartesianGrid 
                            strokeDasharray="3 3" 
                            stroke="#e2e8f0" 
                            horizontal={true}
                            vertical={true}
                            opacity={0.6}
                          />
                          
                          <XAxis 
                            dataKey="month" 
                            type="number"
                            scale="linear"
                            domain={[1, 360]}
                            tickFormatter={(value) => `${Math.ceil(value / 12)}g`}
                            stroke="#64748b"
                            fontSize={12}
                            fontWeight={500}
                            axisLine={{ stroke: '#94a3b8', strokeWidth: 1 }}
                            tickLine={{ stroke: '#94a3b8', strokeWidth: 1 }}
                            label={{ 
                              value: 'Godine rada sistema', 
                              position: 'insideBottom', 
                              offset: -10,
                              style: { textAnchor: 'middle', fontSize: '14px', fontWeight: '600', fill: '#475569' }
                            }}
                          />
                          
                          <YAxis 
                            tickFormatter={(value) => {
                              if (Math.abs(value) >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
                              if (Math.abs(value) >= 1000) return `${(value / 1000).toFixed(0)}k`;
                              return value.toLocaleString('sr-RS');
                            }}
                            stroke="#64748b"
                            fontSize={12}
                            fontWeight={500}
                            axisLine={{ stroke: '#94a3b8', strokeWidth: 1 }}
                            tickLine={{ stroke: '#94a3b8', strokeWidth: 1 }}
                            label={{ 
                              value: 'Povrat investicije (RSD)', 
                              angle: -90, 
                              position: 'insideLeft',
                              style: { textAnchor: 'middle', fontSize: '14px', fontWeight: '600', fill: '#475569' }
                            }}
                          />
                          
                          <RechartsTooltip 
                            formatter={(value: any, name: string) => [
                              `${parseInt(value).toLocaleString('sr-RS')} RSD`,
                              'Kumulativna ušteda'
                            ]}
                            labelFormatter={(month: any) => {
                              const years = Math.ceil(month / 12);
                              const monthsRem = month % 12 || 12;
                              const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Avg', 'Sep', 'Okt', 'Nov', 'Dec'];
                              return `${years}. godina, ${monthNames[monthsRem - 1]}`;
                            }}
                            contentStyle={{
                              backgroundColor: 'rgba(255, 255, 255, 0.98)',
                              border: '2px solid #7C3AED',
                              borderRadius: '12px',
                              boxShadow: '0 10px 25px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
                              padding: '12px 16px',
                              backdropFilter: 'blur(8px)',
                              fontSize: '14px'
                            }}
                            labelStyle={{ 
                              color: '#374151', 
                              fontWeight: 600,
                              marginBottom: '8px',
                              fontSize: '14px'
                            }}
                            cursor={{
                              stroke: '#7C3AED',
                              strokeWidth: 2,
                              strokeDasharray: '5 5',
                              strokeOpacity: 0.7
                            }}
                          />
                          
                          {/* Zero linija */}
                          <ReferenceLine 
                            y={0} 
                            stroke="#ef4444" 
                            strokeDasharray="6 4" 
                            strokeWidth={2}
                            strokeOpacity={0.8}
                          />
                          
                          {/* Area fill */}
                          <Area
                            type="monotone"
                            dataKey="cumulativeCashFlow"
                            stroke="none"
                            fill="url(#roiAreaGradient)"
                            fillOpacity={1}
                          />
                          
                          {/* Glavna linija */}
                          <Line 
                            type="monotone" 
                            dataKey="cumulativeCashFlow" 
                            stroke="url(#lineGradient)"
                            strokeWidth={3}
                            dot={false}
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            filter="url(#dropShadow)"
                            activeDot={{ 
                              r: 6, 
                              fill: '#1CD4D4', 
                              strokeWidth: 3, 
                              stroke: '#ffffff',
                              shadow: '0 0 10px rgba(28, 212, 212, 0.5)'
                            }}
                          />
                          
                          {/* Break-even linija */}
                          {breakEvenMonth > 0 && (
                            <ReferenceLine 
                              x={breakEvenMonth} 
                              stroke="#1CD4D4" 
                              strokeDasharray="8 4"
                              strokeWidth={3}
                              strokeOpacity={0.9}
                              label={{
                                value: "POVRAT INVESTICIJE",
                                position: "topLeft",
                                offset: 10,
                                style: { 
                                  fontSize: '12px', 
                                  fontWeight: 'bold', 
                                  fill: '#1CD4D4',
                                  textShadow: '0 1px 2px rgba(0,0,0,0.1)' 
                                }
                              }}
                            />
                          )}
                        </LineChart>
                      </ResponsiveContainer>
                      
                      {/* Break-even floating indicator */}
                      {breakEvenMonth > 0 && (
                        <div 
                          className="absolute top-6 bg-gradient-to-r from-teal-500 to-teal-600 text-white px-3 py-2 rounded-lg shadow-lg animate-bounce"
                          style={{ 
                            left: `${Math.min(85, (breakEvenMonth / 360) * 100 + 15)}%`,
                            transform: 'translateX(-50%)'
                          }}
                        >
                          <div className="text-xs font-bold text-center">
                            🎯 {Math.ceil(breakEvenMonth / 12)}. godina
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Elegantna legenda */}
                    <div className="mt-6 bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-purple-100">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-3 bg-gradient-to-r from-purple-600 to-teal-500 rounded-full shadow-sm"></div>
                          <span className="font-medium text-gray-700">Kumulativna ušteda</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-0.5 bg-teal-500 rounded-full relative">
                            <div className="absolute inset-0 bg-teal-500 rounded-full animate-pulse opacity-50"></div>
                          </div>
                          <span className="font-medium text-gray-700">Break-even tačka</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-6 h-0.5 bg-red-500 rounded-full border-dashed border border-red-300"></div>
                          <span className="font-medium text-gray-700">Nulta linija</span>
                        </div>
                      </div>
                    </div>

                    {/* Info kartice */}
                    <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-xl border border-purple-200">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-lg">📊</span>
                          <h5 className="font-bold text-purple-800">Metodologija</h5>
                        </div>
                        <p className="text-sm text-purple-700">
                          Grafikon koristi mesečne podatke sa linearnom degradacijom od {degradationAfter30}% kroz 30 godina za preciznu analizu
                        </p>
                      </div>
                      
                      <div className="bg-gradient-to-br from-teal-50 to-teal-100 p-4 rounded-xl border border-teal-200">
                        <div className="flex items-center gap-2 mb-2">
                          <span className="text-lg">💡</span>
                          <h5 className="font-bold text-teal-800">Čitanje grafikona</h5>
                        </div>
                        <p className="text-sm text-teal-700">
                          <strong>Y-osa:</strong> Povrat u RSD (M = milioni) • <strong>X-osa:</strong> Meseci/Godine (1-30g)
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Rezime karta */}
            <Card className="border-purple-200 shadow-lg" style={{ borderRadius: '16px' }}>
              <CardHeader>
                <CardTitle className="text-purple-700">Rezime</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 rounded-xl">
                    <h3 className="font-medium text-green-800 mb-2">Break-even</h3>
                    <p className="text-2xl font-bold text-green-700">
                      {breakEvenYears} godina, {breakEvenMonths} meseci
                    </p>
                    <Badge className="mt-2 bg-green-100 text-green-800">
                      Mesec #{breakEvenMonth}
                    </Badge>
                  </div>
                  
                  <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl">
                    <h3 className="font-medium text-blue-800 mb-2">Ukupna ušteda za 30 godina</h3>
                    <p className="text-xl font-bold text-blue-700">
                      {totalSavings30Years.toLocaleString('sr-RS')} RSD
                    </p>
                  </div>
                  
                  <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl">
                    <h3 className="font-medium text-purple-800 mb-2">Ukupna proizvodnja (30 godina)</h3>
                    <p className="text-xl font-bold text-purple-700">
                      {Math.round(totalProduction30Years).toLocaleString('sr-RS')} kWh
                    </p>
                    <p className="text-xs text-purple-600 mt-1">sa degradacijom</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}