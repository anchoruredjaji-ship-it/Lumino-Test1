import React from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { 
  ArrowLeft, 
  Download
} from 'lucide-react';
import LuminoLogo from '../imports/lumino-logo.svg';

interface ProposalHeaderScreenProps {
  onBack: () => void;
  formData: any;
  tipKupca: string;
  napomena: boolean;
}

export default function ProposalHeaderScreen({ onBack, formData }: ProposalHeaderScreenProps) {
  // Export funkcija  
  const exportToPNG = async () => {
    try {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        const content = document.querySelector('.proposal-cover-content');
        if (content) {
          printWindow.document.write(`
            <html>
              <head>
                <title>Ponuda - ${formData?.nazivKupca || 'Klijent'}</title>
                <style>
                  body { 
                    margin: 0; 
                    padding: 0; 
                    font-family: Inter, sans-serif; 
                    background: linear-gradient(135deg, #1e1b4b 0%, #312e81 50%, #581c87 100%);
                    width: 100vw;
                    height: 100vh;
                  }
                  * { box-sizing: border-box; }
                </style>
              </head>
              <body>
                ${content.outerHTML}
              </body>
            </html>
          `);
          printWindow.document.close();
          printWindow.focus();
          
          setTimeout(() => {
            printWindow.print();
            printWindow.close();
          }, 1000);
        }
      }
    } catch (error) {
      console.error('Greška pri eksportovanju:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <div className="h-8 w-32 flex items-center justify-center">
                <img 
                  src={LuminoLogo} 
                  alt="Lumino Logo" 
                  className="h-6 w-auto object-contain"
                />
              </div>
              <Button
                variant="ghost"
                onClick={onBack}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="h-4 w-4" />
                Nazad
              </Button>
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={exportToPNG}
                className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white"
              >
                <Download className="h-4 w-4 mr-2" />
                Izvezi PNG
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Cover Content */}
      <main className="proposal-cover-content min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-purple-800 relative overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute inset-0">
          <div className="absolute top-20 right-20 w-64 h-64 bg-purple-400/10 rounded-full blur-3xl"></div>
          <div className="absolute bottom-32 left-20 w-80 h-80 bg-blue-400/10 rounded-full blur-3xl"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-indigo-400/5 rounded-full blur-3xl"></div>
        </div>

        <div className="relative z-10 flex flex-col justify-center items-center min-h-screen px-8 py-16 text-center">          
          {/* Logo */}
          <div className="mb-12">
            <div className="w-48 h-32 flex items-center justify-center">
              <img 
                src={LuminoLogo} 
                alt="Lumino Logo" 
                className="w-full h-full object-contain filter brightness-0 invert"
              />
            </div>
          </div>

          {/* Professional Badge */}
          <div className="mb-8">
            <Badge className="bg-yellow-500/20 text-yellow-400 border border-yellow-400/30 px-4 py-2 text-base backdrop-blur-sm">
              🟡 Profesionalna solarna rešenja
            </Badge>
          </div>

          {/* Main Title */}
          <h1 className="text-6xl md:text-7xl lg:text-8xl mb-8 bg-gradient-to-br from-yellow-400 via-yellow-300 to-amber-200 bg-clip-text text-transparent">
            Solarna ponuda
          </h1>

          {/* Power Display */}
          <div className="mb-8">
            <div className="text-5xl md:text-6xl lg:text-7xl text-white mb-4">
              {formData?.snagaSistema || '51.040'} kWp
            </div>
          </div>

          {/* Technology Brands */}
          <div className="mb-16">
            <p className="text-xl md:text-2xl text-gray-300">
              Huawei • Leapton • Ključ u ruke
            </p>
          </div>

          {/* Client and Date Cards */}
          <div className="flex flex-col md:flex-row gap-6 mb-16">
            {/* Client Card */}
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 min-w-[280px]">
              <div className="text-gray-400 text-sm mb-2">Klijent</div>
              <div className="text-white text-xl">
                {formData?.nazivKupca || 'FM Pharm'}
              </div>
            </div>

            {/* Date Card */}
            <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 min-w-[280px]">
              <div className="text-gray-400 text-sm mb-2">Datum</div>
              <div className="text-white text-xl">
                {formData?.datum ? new Date(formData.datum).toLocaleDateString('sr-RS', { 
                  day: 'numeric', 
                  month: 'numeric',
                  year: 'numeric'
                }) : '8. 9. 2025.'}
              </div>
            </div>
          </div>

          {/* Bottom Company Name */}
          <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2">
            <h2 className="text-2xl md:text-3xl bg-gradient-to-r from-yellow-400 to-amber-300 bg-clip-text text-transparent">
              Lumino Solarni Sistemi
            </h2>
          </div>
        </div>

        {/* Subtle grid pattern overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/50 to-transparent" 
             style={{
               backgroundImage: `radial-gradient(circle at 1px 1px, rgba(255,255,255,0.05) 1px, transparent 0)`,
               backgroundSize: '50px 50px'
             }}>
        </div>
      </main>
    </div>
  );
}