import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { 
  ArrowLeft, 
  Download, 
  TrendingUp, 
  Leaf, 
  Snowflake, 
  Flower, 
  Sun, 
  Leaf as LeafFall,
  Info,
  Copy,
  Users, 
  Wrench,
  ShieldCheck,
  FileText,
  Package,
  Battery,
  Cpu,
  Check,
  Settings,
  Shield,
  PanelTop,
  Gauge,
  HardHat,
  Plug,
  Cable,
  Building2,
  Lightbulb,
  Factory,
  SquareStack,
  Router,
  Archive,
  Hammer,
  Pickaxe,
  Construction,
  Network,
  MonitorSpeaker,
  Grid3x3,
  RectangleHorizontal,
  CircuitBoard,
  Activity,
  Database,
  Layers,
  Box,
  Grid2x2,
  Square,
  LayoutGrid,
  Boxes,
  Component
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  ResponsiveContainer, 
  Cell,
  Tooltip,
  LineChart, 
  Line, 
  Area, 
  ReferenceLine,
  Tooltip as RechartsTooltip
} from 'recharts';
import { Tooltip as UITooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './ui/tooltip';
import { formatQuoteTitle } from '../utils/QuoteIdGenerator';

interface FinalProposalScreenProps {
  onBack: () => void;
  formData?: any;
  stavke?: any[];
  artikli?: any[];
  tipKupca?: string;
  napomena?: boolean;
}

export default function FinalProposalScreen({ onBack, formData, stavke = [], artikli = [], tipKupca = 'pravno', napomena = false }: FinalProposalScreenProps) {
  const analysisRef = useRef<HTMLDivElement>(null);
  
  // System efficiency state - extract from formData or use defaults
  const [tipSistema] = useState(formData?.tipSistema || 'standard');
  const [customIskoriscenost] = useState(formData?.customIskoriscenost || '100');

  // ===== SYSTEM COMPONENTS LOGIC FROM SYSTEMSPECIFICATIONSCREEN =====
  
  // Extract data from formData or use defaults
  const sistemData = {
    nazivProjekta: formData?.nazivProjekta || 'Solar Sistem',
    snagaSistema: formData?.snagaSistema || '138',
    nazivKupca: formData?.nazivKupca || 'Klijent',
    datum: formData?.datum || new Date().toLocaleDateString('sr-RS'),
    tipKupca: tipKupca,
    napomena: napomena
  };

  // Generate dynamic title
  const generateDynamicTitle = () => {
    const power = parseInt(sistemData.snagaSistema) || 138;
    let systemType = '';
    
    if (power >= 100) {
      systemType = 'Huawei SUN2000 | Premium';
    } else if (power >= 50) {
      systemType = 'Huawei SUN2000 | Standard';
    } else {
      systemType = 'Huawei | Residential';
    }
    
    return `${systemType}`;
  };

  const dynamicTitle = generateDynamicTitle();

  // Icon mapping for different component types
  const getComponentIcon = (tip: string) => {
    const iconMap: Record<string, any> = {
      // Solarni moduli - različite ikone za različite tipove panela
      'solarni-moduli': LayoutGrid,
      'solarni-panel': Square,
      'modul': Grid3x3,
      'panel': RectangleHorizontal,
      'fotovoltaik': Layers,
      'solarski': Boxes,
      
      // Inverter - CircuitBoard predstavlja elektronski uređaj/inverter
      'inverter': CircuitBoard,
      'menjac': Activity,
      
      // Baterija - Database predstavlja skladište energije, Battery za male baterije
      'baterija': Database,
      'akumulator': Layers,
      'skladiste': Archive,
      'napojne': Box,
      
      // Ugradnja - različite ikone za specifične vrste ugradnji
      'ugradnja': HardHat,
      'montaza': Construction,
      'instalacija': Hammer,
      
      // EPS priključak - Plug za električne priključke
      'eps': Plug,
      'prikljucak': Plug,
      
      // Konstrukcija - Building2 za konstrukcijske elemente
      'konstrukcija': Building2,
      'nosac': Building2,
      'profil': SquareStack,
      
      // Kablovi - Cable za kabliranje
      'kablovi': Cable,
      'kabloviranje': Cable,
      
      // Projektovanje - FileText za dokumentaciju
      'projektovanje': FileText,
      'projekat': FileText,
      'dokumentacija': FileText,
      
      // Orman/razvodna tabla - različite ikone za električne komponente
      'orman': MonitorSpeaker,
      'razvodni': Network,
      'tabla': Router,
      'kontroler': Cpu,
      
      // Default fallback
      'default': Package
    };
    
    // Dodatno mapiranje po ključnim rečima u tipu
    if (tip.includes('panel')) return Square;
    if (tip.includes('modul')) return Grid3x3;
    if (tip.includes('solar') && !tip.includes('solarski')) return RectangleHorizontal;
    if (tip.includes('solarski')) return Boxes;
    if (tip.includes('fotovoltaik')) return Layers;
    if (tip.includes('inverter')) return CircuitBoard;
    if (tip.includes('menjac')) return Activity;
    if (tip.includes('baterij')) return Database;
    if (tip.includes('akumulator')) return tip.includes('industrijska') ? Archive : Layers;
    if (tip.includes('skladište') || tip.includes('skladiste')) return Archive;
    if (tip.includes('montaž') || tip.includes('montaza')) return Construction;
    if (tip.includes('ugradnja') || tip.includes('instal')) return HardHat;
    if (tip.includes('eps') || tip.includes('priključ') || tip.includes('prikljuc')) return Plug;
    if (tip.includes('konstrukcij') || tip.includes('nosač') || tip.includes('profil')) return Building2;
    if (tip.includes('kabl') || tip.includes('kabel')) return Cable;
    if (tip.includes('projekt') || tip.includes('dokument')) return FileText;
    if (tip.includes('orman')) return MonitorSpeaker;
    if (tip.includes('razvod')) return Network;
    if (tip.includes('tabla')) return Router;
    if (tip.includes('kontroler')) return Cpu;
    
    return iconMap[tip] || iconMap['default'];
  };

  // Color mapping for different component types - IDENTIČAN SA SYSTEMSPECIFICATIONSCREEN
  const getComponentIconColor = (tip: string) => {
    const colorMap: Record<string, string> = {
      // Solarni moduli - različite nijanse plave za panele
      'solarni-moduli': 'text-blue-800',
      'solarni-panel': 'text-indigo-600', 
      'modul': 'text-blue-600',
      'panel': 'text-blue-700',
      'fotovoltaik': 'text-indigo-700',
      'solarski': 'text-blue-500',
      
      // Inverter - tamnoplava za elektronske komponente
      'inverter': 'text-slate-700',
      'menjac': 'text-gray-700',
      
      // Baterija - zelena za skladištenje energije
      'baterija': 'text-emerald-600',
      'akumulator': 'text-green-600',
      'skladiste': 'text-teal-600',
      'napojne': 'text-green-700',
      
      // Ugradnja - različite boje za različite tipove radova
      'ugradnja': 'text-amber-700',
      'montaza': 'text-orange-600',
      'instalacija': 'text-yellow-600',
      
      // EPS - crvena za električnu energiju
      'eps': 'text-red-600',
      'prikljucak': 'text-red-600',
      
      // Konstrukcija - siva za metalnu konstrukciju
      'konstrukcija': 'text-slate-600',
      'nosac': 'text-slate-600',
      'profil': 'text-slate-600',
      
      // Kablovi - tamnoplava za kablove
      'kablovi': 'text-indigo-600',
      'kabloviranje': 'text-indigo-600',
      
      // Projektovanje - ljubičasta za LuminOne brand
      'projektovanje': 'text-lumino-purple-start',
      'projekat': 'text-lumino-purple-start',
      'dokumentacija': 'text-lumino-purple-start',
      
      // Orman - različite boje za električne komponente  
      'orman': 'text-lumino-turquoise',
      'razvodni': 'text-blue-700',
      'tabla': 'text-indigo-700',
      'kontroler': 'text-purple-600',
      
      // Default
      'default': 'text-gray-600'
    };
    
    // Dodatno mapiranje po ključnim rečima u tipu
    if (tip.includes('panel')) return 'text-indigo-600';
    if (tip.includes('modul')) return 'text-blue-800';
    if (tip.includes('solar') && !tip.includes('solarski')) return 'text-blue-700';
    if (tip.includes('solarski')) return 'text-blue-500';
    if (tip.includes('fotovoltaik')) return 'text-indigo-700';
    if (tip.includes('inverter')) return 'text-slate-700';
    if (tip.includes('menjac')) return 'text-gray-700';
    if (tip.includes('baterij')) return 'text-emerald-600';
    if (tip.includes('akumulator')) return tip.includes('industrijska') ? 'text-teal-600' : 'text-green-600';
    if (tip.includes('skladište') || tip.includes('skladiste')) return 'text-teal-600';
    if (tip.includes('montaž') || tip.includes('montaza')) return 'text-orange-600';
    if (tip.includes('ugradnja') || tip.includes('instal')) return 'text-amber-700';
    if (tip.includes('eps') || tip.includes('priključ') || tip.includes('prikljuc')) return 'text-red-600';
    if (tip.includes('konstrukcij') || tip.includes('nosač') || tip.includes('profil')) return 'text-slate-600';
    if (tip.includes('kabl') || tip.includes('kabel')) return 'text-indigo-600';
    if (tip.includes('projekt') || tip.includes('dokument')) return 'text-lumino-purple-start';
    if (tip.includes('orman')) return 'text-lumino-turquoise';
    if (tip.includes('razvod')) return 'text-blue-700';
    if (tip.includes('tabla')) return 'text-indigo-700';
    if (tip.includes('kontroler')) return 'text-purple-600';
    
    return colorMap[tip] || colorMap['default'];
  };

  // Helper function to find artikal by ID
  const findArtikalById = (id: string) => {
    return artikli.find(artikal => artikal.id === id);
  };

  // Generate system components from form data
  const getSystemComponents = () => {
    const komponente: any[] = [];

    // Process stavke from props
    stavke.forEach((stavka: any, index: number) => {
      // Skip if no quantity or disabled
      if (!stavka.kolicina || stavka.kolicina === 'Ne' || stavka.kolicina === '0') {
        return;
      }

      let componentData: any = {};
      const ComponentIcon = getComponentIcon(stavka.tip);
      
      // Check if this is an artikal-based selection
      if (stavka.tip.startsWith('artikal-')) {
        const artikalId = stavka.tip.replace('artikal-', '');
        const artikal = findArtikalById(artikalId);
        
        if (artikal) {
          componentData = {
            id: komponente.length + 1,
            naziv: artikal.naziv,
            opis: artikal.opis,
            detaljnjiOpis: `${artikal.opis} - ${artikal.garancija} garancije`,
            garancija: artikal.garancija,
            kolicina: stavka.kolicina === 'Da' || stavka.kolicina === 'Ne' ? stavka.kolicina : `${stavka.kolicina} kom`,
            ikona: getComponentIcon(artikal.tip),
            boja: getComponentIconColor(artikal.tip),
            tip: artikal.tip
          };
        }
      } else {
        // Handle basic component types
        const baseKomponenta = {
          id: komponente.length + 1,
          ikona: ComponentIcon,
          boja: getComponentIconColor(stavka.tip),
          kolicina: stavka.kolicina === 'Da' || stavka.kolicina === 'Ne' ? stavka.kolicina : `${stavka.kolicina} kom`,
          tip: stavka.tip
        };

        switch (stavka.tip) {
          case 'solarni-moduli':
            componentData = {
              ...baseKomponenta,
              naziv: 'Solarni moduli 580W',
              opis: 'Visokoperformansni monokristalin paneli',
              detaljnjiOpis: 'N-type, bifacial technology sa visokom efikasnošću i dugogodišnjom garancijom',
              garancija: '30 godina'
            };
            break;
          case 'inverter':
            const snaga = parseInt(formData?.snagaSistema || '138');
            componentData = {
              ...baseKomponenta,
              naziv: snaga >= 50 ? 'Huawei SUN2000-50KTL' : 'Huawei SUN2000-20KTL',
              opis: `String inverter ${snaga >= 50 ? '50' : '20'} kW snage`,
              detaljnjiOpis: 'Napredni string inverter sa visokom efikasnošću i MPPT optimizacijom',
              garancija: '10 godina'
            };
            break;
          case 'baterija':
            componentData = {
              ...baseKomponenta,
              naziv: 'Litijum baterija 10kWh',
              opis: 'LiFePO4 baterija za skladištenje energije',
              detaljnjiOpis: 'Visokokvalitetna baterija sa dugim ciklusom rada i sigurnim sistemom upravljanja',
              garancija: '10 godina'
            };
            break;
          case 'ugradnja':
            if (stavka.kolicina === 'Da') {
              componentData = {
                ...baseKomponenta,
                naziv: 'Profesionalna ugradnja',
                opis: 'Kompletna instalacija sistema',
                detaljnjiOpis: 'Montaža panela, invertora, kablova i svih komponenti sa finalizacijom sistema',
                garancija: '2 godine'
              };
            }
            break;
          case 'eps':
            if (stavka.kolicina === 'Da') {
              componentData = {
                ...baseKomponenta,
                naziv: 'EPS priključak',
                opis: 'Priključak na elektroenergetsku mrežu',
                detaljnjiOpis: 'Koordinacija sa EPS-om, tehnička dokumentacija i finalno puštanje u rad',
                garancija: '1 godina'
              };
            }
            break;
        }
      }

      // Add component if we have valid data
      if (componentData.naziv) {
        komponente.push(componentData);
      }
    });

    // Always add project documentation - IDENTIČAN SA SYSTEMSPECIFICATIONSCREEN
    komponente.push({
      id: komponente.length + 1,
      naziv: 'Projektovanje i dokumentacija',
      opis: 'Tehnička dokumentacija i obučavanje',
      detaljnjiOpis: 'Kompletna tehnička dokumentacija, plan realizacije i detaljno obučavanje korisnika',
      kolicina: '1 paket',
      garancija: '2 godine',
      ikona: FileText,
      boja: getComponentIconColor('dokumentacija'),
      tip: 'dokumentacija'
    });

    return komponente;
  };

  const komponente = getSystemComponents();

  // ===== ANALIZA PROIZVODNJE - IDENTIČNA SA SOLAR DASHBOARD =====
  const getMonthlyData = () => {
    const defaultValues = [2850, 3200, 4500, 5800, 6900, 7200, 7350, 6800, 5400, 4100, 3200, 2800];
    let monthlyProduction = defaultValues;
    
    if (formData?.mesecnaProizvodnja) {
      // Parse monthly production data - ignore commas and dots as they are thousands separators
      const values = formData.mesecnaProizvodnja
        .split(/[\n]/)
        .map((val: string) => {
          // Remove all commas and dots, then parse as integer
          const cleanedVal = val.trim().replace(/[,.]/g, '');
          return parseInt(cleanedVal) || 0;
        })
        .filter((val: number) => val > 0);
      
      if (values.length >= 12) {
        monthlyProduction = values.slice(0, 12);
      }
    }
    
    return monthlyProduction;
  };

  const monthlyData = getMonthlyData();
  const totalProduction = monthlyData.reduce((sum, val) => sum + val, 0);
  const co2Savings = Math.round(totalProduction * 0.53);

  // Sezonska analiza
  const winter = monthlyData[11] + monthlyData[0] + monthlyData[1]; // Dec, Jan, Feb
  const spring = monthlyData[2] + monthlyData[3] + monthlyData[4]; // Mar, Apr, May
  const summer = monthlyData[5] + monthlyData[6] + monthlyData[7]; // Jun, Jul, Aug
  const autumn = monthlyData[8] + monthlyData[9] + monthlyData[10]; // Sep, Oct, Nov

  const seasons = [
    {
      name: 'Zima',
      production: winter,
      months: 'kWh (Dec-Feb)',
      percentage: ((winter / totalProduction) * 100).toFixed(1),
      icon: Snowflake,
      bgColor: 'bg-gradient-to-br from-lumino-purple-start/10 to-lumino-purple-start/20',
      textColor: 'text-lumino-purple-start',
      iconColor: 'text-lumino-purple-start/70'
    },
    {
      name: 'Proleće',
      production: spring,
      months: 'kWh (Mar-Maj)',
      percentage: ((spring / totalProduction) * 100).toFixed(1),
      icon: Flower,
      bgColor: 'bg-gradient-to-br from-lumino-turquoise/10 to-lumino-turquoise/20',
      textColor: 'text-lumino-turquoise',
      iconColor: 'text-lumino-turquoise/70'
    },
    {
      name: 'Leto',
      production: summer,
      months: 'kWh (Jun-Avg)',
      percentage: ((summer / totalProduction) * 100).toFixed(1),
      icon: Sun,
      bgColor: 'bg-gradient-to-br from-lumino-purple-end/10 to-lumino-purple-end/20',
      textColor: 'text-lumino-purple-end',
      iconColor: 'text-lumino-purple-end/70'
    },
    {
      name: 'Jesen',
      production: autumn,
      months: 'kWh (Sep-Nov)',
      percentage: ((autumn / totalProduction) * 100).toFixed(1),
      icon: LeafFall,
      bgColor: 'bg-gradient-to-br from-amber-100 to-amber-200',
      textColor: 'text-amber-700',
      iconColor: 'text-amber-500'
    }
  ];

  // Chart data for bar chart
  const chartData = monthlyData.map((production, index) => {
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Avg', 'Sep', 'Okt', 'Nov', 'Dec'];
    const colors = [
      '#7C3AED', '#6D28D9', '#8B5CF6', '#A78BFA',
      '#1CD4D4', '#0891B2', '#06B6D4', '#67E8F9',
      '#7C3AED', '#6D28D9', '#8B5CF6', '#A78BFA'
    ];
    
    return {
      month: monthNames[index],
      production: production,
      color: colors[index % colors.length]
    };
  });

  // ===== ROI KALKULACIJA =====
  const [electricityPrice, setElectricityPrice] = useState(7.0);
  const [eurRate, setEurRate] = useState(117.0);
  const [degradationAfter30, setDegradationAfter30] = useState(parseFloat(formData?.degradacijaNakon30 || '20'));

  // ROI Calculation function
  const calculateROI = () => {
    const systemCostEUR = parseFloat(formData?.cenaBezPDV || formData?.cenaSaPDV || '30000');
    const systemCostRSD = systemCostEUR * eurRate;
    const annualProduction = totalProduction;
    
    const data = [];
    let cumulativeCashFlow = -systemCostRSD;
    let breakEvenMonth = 0;
    
    for (let month = 1; month <= 360; month++) {
      const year = Math.ceil(month / 12);
      const degradationFactor = 1.0 - (degradationAfter30 / 100) * ((year - 1) / 29);
      const monthlyProduction = (annualProduction / 12) * Math.max(0, degradationFactor);
      const monthlySavings = monthlyProduction * electricityPrice;
      
      cumulativeCashFlow += monthlySavings;
      
      if (cumulativeCashFlow >= 0 && breakEvenMonth === 0) {
        breakEvenMonth = month;
      }
      
      data.push({
        month,
        year,
        cumulativeCashFlow: Math.round(cumulativeCashFlow),
        monthlySavings: Math.round(monthlySavings),
        monthlyProduction: Math.round(monthlyProduction)
      });
    }
    
    return { data, breakEvenMonth };
  };

  const { data: roiData, breakEvenMonth } = calculateROI();
  const breakEvenYears = Math.floor(breakEvenMonth / 12);
  const breakEvenMonths = breakEvenMonth % 12;
  const totalSavings30Years = roiData[359]?.cumulativeCashFlow || 0;
  const systemCostEUR = parseFloat(formData?.cenaBezPDV || formData?.cenaSaPDV || '30000');
  const systemCostRSD = systemCostEUR * eurRate;

  const copyTooltipText = "Degradacija: Linearna degradacija panela sa 100% performansi u prvoj godini do 87.4% u 30. godini. Formula: 1.0 - (0.126 * (godina - 1) / 29)";

  // Export funkcija
  const exportToPNG = async () => {
    try {
      const printWindow = window.open('', '_blank');
      if (printWindow && analysisRef.current) {
        printWindow.document.write(`
          <html>
            <head>
              <title>Analiza Proizvodnje i ROI - ${new Date().toLocaleDateString('sr-RS')}</title>
              <style>
                body { 
                  margin: 0; 
                  padding: 20px; 
                  font-family: Inter, sans-serif; 
                  background: white;
                  width: 1200px;
                }
                * { box-sizing: border-box; }
              </style>
            </head>
            <body>
              ${analysisRef.current.outerHTML}
            </body>
          </html>
        `);
        printWindow.document.close();
        printWindow.focus();
        
        setTimeout(() => {
          printWindow.print();
          printWindow.close();
        }, 1000);
      }
    } catch (error) {
      console.error('Greška pri eksportovanju:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <div className="h-8 w-32 bg-gradient-to-r from-purple-600 to-purple-800 rounded flex items-center justify-center text-white font-bold text-sm">
                LuminOne
              </div>
              <Button
                variant="ghost"
                onClick={onBack}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="h-4 w-4" />
                Nazad
              </Button>
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={exportToPNG}
                className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white"
              >
                <Download className="h-4 w-4 mr-2" />
                Izvezi PNG
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" ref={analysisRef}>
        {/* Quote Title with Visual Separator */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center bg-gradient-to-r from-purple-50 to-teal-50 px-8 py-4 rounded-2xl border border-purple-200/50 shadow-lg">
            <h1 className="text-2xl font-bold text-gray-800">
              <span className="text-purple-700">Ponuda</span>
              <span className="mx-3 text-teal-500">•</span>
              <span className="text-purple-600">{formatQuoteTitle(formData?.datum).split('• ')[1]}</span>
            </h1>
          </div>
        </div>

        <div className="space-y-16">
          {/* ===== COMPONENTE SISTEMA SEKCIJA - PRVA NA STRANICI ===== */}
          <section className="space-y-12">
            {/* Compact Offer Header - IDENTIČAN SA SYSTEMSPECIFICATIONSCREEN */}
            <div className="bg-gradient-to-r from-lumino-purple-start/10 via-white to-lumino-turquoise/10 p-6 rounded-xl border border-lumino-purple-start/20 shadow-lg">
              <div className="space-y-6">
                {/* Main Header */}
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-3">
                      <h1 className="text-2xl font-bold text-lumino-purple-start">
                        <span className="text-lumino-purple-start">Ponuda</span>
                        <span className="mx-2 text-lumino-turquoise">•</span>
                        <span className="text-lumino-purple-end">{formatQuoteTitle(formData?.datum).split(' • ')[1]}</span>
                      </h1>
                      <div className="h-px bg-lumino-purple-start/30 flex-1 hidden sm:block mx-3"></div>
                      <Badge variant="outline" className="text-base px-3 py-1 border-lumino-turquoise/40 text-lumino-turquoise bg-lumino-turquoise/10 font-semibold self-start sm:self-center">
                        {dynamicTitle}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground leading-relaxed max-w-2xl">
                      Kompletno solarno rešenje prilagođeno vašim potrebama.
                    </p>
                  </div>
                  <div className="flex flex-col gap-3 text-center lg:text-right">
                    <div className="flex flex-col gap-2">
                      <Badge variant="outline" className="text-xl px-4 py-2 border-lumino-purple-start/30 text-lumino-purple-start bg-lumino-purple-start/10 font-bold">
                        {sistemData.snagaSistema} kWp
                      </Badge>
                      <div className="text-sm text-muted-foreground">
                        {sistemData.nazivProjekta || 'Solar Sistem'}
                      </div>
                    </div>
                    <div className="text-xs text-lumino-purple-start/70 bg-lumino-purple-start/5 px-3 py-1 rounded-full">
                      {sistemData.datum}
                    </div>
                  </div>
                </div>

                {/* Compact Info Grid */}
                <div className="bg-white/60 backdrop-blur-sm rounded-lg p-4 border border-lumino-purple-start/10">
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-center">
                    <div className="space-y-1">
                      <div className="text-base font-bold text-lumino-purple-start">{sistemData.tipKupca === 'pravno' ? '30' : '25'} god</div>
                      <div className="text-xs text-muted-foreground">Garancija</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-base font-bold text-lumino-turquoise">Huawei</div>
                      <div className="text-xs text-muted-foreground">Inverter</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-base font-bold text-lumino-purple-start">
                        {parseInt(sistemData.snagaSistema) >= 100 ? 'Premium' : 
                         parseInt(sistemData.snagaSistema) >= 50 ? 'Standard' : 'Residential'}
                      </div>
                      <div className="text-xs text-muted-foreground">Tip sistema</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-base font-bold text-lumino-purple-start">{sistemData.nazivKupca || 'Klijent'}</div>
                      <div className="text-xs text-muted-foreground">Kupac</div>
                    </div>
                  </div>
                </div>

                {/* Mini Services */}
                <div className="border-t border-lumino-purple-start/20 pt-4">
                  <h3 className="text-center text-base font-semibold text-lumino-purple-start mb-4">Usluge ključ u ruke</h3>
                  <div className="grid grid-cols-4 gap-3">
                    <div className="text-center">
                      <div className="w-8 h-8 mx-auto mb-2 rounded-lg bg-lumino-purple-start/10 flex items-center justify-center">
                        <Users className="h-4 w-4 text-lumino-purple-start" />
                      </div>
                      <div className="text-xs text-muted-foreground">Savetovanje</div>
                    </div>
                    <div className="text-center">
                      <div className="w-8 h-8 mx-auto mb-2 rounded-lg bg-lumino-turquoise/10 flex items-center justify-center">
                        <FileText className="h-4 w-4 text-lumino-turquoise" />
                      </div>
                      <div className="text-xs text-muted-foreground">Projektovanje</div>
                    </div>
                    <div className="text-center">
                      <div className="w-8 h-8 mx-auto mb-2 rounded-lg bg-lumino-purple-start/10 flex items-center justify-center">
                        <Wrench className="h-4 w-4 text-lumino-purple-start" />
                      </div>
                      <div className="text-xs text-muted-foreground">Montaža</div>
                    </div>
                    <div className="text-center">
                      <div className="w-8 h-8 mx-auto mb-2 rounded-lg bg-lumino-turquoise/10 flex items-center justify-center">
                        <ShieldCheck className="h-4 w-4 text-lumino-turquoise" />
                      </div>
                      <div className="text-xs text-muted-foreground">Podrška</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Components Section */}
            <div className="text-center space-y-4">
              <h2 className="text-3xl font-semibold bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise bg-clip-text text-transparent">
                Komponente sistema
              </h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Detaljni pregled svih komponenti uključenih u vaš solarni sistem
              </p>
            </div>

            {komponente.length > 0 ? (
              <div className="space-y-8">
                {/* Traditional Table with Modern Styling */}
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise text-white">
                          <th className="px-4 py-4 text-left text-sm font-semibold w-16">
                            Poz.
                          </th>
                          <th className="px-4 py-4 text-left text-sm font-semibold">
                            Opis
                          </th>
                          <th className="px-4 py-4 text-center text-sm font-semibold w-24">
                            Slika
                          </th>
                          <th className="px-4 py-4 text-center text-sm font-semibold w-20">
                            J.M.
                          </th>
                          <th className="px-4 py-4 text-center text-sm font-semibold w-20">
                            Kol.
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {komponente.map((komponenta, index) => {
                          // Find corresponding artikal for image
                          let slikaUrl = null;
                          if (komponenta.tip?.startsWith('artikal-')) {
                            const artikalId = komponenta.tip.replace('artikal-', '');
                            const artikal = findArtikalById(artikalId);
                            slikaUrl = artikal?.slika;
                          }

                          return (
                            <tr key={komponenta.id} className="border-b border-gray-200 hover:bg-gradient-to-r hover:from-lumino-purple-start/5 hover:to-lumino-turquoise/5 transition-colors duration-200">
                              <td className="px-4 py-6 text-center text-sm font-medium text-lumino-purple-start">
                                {index + 1}.
                              </td>
                              <td className="px-4 py-6">
                                <div className="space-y-2">
                                  <h4 className="font-semibold text-foreground text-base">
                                    {komponenta.naziv}
                                  </h4>
                                  <p className="text-sm text-lumino-turquoise font-medium">
                                    {komponenta.opis}
                                  </p>
                                  <div className="text-xs text-muted-foreground leading-relaxed">
                                    {komponenta.detaljnjiOpis?.split('\\n').map((line, i) => (
                                      <div key={i} className="mb-1">
                                        {line.trim().startsWith('•') ? (
                                          <div className="flex items-start gap-2">
                                            <span className="text-lumino-turquoise">•</span>
                                            <span>{line.trim().slice(1).trim()}</span>
                                          </div>
                                        ) : (
                                          line.trim()
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                  {komponenta.garancija && (
                                    <div className="mt-2">
                                      <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-300">
                                        Garancija: {komponenta.garancija}
                                      </Badge>
                                    </div>
                                  )}
                                </div>
                              </td>
                              <td className="px-2 py-6 text-center">
                                {slikaUrl ? (
                                  <div className="w-16 h-12 mx-auto bg-gray-100 rounded-lg border-2 border-lumino-purple-start/20 overflow-hidden shadow-sm">
                                    <img 
                                      src={slikaUrl} 
                                      alt={komponenta.naziv}
                                      className="w-full h-full object-cover"
                                    />
                                  </div>
                                ) : (
                                  <div className="w-16 h-12 mx-auto bg-gradient-to-br from-gray-50 to-white rounded-lg border-2 border-gray-200 flex items-center justify-center shadow-sm hover:shadow-md transition-shadow">
                                    <komponenta.ikona className={`h-7 w-7 ${komponenta.boja || 'text-lumino-purple-start'}`} />
                                  </div>
                                )}
                              </td>
                              <td className="px-4 py-6 text-center text-sm font-medium text-foreground">
                                {(() => {
                                  if (komponenta.tip?.startsWith('artikal-')) {
                                    const artikalId = komponenta.tip.replace('artikal-', '');
                                    const artikal = findArtikalById(artikalId);
                                    return artikal?.jedinicaMere || 'kom.';
                                  }
                                  return 'kom.';
                                })()}
                              </td>
                              <td className="px-4 py-6 text-center">
                                <Badge variant="outline" className="bg-lumino-turquoise/10 text-lumino-turquoise border-lumino-turquoise/30 font-semibold">
                                  {komponenta.kolicina}
                                </Badge>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Modern Footer with Traditional Info */}
                <div className="bg-gradient-to-r from-gray-50 to-white rounded-xl border border-gray-200 shadow-lg overflow-hidden">
                  <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <h4 className="font-semibold text-lumino-purple-start">Način plaćanja:</h4>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <p>50% avans pre isporuke opreme na lokaciju</p>
                          <p>50% nakon puštanja elektrane u rad</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-semibold text-lumino-purple-start">Valuta plaćanja:</h4>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <p>Uplate u dinarima, kurs se obračunava po srednjem</p>
                          <p>kursu NBS na dan plaćanja.</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-semibold text-lumino-purple-start">Vreme realizacije projekta:</h4>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <p>Oprema se nalazi na stanju, moguća je realizacija u</p>
                          <p>roku od 10 dana od prihvatanja ponude.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Total Price Section */}
                  <div className="bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise p-4">
                    <div className="text-center text-white">
                      <p className="text-lg font-semibold">
                        Ukupna cena sistema ključ u ruke{napomena && tipKupca === 'pravno' ? ', Član 10 - bez PDV-a' : ', bez PDV-a'} (EUR): {formData?.cenaBezPDV ? parseFloat(formData.cenaBezPDV).toLocaleString('sr-RS') : '24.900,00'} €
                      </p>
                      {!napomena && tipKupca === 'pravno' && formData?.cenaSaPDV && (
                        <p className="text-sm text-white/90 mt-1">
                          Sa PDV-om: {parseFloat(formData.cenaSaPDV).toLocaleString('sr-RS')} €
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <Card className="shadow-sm border border-border">
                <CardContent className="p-12 text-center">
                  <Package className="h-16 w-16 mx-auto mb-4 text-muted-foreground/50" />
                  <h3 className="text-xl font-semibold text-muted-foreground mb-2">Nema aktivnih komponenti</h3>
                  <p className="text-muted-foreground mb-4">
                    Dodajte komponente u glavnoj formi (sekcija "Stavke") da biste videli specifikaciju sistema
                  </p>
                  <div className="text-left text-sm text-muted-foreground bg-muted/50 p-4 rounded-lg max-w-md mx-auto">
                    <p className="font-medium mb-2">Trenutno stanje stavki:</p>
                    <ul className="space-y-1">
                      {stavke.map((stavka, index) => (
                        <li key={stavka.id} className="flex justify-between">
                          <span>{stavka.tip}:</span>
                          <span className={stavka.kolicina && stavka.kolicina !== 'Ne' && stavka.kolicina !== '0' ? 'text-green-600' : 'text-red-500'}>
                            {stavka.kolicina || 'Nije uneto'}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            )}
          </section>

          {/* ===== ANALIZA PROIZVODNJE SEKCIJA ===== */}
          <section className="space-y-8">
            <div className="text-center">
              <h2 className="text-4xl font-bold bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise bg-clip-text text-transparent mb-4">Analiza Proizvodnje</h2>
              <p className="text-xl text-muted-foreground">Detaljana analiza godišnje i mesečne proizvodnje energije</p>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card className="bg-gradient-to-br from-lumino-turquoise to-cyan-500 text-white border-0 shadow-lg">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <TrendingUp className="h-8 w-8" />
                        <h3 className="text-xl font-medium">Godišnja proizvodnja</h3>
                      </div>
                      <p className="text-4xl font-bold mb-2">{totalProduction.toLocaleString('sr-RS')}</p>
                      <p className="text-cyan-100 text-lg">kWh</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-lumino-purple-start to-lumino-purple-end text-white border-0 shadow-lg">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="flex items-center gap-3 mb-3">
                        <Leaf className="h-8 w-8" />
                        <h3 className="text-xl font-medium">Smanjenje CO₂</h3>
                      </div>
                      <p className="text-4xl font-bold mb-2">{co2Savings.toLocaleString('sr-RS')}</p>
                      <p className="text-purple-100 text-lg">kg godišnje</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sezonska analiza */}
            <div className="mb-8">
              <h2 className="text-2xl font-semibold bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise bg-clip-text text-transparent text-center mb-6">Sezonska analiza proizvodnje</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                {seasons.map((season, index) => (
                  <Card key={index} className={`${season.bgColor} border-0 shadow-md`}>
                    <CardContent className="p-6">
                      <div className="text-center">
                        <season.icon className={`h-12 w-12 mx-auto mb-4 ${season.iconColor}`} />
                        <h3 className={`text-lg font-semibold mb-2 ${season.textColor}`}>{season.name}</h3>
                        <p className={`text-2xl font-bold mb-1 ${season.textColor}`}>
                          {season.production.toLocaleString('sr-RS')}
                        </p>
                        <p className={`text-sm ${season.textColor} opacity-80 mb-2`}>{season.months}</p>
                        <p className={`text-sm font-medium ${season.textColor}`}>
                          {season.percentage}% ukupne
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Main Chart Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Left Column - Location Parameters */}
              <div className="lg:col-span-1">
                <h2 className="text-xl font-semibold mb-6 text-lumino-purple-start">Parametri lokacije</h2>
                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-lumino-purple-start/10 flex items-center justify-center flex-shrink-0">
                      <div className="w-5 h-5 text-lumino-purple-start">📍</div>
                    </div>
                    <div className="flex-1 pt-1">
                      <p className="text-gray-700 font-medium">Adresa:</p>
                      <p className="text-gray-900 font-semibold">{formData?.objekatLokacija || "Subotica"}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-lumino-turquoise/10 flex items-center justify-center flex-shrink-0">
                      <div className="w-5 h-5 text-lumino-turquoise">🔄</div>
                    </div>
                    <div className="flex-1 pt-1">
                      <p className="text-gray-700 font-medium">Orijentacija:</p>
                      <p className="text-gray-900 font-semibold">SE 146°</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-lumino-purple-end/10 flex items-center justify-center flex-shrink-0">
                      <div className="w-5 h-5 text-lumino-purple-end">📈</div>
                    </div>
                    <div className="flex-1 pt-1">
                      <p className="text-gray-700 font-medium">Nagib:</p>
                      <p className="text-gray-900 font-semibold">15°</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-lumino-turquoise/10 flex items-center justify-center flex-shrink-0">
                      <div className="w-5 h-5 text-lumino-turquoise">📊</div>
                    </div>
                    <div className="flex-1 pt-1">
                      <p className="text-gray-700 font-medium">Performance ratio:</p>
                      <p className="text-gray-900 font-semibold">93.12%</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-lg bg-lumino-purple-start/10 flex items-center justify-center flex-shrink-0">
                      <div className="w-5 h-5 text-lumino-purple-start">⚡</div>
                    </div>
                    <div className="flex-1 pt-1">
                      <p className="text-gray-700 font-medium">Degradacija:</p>
                      <p className="text-gray-900 font-semibold">1% godina 1, zatim 0.4% godišnje</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Right Column - Monthly Production Chart */}
              <div className="lg:col-span-2">
                <Card className="bg-white border border-gray-200 shadow-sm">
                  <CardHeader>
                    <CardTitle className="text-xl font-semibold text-lumino-purple-start">Mesečna proizvodnja</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="h-80 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart
                          data={chartData}
                          margin={{
                            top: 20,
                            right: 30,
                            left: 20,
                            bottom: 5,
                          }}
                        >
                          <CartesianGrid 
                            strokeDasharray="3 3" 
                            stroke="#f3f4f6"
                            strokeOpacity={0.8}
                          />
                          <XAxis 
                            dataKey="month" 
                            axisLine={false}
                            tickLine={false}
                            tick={{ fontSize: 14, fill: '#6b7280' }}
                          />
                          <YAxis 
                            axisLine={false}
                            tickLine={false}
                            tick={{ fontSize: 14, fill: '#6b7280' }}
                            tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                            domain={[0, 8000]}
                          />
                          <Tooltip
                            contentStyle={{
                              backgroundColor: '#ffffff',
                              border: '1px solid #e5e7eb',
                              borderRadius: '12px',
                              boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                              color: '#1f2937'
                            }}
                            labelStyle={{ color: '#1f2937', fontWeight: '600' }}
                            itemStyle={{ color: '#1f2937' }}
                            formatter={(value: number) => [`${value.toLocaleString('sr-RS')} kWh`, 'Proizvodnja']}
                            labelFormatter={(label) => `Mesec: ${label}`}
                          />
                          <Bar 
                            dataKey="production" 
                            radius={[6, 6, 0, 0]}
                          >
                            {chartData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Bar>
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                    
                    {/* Bottom info */}
                    <div className="mt-6 pt-4 border-t border-gray-100">
                      <div className="flex flex-col sm:flex-row justify-between gap-4 text-sm">
                        <div className="text-gray-700">
                          <span className="font-medium">Najveća proizvodnja:</span>
                          <span className="ml-2 font-semibold">
                            Jul ({Math.max(...monthlyData).toLocaleString('sr-RS')} kWh)
                          </span>
                        </div>
                        <div className="text-gray-700">
                          <span className="font-medium">Ukupna godišnja proizvodnja:</span>
                          <span className="ml-2 font-semibold">{totalProduction.toLocaleString('sr-RS')} kWh</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </section>

          {/* ===== ROI ANALIZA SEKCIJA - SAMO ZA PRAVNA LICA ===== */}
          {formData?.tipKupca !== 'fizicko' && (
            <section className="space-y-8">
              <div className="text-center space-y-2">
                <h2 className="text-4xl font-bold bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise bg-clip-text text-transparent mb-4">ROI – Povrat investicije</h2>
                <p className="text-xl text-muted-foreground">Interaktivna analiza povrata investicije kroz 30 godina</p>
                <Badge className="bg-lumino-purple-start/10 text-lumino-purple-start border-lumino-purple-start/30">
                  Degradacija panela do {(100 - degradationAfter30)}% u 30 god. (linearno)
                </Badge>
              </div>

              {/* ROI Ulazi */}
              <Card className="border-lumino-purple-start/20 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lumino-purple-start">ROI Parametri</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="electricityPrice">Cena struje (RSD/kWh)</Label>
                      <Input
                        id="electricityPrice"
                        type="number"
                        step="0.1"
                        value={electricityPrice}
                        onChange={(e) => setElectricityPrice(parseFloat(e.target.value) || 0)}
                        className="bg-input-background"
                      />
                    </div>
                    <div>
                      <Label htmlFor="eurRate">Srednji kurs (RSD/EUR)</Label>
                      <Input
                        id="eurRate"
                        type="number"
                        step="0.1"
                        value={eurRate}
                        onChange={(e) => setEurRate(parseFloat(e.target.value) || 0)}
                        className="bg-input-background"
                      />
                    </div>
                    <div>
                      <Label htmlFor="degradationAfter30">Degradacija nakon 30g (%)</Label>
                      <Input
                        id="degradationAfter30"
                        type="number"
                        step="0.1"
                        value={degradationAfter30}
                        onChange={(e) => setDegradationAfter30(parseFloat(e.target.value) || 20)}
                        className="bg-input-background"
                      />
                    </div>
                    <div>
                      <Label htmlFor="eurPrice">Cena sistema (EUR)</Label>
                      <Input
                        id="eurPrice"
                        type="number"
                        value={systemCostEUR}
                        readOnly
                        className="bg-gray-100 text-gray-600"
                      />
                    </div>
                    <div>
                      <Label htmlFor="rsdPrice">Cena sistema (RSD)</Label>
                      <Input
                        id="rsdPrice"
                        type="number"
                        value={Math.round(systemCostRSD)}
                        readOnly
                        className="bg-gray-100 text-gray-600"
                      />
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200 flex items-center gap-2">
                    <Info className="h-4 w-4 text-blue-600" />
                    <span className="text-sm text-blue-800">
                      Degradacija: 100% → {(100 - degradationAfter30)}% za 30 godina
                    </span>
                    <TooltipProvider>
                      <UITooltip>
                        <TooltipTrigger asChild>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 w-6 p-0 text-blue-600 hover:text-blue-800"
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </TooltipTrigger>
                        <TooltipContent className="max-w-xs">
                          <p className="text-xs">{copyTooltipText}</p>
                        </TooltipContent>
                      </UITooltip>
                    </TooltipProvider>
                    <span className="text-xs text-lumino-turquoise ml-auto">linearno, primenjuje se po godini</span>
                  </div>
                </CardContent>
              </Card>

              {/* ROI Dashboard */}
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-br from-lumino-purple-start/5 via-white to-lumino-turquoise/5 rounded-3xl"></div>
                
                <div className="relative bg-white/80 backdrop-blur-sm border border-lumino-purple-start/20 shadow-2xl rounded-3xl overflow-hidden">
                  <div className="bg-gradient-to-r from-lumino-purple-start via-lumino-purple-end to-lumino-turquoise p-6 text-white relative overflow-hidden">
                    <div className="absolute inset-0 bg-gradient-to-r from-lumino-purple-start/20 to-lumino-turquoise/20 animate-pulse"></div>
                    <div className="relative z-10">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="text-2xl font-bold mb-2">ROI Analiza Sistema</h3>
                          <p className="text-white/90">Detaljaan pregled profitabilnosti kroz 30 godina</p>
                        </div>
                        <div className="text-right">
                          <div className="bg-white/20 backdrop-blur rounded-2xl p-3 border border-white/30">
                            <div className="text-3xl font-bold text-white">
                              {Math.ceil(breakEvenMonth / 12)}
                            </div>
                            <div className="text-sm text-white/80">godina povrata</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6">
                    {/* KPI Kartice */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                      <div className="bg-gradient-to-br from-lumino-purple-start to-lumino-purple-end text-white p-4 rounded-2xl shadow-lg transform hover:scale-105 transition-transform">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-white/80 text-sm">Ukupna ušteda</div>
                            <div className="text-2xl font-bold">
                              {(totalSavings30Years / 1000000).toFixed(1)}M RSD
                            </div>
                          </div>
                          <div className="text-white/80 text-3xl">💰</div>
                        </div>
                      </div>
                      
                      <div className="bg-gradient-to-br from-lumino-turquoise to-cyan-500 text-white p-4 rounded-2xl shadow-lg transform hover:scale-105 transition-transform">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-white/80 text-sm">Godišnja proizvodnja</div>
                            <div className="text-2xl font-bold">
                              {(totalProduction / 1000).toFixed(0)}k kWh
                            </div>
                          </div>
                          <div className="text-white/80 text-3xl">⚡</div>
                        </div>
                      </div>
                      
                      <div className="bg-gradient-to-br from-emerald-500 to-green-600 text-white p-4 rounded-2xl shadow-lg transform hover:scale-105 transition-transform">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-white/80 text-sm">30-god degradacija</div>
                            <div className="text-2xl font-bold">{degradationAfter30}%</div>
                          </div>
                          <div className="text-white/80 text-3xl">📉</div>
                        </div>
                      </div>
                    </div>

                    {/* ROI Grafikon */}
                    <div className="bg-gradient-to-br from-white to-lumino-purple-start/5 p-6 rounded-2xl border border-lumino-purple-start/20">
                      <div className="mb-6">
                        <h4 className="text-2xl font-bold bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise bg-clip-text text-transparent mb-2">
                          Kumulativni Povrat Investicije
                        </h4>
                        <p className="text-muted-foreground">Praćenje profitabilnosti kroz vreme sa tačkom break-even-a</p>
                      </div>
                      
                      <div className="h-[500px] relative bg-white rounded-xl shadow-inner border border-lumino-purple-start/10 p-4">
                        <ResponsiveContainer width="100%" height="100%">
                          <LineChart 
                            data={roiData} 
                            margin={{ top: 30, right: 50, left: 80, bottom: 80 }}
                          >
                            <defs>
                              <linearGradient id="roiAreaGradient" x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor="#7C3AED" stopOpacity={0.4}/>
                                <stop offset="50%" stopColor="#8B5CF6" stopOpacity={0.2}/>
                                <stop offset="100%" stopColor="#1CD4D4" stopOpacity={0.1}/>
                              </linearGradient>
                              <linearGradient id="lineGradient" x1="0" y1="0" x2="1" y2="0">
                                <stop offset="0%" stopColor="#7C3AED"/>
                                <stop offset="50%" stopColor="#8B5CF6"/>
                                <stop offset="100%" stopColor="#1CD4D4"/>
                              </linearGradient>
                            </defs>
                            
                            <CartesianGrid 
                              strokeDasharray="3 3" 
                              stroke="#e2e8f0" 
                              horizontal={true}
                              vertical={true}
                              opacity={0.4}
                            />
                            
                            <XAxis 
                              dataKey="month" 
                              type="number"
                              scale="linear"
                              domain={[1, 360]}
                              tickFormatter={(value) => `${Math.ceil(value / 12)}g`}
                              stroke="#7C3AED"
                              fontSize={12}
                              fontWeight={500}
                            />
                            
                            <YAxis 
                              tickFormatter={(value) => {
                                if (Math.abs(value) >= 1000000) return `${(value / 1000000).toFixed(1)}M`;
                                if (Math.abs(value) >= 1000) return `${(value / 1000).toFixed(0)}k`;
                                return value.toLocaleString('sr-RS');
                              }}
                              stroke="#1CD4D4"
                              fontSize={12}
                              fontWeight={500}
                            />
                            
                            <RechartsTooltip 
                              formatter={(value: any, name: string) => [
                                `${parseInt(value).toLocaleString('sr-RS')} RSD`,
                                'Kumulativna ušteda'
                              ]}
                              labelFormatter={(month: any) => {
                                const years = Math.ceil(month / 12);
                                const monthsRem = month % 12 || 12;
                                const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Avg', 'Sep', 'Okt', 'Nov', 'Dec'];
                                return `${years}. godina, ${monthNames[monthsRem - 1]}`;
                              }}
                              contentStyle={{
                                backgroundColor: 'rgba(255, 255, 255, 0.98)',
                                border: '2px solid #7C3AED',
                                borderRadius: '12px',
                                boxShadow: '0 10px 25px -3px rgba(0, 0, 0, 0.1)',
                                padding: '12px 16px',
                                backdropFilter: 'blur(8px)',
                                fontSize: '14px'
                              }}
                            />
                            
                            <ReferenceLine 
                              y={0} 
                              stroke="#1CD4D4" 
                              strokeDasharray="6 4" 
                              strokeWidth={2}
                              strokeOpacity={0.8}
                            />
                            
                            <Area
                              type="monotone"
                              dataKey="cumulativeCashFlow"
                              stroke="none"
                              fill="url(#roiAreaGradient)"
                              fillOpacity={1}
                            />
                            
                            <Line 
                              type="monotone" 
                              dataKey="cumulativeCashFlow" 
                              stroke="url(#lineGradient)"
                              strokeWidth={3}
                              dot={false}
                              strokeLinecap="round"
                              strokeLinejoin="round"
                              activeDot={{ 
                                r: 6, 
                                fill: '#1CD4D4', 
                                strokeWidth: 3, 
                                stroke: '#ffffff'
                              }}
                            />
                            
                            {breakEvenMonth > 0 && (
                              <ReferenceLine 
                                x={breakEvenMonth} 
                                stroke="#1CD4D4" 
                                strokeDasharray="8 4"
                                strokeWidth={3}
                                strokeOpacity={0.9}
                                label={{
                                  value: "POVRAT INVESTICIJE",
                                  position: "topLeft",
                                  offset: 10,
                                  style: { 
                                    fontSize: '12px', 
                                    fontWeight: 'bold', 
                                    fill: '#1CD4D4'
                                  }
                                }}
                              />
                            )}
                          </LineChart>
                        </ResponsiveContainer>
                        
                        {breakEvenMonth > 0 && (
                          <div 
                            className="absolute top-6 bg-gradient-to-r from-lumino-turquoise to-cyan-500 text-white px-3 py-2 rounded-lg shadow-lg animate-bounce"
                            style={{ 
                              left: `${Math.min(85, (breakEvenMonth / 360) * 100 + 15)}%`,
                              transform: 'translateX(-50%)'
                            }}
                          >
                            <div className="text-xs font-bold text-center">
                              🎯 {Math.ceil(breakEvenMonth / 12)}. godina
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}
        </div>
      </main>
    </div>
  );
}