import React, { useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent } from './ui/card';
import { 
  ArrowLeft, 
  Download,
  User,
  FileText,
  Wrench,
  CheckCircle,
  Calculator,
  UserCheck,
  Settings,
  PlayCircle
} from 'lucide-react';
import LuminoLogo from '../imports/lumino-logo.svg';
import { formatQuoteTitle } from '../utils/QuoteIdGenerator';

interface ClientOfferDocumentProps {
  onBack: () => void;
  formData: any;
}

export default function ClientOfferDocument({ onBack, formData }: ClientOfferDocumentProps) {
  const [clientName, setClientName] = useState(formData?.nazivKupca || '');
  const [offerDate, setOfferDate] = useState(
    formData?.datum || new Date().toLocaleDateString('sr-RS', { 
      day: 'numeric', 
      month: 'long',
      year: 'numeric'
    })
  );

  // Export to PDF function
  const exportToPDF = async () => {
    try {
      const printWindow = window.open('', '_blank');
      if (printWindow) {
        const content = document.querySelector('.client-offer-document');
        if (content) {
          printWindow.document.write(`
            <html>
              <head>
                <title>Ponuda - ${clientName || 'Klijent'}</title>
                <style>
                  @page {
                    size: A4 portrait;
                    margin: 0;
                  }
                  body { 
                    margin: 0; 
                    padding: 0; 
                    font-family: Inter, sans-serif;
                    width: 100%;
                    height: 100vh;
                    -webkit-print-color-adjust: exact;
                    color-adjust: exact;
                  }
                  * { 
                    box-sizing: border-box;
                    -webkit-print-color-adjust: exact;
                    color-adjust: exact;
                  }
                  .no-print { display: none !important; }
                  .page-break { page-break-before: always; }
                </style>
              </head>
              <body>
                ${content.outerHTML}
              </body>
            </html>
          `);
          printWindow.document.close();
          printWindow.focus();
          
          setTimeout(() => {
            printWindow.print();
            printWindow.close();
          }, 1000);
        }
      }
    } catch (error) {
      console.error('Greška pri eksportovanju:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header - No Print */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50 no-print">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <div className="h-8 w-32 flex items-center justify-center">
                <img 
                  src={LuminoLogo} 
                  alt="Lumino Logo" 
                  className="h-6 w-auto object-contain"
                />
              </div>
              <Button
                variant="ghost"
                onClick={onBack}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="h-4 w-4" />
                Nazad
              </Button>
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={exportToPDF}
                className="bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white"
              >
                <Download className="h-4 w-4 mr-2" />
                Izvezi PDF
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Document Content */}
      <main className="client-offer-document">
        {/* 1. Cover Page */}
        <section className="min-h-screen relative bg-gradient-to-br from-purple-600 via-purple-700 to-purple-800 overflow-hidden">
          {/* Background Image with Overlay */}
          <div 
            className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-30"
            style={{
              backgroundImage: `url('https://images.unsplash.com/photo-1676337168442-56f47df3972c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xhciUyMHBhbmVsJTIwaW5zdGFsbGF0aW9uJTIwd29ya2VyJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc1NzM1ODM4Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral')`
            }}
          />

          {/* Lumino gradient overlay */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#6736FF]/90 via-purple-700/95 to-[#3CCBFF]/80" />

          <div className="relative z-10 flex flex-col justify-center items-center min-h-screen px-8 py-16 text-center">          
            {/* Logo */}
            <div className="mb-16">
              <div className="bg-white/95 backdrop-blur-lg rounded-2xl p-8 shadow-2xl border border-white/20">
                <img 
                  src={LuminoLogo} 
                  alt="Lumino Logo" 
                  className="w-48 h-auto object-contain"
                />
              </div>
            </div>

            {/* Main Title */}
            <h1 className="text-5xl md:text-6xl lg:text-7xl mb-6 text-white">
              Ponuda | Huawei / Leapton
            </h1>

            {/* Subtitle */}
            <div className="mb-16">
              <div className="text-2xl md:text-3xl lg:text-4xl text-white/90">
                Solarni sistem {formData?.snagaSistema || '51.040'} kWp
              </div>
            </div>

            {/* Client and Date Input Fields */}
            <div className="flex flex-col md:flex-row gap-8 mb-24 max-w-4xl w-full">
              {/* Client Field */}
              <div className="bg-white/20 backdrop-blur-xl rounded-3xl p-8 border border-white/30 flex-1 shadow-2xl">
                <Label htmlFor="client-name" className="text-white/70 text-lg mb-4 block">
                  Klijent
                </Label>
                <Input
                  id="client-name"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="[Ime klijenta]"
                  className="bg-white/20 border-white/30 text-white text-xl placeholder:text-white/50 focus:bg-white/30 h-12"
                />
              </div>

              {/* Date Field */}
              <div className="bg-white/20 backdrop-blur-xl rounded-3xl p-8 border border-white/30 flex-1 shadow-2xl">
                <Label htmlFor="offer-date" className="text-white/70 text-lg mb-4 block">
                  Datum
                </Label>
                <Input
                  id="offer-date"
                  value={offerDate}
                  onChange={(e) => setOfferDate(e.target.value)}
                  className="bg-white/20 border-white/30 text-white text-xl placeholder:text-white/50 focus:bg-white/30 h-12"
                />
              </div>
            </div>

            {/* Footer */}
            <div className="absolute bottom-12 left-1/2 transform -translate-x-1/2">
              <div className="text-white/80 text-xl">
                Powered by Lumino DOO
              </div>
            </div>
          </div>

          {/* Decorative elements */}
          <div className="absolute top-20 right-20 w-32 h-32 bg-white/10 rounded-full blur-2xl"></div>
          <div className="absolute bottom-40 left-20 w-48 h-48 bg-white/5 rounded-full blur-3xl"></div>
          <div className="absolute top-1/3 left-1/4 w-24 h-24 bg-[#3CCBFF]/20 rounded-full blur-xl"></div>
          <div className="absolute bottom-1/3 right-1/4 w-36 h-36 bg-purple-300/20 rounded-full blur-2xl"></div>
        </section>

        {/* 2. Introductory Section */}
        <section className="page-break min-h-screen bg-gray-50 py-16 px-8">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="text-center mb-16">
              <h2 className="text-4xl md:text-5xl text-[#6736FF] mb-8">
                Potpuna usluga
              </h2>
              
              <p className="text-xl md:text-2xl text-gray-700 mb-12 max-w-4xl mx-auto">
                Potpuna usluga uključuje savetovanje, planiranje, montažu i puštanje u rad 
                fotonaponskog sistema konfiguriranog od strane Lumino DOO.
              </p>
            </div>

            {/* 3 Service Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              {/* 1. Savetovanje */}
              <div className="text-center">
                <div className="mb-6">
                  <div className="w-16 h-16 mx-auto bg-[#6736FF] rounded-full flex items-center justify-center shadow-lg">
                    <UserCheck className="h-8 w-8 text-white" />
                  </div>
                </div>
                <h4 className="text-xl mb-4 text-gray-800">
                  Savetovanje
                </h4>
                <p className="text-gray-600 leading-relaxed">
                  Profesionalno savetovanje i planiranje optimalne konfiguracije sistema
                </p>
              </div>

              {/* 2. Montaža */}
              <div className="text-center">
                <div className="mb-6">
                  <div className="w-16 h-16 mx-auto bg-[#3CCBFF] rounded-full flex items-center justify-center shadow-lg">
                    <Wrench className="h-8 w-8 text-white" />
                  </div>
                </div>
                <h4 className="text-xl mb-4 text-gray-800">
                  Montaža
                </h4>
                <p className="text-gray-600 leading-relaxed">
                  Stručna montaža opreme i kompletna instalacija sistema
                </p>
              </div>

              {/* 3. Puštanje u rad */}
              <div className="text-center">
                <div className="mb-6">
                  <div className="w-16 h-16 mx-auto bg-gradient-to-br from-[#6736FF] to-[#3CCBFF] rounded-full flex items-center justify-center shadow-lg">
                    <PlayCircle className="h-8 w-8 text-white" />
                  </div>
                </div>
                <h4 className="text-xl mb-4 text-gray-800">
                  Puštanje u rad
                </h4>
                <p className="text-gray-600 leading-relaxed">
                  Testiranje, kalibracija i puštanje sistema u potpuno funkcionalno stanje
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* 3. Key Services - "Ključ u ruke ponuda" */}
        <section className="min-h-screen bg-white py-16 px-8">
          <div className="max-w-7xl mx-auto">
            {/* Section Title */}
            <div className="text-center mb-16">
              <h3 className="text-4xl md:text-5xl text-gray-800 mb-6">
                Ključ u ruke ponuda
              </h3>
              <p className="text-xl text-gray-600 max-w-3xl mx-auto">
                Naše usluge pokrivaju kompletan ciklus realizacije solarnog sistema
              </p>
            </div>

            {/* 4 Service Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {/* 1. Savetovanje */}
              <Card className="group hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-2xl border-0 bg-gradient-to-br from-gray-50 to-white">
                <CardContent className="p-8 text-center">
                  <div className="mb-6">
                    <div className="w-20 h-20 mx-auto bg-[#6736FF] rounded-full flex items-center justify-center shadow-lg">
                      <UserCheck className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <h4 className="text-xl mb-4 text-gray-800">
                    Savetovanje
                  </h4>
                  <p className="text-gray-600 leading-relaxed">
                    Profesionalno savetovanje i planiranje optimalne konfiguracije sistema
                  </p>
                </CardContent>
              </Card>

              {/* 2. Projektovanje */}
              <Card className="group hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-2xl border-0 bg-gradient-to-br from-gray-50 to-white">
                <CardContent className="p-8 text-center">
                  <div className="mb-6">
                    <div className="w-20 h-20 mx-auto bg-[#3CCBFF] rounded-full flex items-center justify-center shadow-lg">
                      <FileText className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <h4 className="text-xl mb-4 text-gray-800">
                    Projektovanje
                  </h4>
                  <p className="text-gray-600 leading-relaxed">
                    Detaljno projektovanje i tehnička dokumentacija u skladu sa najvišim standardima
                  </p>
                </CardContent>
              </Card>

              {/* 3. Montaža i puštanje u rad */}
              <Card className="group hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-2xl border-0 bg-gradient-to-br from-gray-50 to-white">
                <CardContent className="p-8 text-center">
                  <div className="mb-6">
                    <div className="w-20 h-20 mx-auto bg-gradient-to-br from-[#6736FF] to-[#3CCBFF] rounded-full flex items-center justify-center shadow-lg">
                      <div className="flex items-center justify-center gap-1">
                        <Wrench className="h-5 w-5 text-white" />
                        <PlayCircle className="h-5 w-5 text-white" />
                      </div>
                    </div>
                  </div>
                  <h4 className="text-xl mb-4 text-gray-800">
                    Montaža i puštanje u rad
                  </h4>
                  <p className="text-gray-600 leading-relaxed">
                    Stručna montaža, testiranje i kalibracija sistema za potpuno funkcionalno stanje
                  </p>
                </CardContent>
              </Card>

              {/* 4. Upotrebna dozvola i dokumentacija */}
              <Card className="group hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-2xl border-0 bg-gradient-to-br from-gray-50 to-white">
                <CardContent className="p-8 text-center">
                  <div className="mb-6">
                    <div className="w-20 h-20 mx-auto bg-gradient-to-br from-blue-600 to-[#6736FF] rounded-full flex items-center justify-center shadow-lg">
                      <CheckCircle className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <h4 className="text-xl mb-4 text-gray-800">
                    Upotrebna dozvola i dokumentacija
                  </h4>
                  <p className="text-gray-600 leading-relaxed">
                    Praćenje procesa dokumentacije i obezbeđivanje upotrebne dozvole za legalan i siguran rad
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Bottom CTA Section */}
            <div className="mt-16 text-center">
              <div className="bg-gradient-to-r from-[#6736FF]/10 to-[#3CCBFF]/10 rounded-3xl p-8 border border-purple-200">
                <h4 className="text-2xl text-gray-800 mb-4">
                  Spremni smo da realizujemo vaš projekat
                </h4>
                <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto">
                  Kontaktirajte nas za detaljnu konsultaciju i prilagođenu ponudu 
                  koja odgovara vašim specifičnim potrebama i zahtevima.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
                  <div className="text-[#6736FF]">
                    <Calculator className="h-6 w-6 inline mr-2" />
                    Besplatna procena
                  </div>
                  <div className="text-[#3CCBFF]">
                    <Settings className="h-6 w-6 inline mr-2" />
                    Individualno rešenje
                  </div>
                  <div className="text-purple-600">
                    <User className="h-6 w-6 inline mr-2" />
                    Stručna podrška
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}