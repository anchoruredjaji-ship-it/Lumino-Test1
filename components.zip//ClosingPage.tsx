import React from 'react';
import { Card, CardContent } from './ui/card';
import { Phone, Mail, MapPin, Clock, Star, Users } from 'lucide-react';

export function ClosingPage() {
  const companyData = {
    name: "Lumino Solarni Sistemi",
    address: "Svetosavska 25",
    city: "Novi Sad, Srbija",
    phone: "+381 21 123 456",
    email: "info@luminosolar.rs",
    website: "www.luminosolar.rs"
  };
  const contactInfo = [
    { icon: Phone, label: "Telefon", value: companyData.phone },
    { icon: Mail, label: "Email", value: companyData.email },
    { icon: MapPin, label: "Adresa", value: `${companyData.address}, ${companyData.city}` },
    { icon: Clock, label: "Radno vreme", value: "Ponedeljak - Petak: 08:00 - 16:00" }
  ];

  const achievements = [
    { icon: Star, number: "500+", text: "Zadovoljnih klijenata" },
    { icon: Users, number: "15", text: "Godina iskustva" },
    { icon: Star, number: "98%", text: "Ocena zadovoljstva" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-teal-50 flex flex-col justify-between p-8">
      {/* Header */}
      <div className="text-center mb-12">
        <div className="flex items-center justify-center space-x-4 mb-6">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-teal-600 rounded-full flex items-center justify-center">
            <svg className="w-10 h-10 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
            </svg>
          </div>
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-teal-600 bg-clip-text text-transparent">
              {companyData.name}
            </h1>
            <p className="text-gray-600">Vaš partner za čistu energiju</p>
          </div>
        </div>
        
        <h2 className="text-2xl font-bold text-gray-900 mb-4">
          Hvala vam što razmatrate našu ponudu!
        </h2>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Spremni smo da započnemo vaš put ka energetskoj nezavisnosti i doprinosu očuvanju životne sredine.
        </p>
      </div>

      {/* Main Content */}
      <div className="flex-1">
        <div className="grid lg:grid-cols-2 gap-12 mb-16">
          {/* Contact Information */}
          <Card className="shadow-xl border-purple-100">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Kontakt informacije
              </h3>
              
              <div className="space-y-6">
                {contactInfo.map((contact, index) => (
                  <div key={index} className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                    <div className="w-10 h-10 bg-gradient-to-r from-purple-100 to-teal-100 rounded-full flex items-center justify-center">
                      <contact.icon className="w-5 h-5 text-purple-700" />
                    </div>
                    <div>
                      <div className="font-medium text-gray-900">{contact.label}</div>
                      <div className="text-gray-600">{contact.value}</div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-8 p-4 bg-gradient-to-r from-purple-50 to-teal-50 rounded-lg border border-purple-200">
                <h4 className="font-semibold text-purple-800 mb-2">Besplatna konsultacija</h4>
                <p className="text-sm text-purple-700">
                  Pozovite nas za detaljnu analizu vaših potreba i personalizovanu ponudu.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Why Choose Us */}
          <Card className="shadow-xl border-teal-100">
            <CardContent className="p-8">
              <h3 className="text-2xl font-bold text-gray-900 mb-6 text-center">
                Zašto odabrati nas?
              </h3>
              
              <div className="space-y-6">
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {achievements.map((achievement, index) => (
                    <div key={index} className="text-center p-4 bg-gradient-to-br from-teal-50 to-purple-50 rounded-lg">
                      <achievement.icon className="w-8 h-8 text-teal-600 mx-auto mb-2" />
                      <div className="text-xl font-bold text-teal-700">{achievement.number}</div>
                      <div className="text-xs text-gray-600">{achievement.text}</div>
                    </div>
                  ))}
                </div>
                
                <div className="space-y-4">
                  {[
                    "Besplatna procena i konsultacija",
                    "Premium oprema sa najboljim garancijama",
                    "Profesionalna instalacija i servis",
                    "Transparentno poslovanje i fer cene",
                    "Podrška tokom celog životnog ciklusa"
                  ].map((benefit, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-gradient-to-r from-purple-500 to-teal-500 rounded-full"></div>
                      <span className="text-gray-700">{benefit}</span>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Call to Action */}
        <Card className="shadow-2xl bg-gradient-to-r from-purple-600 to-teal-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">
              Spremni ste za sledeći korak?
            </h3>
            <p className="text-lg mb-6 opacity-90">
              Kontaktirajte nas danas i započnite svoju solarnu priču!
            </p>
            
            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-white/10 backdrop-blur rounded-lg p-6">
                <Phone className="w-8 h-8 mx-auto mb-3 opacity-90" />
                <h4 className="font-semibold mb-2">Pozovite nas</h4>
                <p className="text-lg font-bold">{companyData.phone}</p>
                <p className="text-sm opacity-80">Odmah razgovarajte sa našim stručnjacima</p>
              </div>
              
              <div className="bg-white/10 backdrop-blur rounded-lg p-6">
                <Mail className="w-8 h-8 mx-auto mb-3 opacity-90" />
                <h4 className="font-semibold mb-2">Pošaljite email</h4>
                <p className="text-lg font-bold">{companyData.email}</p>
                <p className="text-sm opacity-80">Odgovorićemo u roku od 2 sata</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <div className="text-center text-sm text-gray-500 mt-12">
        <div className="border-t border-gray-200 pt-6">
          <p className="mb-2">© 2024 {companyData.name}. Sva prava zadržana.</p>
          <p>
            Licencirani izvođač radova | Član Udruženja za obnovljive izvore energije
          </p>
          <p className="mt-2 text-xs">
            Ponuda je validna 30 dana od datuma izdavanja. Cene ne uključuju PDV.
          </p>
        </div>
      </div>
    </div>
  );
}