import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Sun, Leaf, TrendingUp, Award } from 'lucide-react';

export function ProductionAnalysis() {
  const locationData = {
    address: "Industrijska zona bb",
    city: "Subotica",
    orientation: "SE 146°",
    tilt: 15,
    performanceRatio: 93.12,
    degradation: "1% godina 1, zatim 0.4% godišnje"
  };
  
  const productionData = {
    monthlyProduction: [
      { month: 'Januar', production: 2850 },
      { month: 'Februar', production: 3420 },
      { month: 'Mart', production: 4680 },
      { month: 'April', production: 5820 },
      { month: 'Maj', production: 6750 },
      { month: 'Jun', production: 7200 },
      { month: 'Jul', production: 7350 },
      { month: 'Avgust', production: 6890 },
      { month: 'Septembar', production: 5420 },
      { month: 'Oktobar', production: 3950 },
      { month: 'Novembar', production: 2810 },
      { month: 'Decembar', production: 2200 }
    ],
    annualProduction: 58350,
    co2Reduction: 31270
  };
  
  const clientName = "FM Pharm";
  const totalProduction = productionData.annualProduction;
  const avgMonthlyProduction = totalProduction / 12;
  
  // 25-year projection data
  const yearlyProjection = [];
  for (let year = 1; year <= 25; year++) {
    const degradationRate = year === 1 ? 0.01 : 0.004; // 1% first year, then 0.4% annually
    const totalDegradation = year === 1 ? 0.01 : 0.01 + (year - 1) * 0.004;
    const production = totalProduction * (1 - totalDegradation);
    yearlyProjection.push({
      year,
      production: Math.round(production),
      cumulative: yearlyProjection.reduce((sum, p) => sum + p.production, production)
    });
  }

  return (
    <div className="min-h-screen bg-white p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Analiza proizvodnje
          </h1>
          <p className="text-xl text-gray-600">
            Detaljana projekcija energetske proizvodnje za {clientName}
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid md:grid-cols-4 gap-6 mb-12">
          <Card className="text-center bg-gradient-to-br from-yellow-50 to-orange-50 border-orange-200">
            <CardContent className="p-6">
              <Sun className="w-8 h-8 text-orange-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-orange-700">
                {totalProduction.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">kWh godišnje</div>
            </CardContent>
          </Card>
          
          <Card className="text-center bg-gradient-to-br from-green-50 to-teal-50 border-teal-200">
            <CardContent className="p-6">
              <Leaf className="w-8 h-8 text-teal-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-teal-700">
                {productionData.co2Reduction}
              </div>
              <div className="text-sm text-gray-600">kg CO₂ ušteda</div>
            </CardContent>
          </Card>
          
          <Card className="text-center bg-gradient-to-br from-purple-50 to-blue-50 border-blue-200">
            <CardContent className="p-6">
              <TrendingUp className="w-8 h-8 text-blue-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-blue-700">
                {locationData.performanceRatio}%
              </div>
              <div className="text-sm text-gray-600">Performance Ratio</div>
            </CardContent>
          </Card>
          
          <Card className="text-center bg-gradient-to-br from-pink-50 to-purple-50 border-purple-200">
            <CardContent className="p-6">
              <Award className="w-8 h-8 text-purple-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-purple-700">
                {Math.round(avgMonthlyProduction).toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">kWh mesečno</div>
            </CardContent>
          </Card>
        </div>

        {/* Monthly Production Chart */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-2xl text-gray-900 text-center">
              Mesečna proizvodnja električne energije
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={productionData.monthlyProduction}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis 
                  dataKey="month" 
                  stroke="#666"
                  fontSize={12}
                />
                <YAxis 
                  stroke="#666"
                  fontSize={12}
                  tickFormatter={(value) => `${value} kWh`}
                />
                <Tooltip 
                  formatter={(value) => [`${value} kWh`, 'Proizvodnja']}
                  labelStyle={{ color: '#333' }}
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #ddd',
                    borderRadius: '8px'
                  }}
                />
                <Bar 
                  dataKey="production" 
                  fill="url(#gradient)"
                  radius={[4, 4, 0, 0]}
                />
                <defs>
                  <linearGradient id="gradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#7C3AED" />
                    <stop offset="100%" stopColor="#1CD4D4" />
                  </linearGradient>
                </defs>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Location Details */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-gray-900">
                Parametri lokacije
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span className="text-gray-600">Lokacija:</span>
                  <span className="font-medium">{locationData.address}, {locationData.city}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Orijentacija:</span>
                  <span className="font-medium">{locationData.orientation}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Nagib:</span>
                  <span className="font-medium">{locationData.tilt}°</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Performance Ratio:</span>
                  <span className="font-medium">{locationData.performanceRatio}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Degradacija:</span>
                  <span className="font-medium">{locationData.degradation}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl text-gray-900">
                Ekoloski uticaj
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-700 mb-2">
                    {productionData.co2Reduction} kg
                  </div>
                  <div className="text-gray-600">CO₂ ušteda godišnje</div>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div className="bg-green-50 p-4 rounded-lg">
                    <div className="text-lg font-bold text-green-700">
                      {Math.round(productionData.co2Reduction * 25 / 1000)} t
                    </div>
                    <div className="text-sm text-gray-600">CO₂ za 25 godina</div>
                  </div>
                  <div className="bg-blue-50 p-4 rounded-lg">
                    <div className="text-lg font-bold text-blue-700">
                      {Math.round(productionData.co2Reduction / 22)}
                    </div>
                    <div className="text-sm text-gray-600">Ekvivalent stabala</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* 25-Year Production Projection */}
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl text-gray-900 text-center">
              Projekcija proizvodnje za 25 godina
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <LineChart data={yearlyProjection.slice(0, 25)}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis 
                  dataKey="year" 
                  stroke="#666"
                  fontSize={12}
                  tickFormatter={(value) => `God. ${value}`}
                />
                <YAxis 
                  stroke="#666"
                  fontSize={12}
                  tickFormatter={(value) => `${(value/1000).toFixed(0)}k kWh`}
                />
                <Tooltip 
                  formatter={(value, name) => [
                    `${Number(value).toLocaleString()} kWh`, 
                    'Godišnja proizvodnja'
                  ]}
                  labelFormatter={(value) => `Godina ${value}`}
                  contentStyle={{
                    backgroundColor: '#fff',
                    border: '1px solid #ddd',
                    borderRadius: '8px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="production" 
                  stroke="#7C3AED" 
                  strokeWidth={3}
                  dot={{ fill: '#7C3AED', strokeWidth: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
            
            <div className="mt-6 grid md:grid-cols-3 gap-6 text-center">
              <div className="bg-purple-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-purple-700">
                  {Math.round(yearlyProjection.reduce((sum, year) => sum + year.production, 0) / 1000)}
                </div>
                <div className="text-sm text-gray-600">MWh ukupno za 25 godina</div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-green-700">80%</div>
                <div className="text-sm text-gray-600">Zadržana efikasnost posle 25 godina</div>
              </div>
              <div className="bg-blue-50 p-4 rounded-lg">
                <div className="text-2xl font-bold text-blue-700">
                  {Math.round(avgMonthlyProduction * 12 * 25 / 1000)}
                </div>
                <div className="text-sm text-gray-600">MWh životni učinak</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}