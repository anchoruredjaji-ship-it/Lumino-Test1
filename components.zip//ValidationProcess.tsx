import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CheckCircle, FileCheck, Users, Award, Shield, Settings } from 'lucide-react';

export function ValidationProcess() {
  const validationSteps = [
    {
      icon: FileCheck,
      title: "Projektna dokumentacija",
      description: "Sveobuhvatna tehnička dokumentacija sistema",
      details: [
        "3D model solarnog sistema",
        "Električna šema i specifikacije",
        "Statički proračun konstrukije",
        "Studija zaštite od požara"
      ],
      color: "blue"
    },
    {
      icon: Settings,
      title: "Tehnički pregled",
      description: "Detaljan pregled svih komponenti i instalacije",
      details: [
        "Pregled kvaliteta instalacije",
        "Testiranje električnih konekcija",
        "Merenje performansi sistema",
        "Bezbednosni pregled"
      ],
      color: "purple"
    },
    {
      icon: Users,
      title: "Obuka korisnika",
      description: "Kompletno uputstvo za korišćenje i održavanje",
      details: [
        "Rukovanje monitoringom sistema",
        "Osnove održavanja panela",
        "Prepoznavanje problema",
        "Kontakt za tehničku podršku"
      ],
      color: "green"
    },
    {
      icon: Award,
      title: "Sertifikat i garancije",
      description: "Zvanični dokumenti i garancijske isprave",
      details: [
        "Sertifikat o kvalitetu instalacije",
        "Garancijske isprave komponenti",
        "Uputstvo za održavanje",
        "Kontakt podaci za servis"
      ],
      color: "orange"
    }
  ];

  const certifications = [
    { name: "ISO 9001", desc: "Sistem upravljanja kvalitetom" },
    { name: "ISO 14001", desc: "Upravljanje životnom sredinom" },
    { name: "OHSAS 18001", desc: "Bezbednost i zdravlje na radu" },
    { name: "IEC 61215", desc: "Kvalitet solarnih panela" }
  ];

  return (
    <div className="min-h-screen bg-white p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Validacija i puštanje u rad
          </h1>
          <p className="text-xl text-gray-600">
            Rigorozni proces osigurava kvalitet i bezbednost vašeg sistema
          </p>
        </div>

        {/* Quality Promise */}
        <Card className="mb-12 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
          <CardContent className="p-8 text-center">
            <Shield className="w-16 h-16 text-blue-600 mx-auto mb-6" />
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Naša obaveza prema kvalitetu
            </h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto mb-6">
              Svaki sistem prolazi kroz striktnu proceduru validacije pre puštanja u rad. 
              Naš tim sertifikovanih stručnjaka osigurava da vaš sistem radi optimalno i bezbedno.
            </p>
            <div className="flex justify-center space-x-4">
              <Badge className="bg-blue-100 text-blue-800 px-4 py-2">100% testirano</Badge>
              <Badge className="bg-green-100 text-green-800 px-4 py-2">Sertifikovano</Badge>
              <Badge className="bg-purple-100 text-purple-800 px-4 py-2">Garantovano</Badge>
            </div>
          </CardContent>
        </Card>

        {/* Validation Steps */}
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {validationSteps.map((step, index) => {
            const colorClasses = {
              blue: "from-blue-50 to-blue-100 border-blue-200 text-blue-700",
              purple: "from-purple-50 to-purple-100 border-purple-200 text-purple-700", 
              green: "from-green-50 to-green-100 border-green-200 text-green-700",
              orange: "from-orange-50 to-orange-100 border-orange-200 text-orange-700"
            };

            return (
              <Card key={index} className={`bg-gradient-to-br ${colorClasses[step.color as keyof typeof colorClasses]} shadow-lg`}>
                <CardHeader className="pb-4">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm">
                      <step.icon className="w-6 h-6 text-gray-700" />
                    </div>
                    <div>
                      <CardTitle className="text-xl text-gray-900">
                        {step.title}
                      </CardTitle>
                      <p className="text-gray-600 mt-1">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {step.details.map((detail, detailIndex) => (
                      <div key={detailIndex} className="flex items-center space-x-3">
                        <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
                        <span className="text-gray-700">{detail}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Testing Protocol */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-2xl text-gray-900 text-center">
              Protokol testiranja
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-red-600">1</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Električna bezbednost</h3>
                <p className="text-sm text-gray-600">
                  Testiranje izolacije, uzemljenja i zaštite od prenapona
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-yellow-600">2</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Performanse sistema</h3>
                <p className="text-sm text-gray-600">
                  Merenje izlazne snage, efikasnosti i stabilnosti rada
                </p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <span className="text-2xl font-bold text-green-600">3</span>
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">Finalna validacija</h3>
                <p className="text-sm text-gray-600">
                  Kompletna funkcionalna provera i puštanje u rad
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Certifications */}
        <Card className="mb-12 bg-gradient-to-r from-gray-50 to-white">
          <CardHeader>
            <CardTitle className="text-2xl text-gray-900 text-center">
              Sertifikati i standardi
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-center text-gray-600 mb-8">
              Naša kompanija i svi naši proizvodi imaju potrebne sertifikate i odgovaraju najstrožim industrijskim standardima.
            </p>
            
            <div className="grid md:grid-cols-4 gap-6">
              {certifications.map((cert, index) => (
                <div key={index} className="text-center p-4 bg-white rounded-lg shadow-sm border border-gray-200">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Award className="w-6 h-6 text-blue-600" />
                  </div>
                  <h4 className="font-semibold text-gray-900 mb-2">{cert.name}</h4>
                  <p className="text-xs text-gray-600">{cert.desc}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Warranty Information */}
        <Card className="bg-gradient-to-r from-green-100 to-blue-100 border-green-200">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-center text-gray-900 mb-6">
              Sveobuhvatna garancija
            </h3>
            
            <div className="grid md:grid-cols-4 gap-6 mb-8">
              <div className="text-center">
                <div className="text-3xl font-bold text-green-700 mb-2">25</div>
                <div className="text-sm text-gray-600">godina garancije na panele</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-700 mb-2">10</div>
                <div className="text-sm text-gray-600">godina garancije na invertere</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-700 mb-2">5</div>
                <div className="text-sm text-gray-600">godina garancije na radove</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-700 mb-2">∞</div>
                <div className="text-sm text-gray-600">tehnička podrška</div>
              </div>
            </div>

            <div className="bg-white rounded-lg p-6 shadow-sm">
              <h4 className="font-semibold text-gray-900 mb-4 text-center">
                Šta garancija pokriva:
              </h4>
              <div className="grid md:grid-cols-2 gap-4">
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Kvarove na opremi</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Besplatne popravke</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Zamenu neispravnih delova</span>
                  </li>
                </ul>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Godišnji servisni pregled</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>24/7 tehničku podršku</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600" />
                    <span>Monitoring performansi</span>
                  </li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}