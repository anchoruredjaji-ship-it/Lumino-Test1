import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Euro, TrendingDown, Calendar, CheckCircle } from 'lucide-react';

export function FinancialSection() {
  const financialData = {
    totalPrice: 24900,
    pricePerKw: 488,
    paymentOptions: ["Jednokratno plaćanje", "Kredit", "Leasing"]
  };
  const systemPower = 51.04;
  const monthlySavings = Math.round(systemPower * 100 * 0.15); // Estimate
  const paybackPeriod = Math.round(financialData.totalPrice / (monthlySavings * 12 * 10)) / 10;

  return (
    <div className="min-h-screen bg-white p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Finansijska analiza
          </h1>
          <p className="text-xl text-gray-600">
            Transparentni pregled investicije i ušteda
          </p>
        </div>

        {/* Main Investment Card */}
        <Card className="mb-12 border-purple-200 bg-gradient-to-r from-purple-50 to-white">
          <CardHeader>
            <CardTitle className="text-center text-2xl text-purple-700">
              Investicija u vaš solarni sistem
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center mb-8">
              <div className="text-5xl font-bold text-purple-700 mb-2">
                €{financialData.totalPrice.toLocaleString()}
              </div>
              <div className="text-lg text-gray-600">
                €{financialData.pricePerKw}/kWp
              </div>
              <Badge className="mt-4 bg-green-100 text-green-800">
                Bez PDV-a
              </Badge>
            </div>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                <Euro className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <div className="font-semibold">Konkurentna cena</div>
                <div className="text-sm text-gray-600">
                  €{financialData.pricePerKw}/kWp je među najboljim na tržištu
                </div>
              </div>
              <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                <TrendingDown className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <div className="font-semibold">Brz povrat</div>
                <div className="text-sm text-gray-600">
                  Investicija se vraća za {paybackPeriod} godina
                </div>
              </div>
              <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                <CheckCircle className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="font-semibold">Sve uključeno</div>
                <div className="text-sm text-gray-600">
                  Cena uključuje opremu i instalaciju
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment Options */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-xl text-gray-900 flex items-center">
              <Calendar className="w-6 h-6 mr-2 text-purple-600" />
              Opcije plaćanja
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {financialData.paymentOptions.map((option, index) => (
                <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                  <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  <span className="text-gray-700">{option}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Savings Projection */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          <Card className="border-green-200 bg-gradient-to-br from-green-50 to-white">
            <CardHeader>
              <CardTitle className="text-xl text-green-700">
                Uštede kroz vreme
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Mesečna ušteda:</span>
                  <span className="font-bold text-green-700">€{monthlySavings}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Godišnja ušteda:</span>
                  <span className="font-bold text-green-700">€{monthlySavings * 12}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Ušteda za 10 godina:</span>
                  <span className="font-bold text-green-700">€{monthlySavings * 12 * 10}</span>
                </div>
                <div className="flex justify-between items-center border-t pt-4">
                  <span>Ušteda za 25 godina:</span>
                  <span className="font-bold text-2xl text-green-700">
                    €{monthlySavings * 12 * 25}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-gradient-to-br from-blue-50 to-white">
            <CardHeader>
              <CardTitle className="text-xl text-blue-700">
                Povrat investicije
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-blue-700 mb-2">
                  {paybackPeriod} godina
                </div>
                <div className="text-gray-600">
                  Период povrata investicije
                </div>
              </div>
              
              <div className="bg-gray-200 rounded-full h-4 mb-4">
                <div 
                  className="bg-gradient-to-r from-blue-500 to-blue-600 h-4 rounded-full"
                  style={{ width: `${Math.min((25 / paybackPeriod) * 100, 100)}%` }}
                ></div>
              </div>
              
              <p className="text-sm text-gray-600 text-center">
                Nakon {paybackPeriod} godina, sve je čista zarada!
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Additional Benefits */}
        <Card className="bg-gradient-to-r from-orange-50 to-yellow-50 border-orange-200">
          <CardHeader>
            <CardTitle className="text-xl text-orange-700 text-center">
              Dodatne koristi
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6 text-center">
              <div>
                <div className="text-2xl font-bold text-orange-700 mb-2">+15%</div>
                <div className="text-gray-700">Povećanje vrednosti nekretnine</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-green-700 mb-2">0%</div>
                <div className="text-gray-700">Emisija CO₂ tokom rada</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-700 mb-2">∞</div>
                <div className="text-gray-700">Godina besplatne energije sunca</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}