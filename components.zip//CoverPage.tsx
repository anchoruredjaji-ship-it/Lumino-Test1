import React from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function CoverPage() {
  const clientName = "FM Pharm";
  const projectDate = new Date().toLocaleDateString('sr-RS');
  const companyName = "Lumino Solarni Sistemi";
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-white flex flex-col justify-between p-8">
      {/* Header with Logo */}
      <div className="flex justify-between items-start">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-purple-800 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-white" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
            </svg>
          </div>
          <div>
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-purple-800 bg-clip-text text-transparent">
              {companyName}
            </h1>
            <p className="text-sm text-gray-600">Solar Energy Solutions</p>
          </div>
        </div>
        <div className="text-right text-sm text-gray-600">
          <p>Datum: {projectDate}</p>
          <p>Ponuda br: #{Math.floor(Math.random() * 10000)}</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="text-center space-y-8">
        <div className="space-y-4">
          <h1 className="text-5xl font-bold text-gray-900">
            SOLAR PROPOSAL
          </h1>
          <h2 className="text-3xl font-semibold text-purple-700">
            {clientName}
          </h2>
          <p className="text-xl text-gray-600">
            Comprehensive Solar Energy System Design & Installation
          </p>
        </div>

        {/* Hero Image */}
        <div className="flex justify-center">
          <div className="relative">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1726795867795-32bc9872a44a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBzb2xhciUyMHBhbmVscyUyMGluc3RhbGxhdGlvbnxlbnwxfHx8fDE3NTcyNjIzNDB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Solar Panel Installation"
              className="w-96 h-64 object-cover rounded-xl shadow-2xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-purple-900/20 to-transparent rounded-xl" />
          </div>
        </div>

        {/* Call to Action */}
        <div className="bg-white rounded-2xl shadow-lg p-8 max-w-md mx-auto">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">
            Your Path to Clean Energy
          </h3>
          <p className="text-gray-600 mb-6">
            This comprehensive proposal includes system design, financial analysis, and implementation timeline tailored specifically for your needs.
          </p>
          <div className="flex items-center justify-center space-x-2 text-purple-700">
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10.293 15.707a1 1 0 010-1.414L14.586 10l-4.293-4.293a1 1 0 111.414-1.414l5 5a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0z" clipRule="evenodd"/>
              <path fillRule="evenodd" d="M3 10a1 1 0 011-1h10a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd"/>
            </svg>
            <span className="font-medium">Start Your Solar Journey</span>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="text-center text-sm text-gray-500">
        <p>© 2024 {companyName}. Sva prava zadržana.</p>
        <p className="mt-1">Kontakt: info@luminosolar.rs | +381 21 123 456</p>
      </div>
    </div>
  );
}