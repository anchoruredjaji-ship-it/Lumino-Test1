import React, { useState, useRef } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { ArrowLeft, Download, BarChart3, LineChart, PieChart, TrendingUp } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area, BarChart, Bar } from 'recharts';
// Note: html2canvas would be imported here in a real implementation
// import html2canvas from 'html2canvas';

interface ChartGeneratorScreenProps {
  onBack: () => void;
  formData: {
    mesecnaProizvodnja: string;
    snagaSistema: string;
    nazivProjekta: string;
    [key: string]: string;
  };
}

export default function ChartGeneratorScreen({ onBack, formData }: ChartGeneratorScreenProps) {
  const [selectedChart, setSelectedChart] = useState<'area' | 'bar' | 'line'>('area');
  const chartRef = useRef<HTMLDivElement>(null);

  // Parse mesečna proizvodnja data
  const parseMonthlyData = () => {
    // Primer podaci ako nema unesenih podataka
    const defaultData = '1684\n2527\n4527\n6052\n7016\n7685\n7766\n6807\n4966\n3503\n2054\n1284';
    
    const dataToUse = formData.mesecnaProizvodnja || defaultData;
    
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Avg', 'Sep', 'Okt', 'Nov', 'Dec'];
    const values = dataToUse
      .split(/[\n,]/)
      .map(val => parseFloat(val.trim().replace(',', '.')))
      .filter(val => !isNaN(val));

    return months.map((month, index) => ({
      month,
      proizvodnja: values[index] || 0,
      kumulativna: values.slice(0, index + 1).reduce((sum, val) => sum + (val || 0), 0)
    }));
  };

  const data = parseMonthlyData();
  const totalProduction = data.reduce((sum, item) => sum + item.proizvodnja, 0);

  // Export chart as PNG
  const exportChart = async () => {
    if (chartRef.current) {
      try {
        // Mock implementation - in real app, would use html2canvas
        const mockCanvas = document.createElement('canvas');
        mockCanvas.width = 800;
        mockCanvas.height = 400;
        const ctx = mockCanvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, 800, 400);
          ctx.fillStyle = '#7C3AED';
          ctx.font = '20px Inter';
          ctx.fillText('Dijagram mesečne proizvodnje', 50, 50);
          ctx.fillText(`${formData.nazivProjekta || 'Solar sistem'}`, 50, 80);
        }
        
        const link = document.createElement('a');
        link.download = `${formData.nazivProjekta || 'dijagram'}_mesecna_proizvodnja.png`;
        link.href = mockCanvas.toDataURL();
        link.click();
      } catch (error) {
        console.error('Greška pri exportovanju dijagrama:', error);
      }
    }
  };

  const formatTooltip = (value: any, name: string) => {
    if (name === 'proizvodnja') {
      return [`${value.toLocaleString('sr-RS')} kWh`, 'Mesečna proizvodnja'];
    }
    if (name === 'kumulativna') {
      return [`${value.toLocaleString('sr-RS')} kWh`, 'Kumulativna proizvodnja'];
    }
    return [value, name];
  };

  const renderChart = () => {
    const commonProps = {
      data,
      margin: { top: 20, right: 30, left: 20, bottom: 20 }
    };

    switch (selectedChart) {
      case 'area':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart {...commonProps}>
              <defs>
                <linearGradient id="colorProizvodnja" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#7C3AED" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#7C3AED" stopOpacity={0.1}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="month" 
                stroke="#666" 
                fontSize={12}
                tick={{ fill: '#666' }}
              />
              <YAxis 
                stroke="#666" 
                fontSize={12}
                tick={{ fill: '#666' }}
                tickFormatter={(value) => `${(value / 1000).toFixed(1)}k`}
              />
              <Tooltip 
                formatter={formatTooltip}
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Area
                type="monotone"
                dataKey="proizvodnja"
                stroke="#7C3AED"
                strokeWidth={3}
                fill="url(#colorProizvodnja)"
                dot={{ fill: '#7C3AED', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: '#7C3AED', strokeWidth: 2, fill: '#fff' }}
              />
            </AreaChart>
          </ResponsiveContainer>
        );

      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart {...commonProps}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="month" 
                stroke="#666" 
                fontSize={12}
                tick={{ fill: '#666' }}
              />
              <YAxis 
                stroke="#666" 
                fontSize={12}
                tick={{ fill: '#666' }}
                tickFormatter={(value) => `${(value / 1000).toFixed(1)}k`}
              />
              <Tooltip 
                formatter={formatTooltip}
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Bar 
                dataKey="proizvodnja" 
                fill="#7C3AED"
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        );

      case 'line':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart {...commonProps}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey="month" 
                stroke="#666" 
                fontSize={12}
                tick={{ fill: '#666' }}
              />
              <YAxis 
                stroke="#666" 
                fontSize={12}
                tick={{ fill: '#666' }}
                tickFormatter={(value) => `${(value / 1000).toFixed(1)}k`}
              />
              <Tooltip 
                formatter={formatTooltip}
                contentStyle={{ 
                  backgroundColor: '#fff', 
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)'
                }}
              />
              <Line
                type="monotone"
                dataKey="proizvodnja"
                stroke="#7C3AED"
                strokeWidth={3}
                dot={{ fill: '#7C3AED', strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: '#7C3AED', strokeWidth: 2, fill: '#fff' }}
              />
            </LineChart>
          </ResponsiveContainer>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-4">
              <div className="h-8 w-32 bg-gradient-to-r from-purple-600 to-purple-800 rounded flex items-center justify-center text-white font-bold text-sm">
                LuminOne
              </div>
              <Button
                variant="ghost"
                onClick={onBack}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-900"
              >
                <ArrowLeft className="h-4 w-4" />
                Nazad na formu
              </Button>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={exportChart}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-600 to-teal-600 hover:from-purple-700 hover:to-teal-700 text-white rounded-md transition-colors"
              >
                <Download className="h-4 w-4" />
                Izvezi PNG
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-gray-900 mb-2">Kreator dijagrama proizvodnje</h1>
          <p className="text-gray-600">
            Kreirajte i exportujte profesionalne dijagrame mesečne proizvodnje u PNG formatu.
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-4 gap-8">
          {/* Chart Controls */}
          <div className="xl:col-span-1 space-y-6">
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-purple-700">Tip dijagrama</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  variant={selectedChart === 'area' ? 'default' : 'outline'}
                  onClick={() => setSelectedChart('area')}
                  className="w-full justify-start gap-3"
                >
                  <TrendingUp className="h-4 w-4" />
                  Area Chart
                </Button>
                <Button
                  variant={selectedChart === 'bar' ? 'default' : 'outline'}
                  onClick={() => setSelectedChart('bar')}
                  className="w-full justify-start gap-3"
                >
                  <BarChart3 className="h-4 w-4" />
                  Bar Chart
                </Button>
                <Button
                  variant={selectedChart === 'line' ? 'default' : 'outline'}
                  onClick={() => setSelectedChart('line')}
                  className="w-full justify-start gap-3"
                >
                  <LineChart className="h-4 w-4" />
                  Line Chart
                </Button>
              </CardContent>
            </Card>

            {/* Statistics */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-purple-700">Statistike</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">Ukupna godišnja proizvodnja</p>
                  <p className="text-2xl font-bold text-purple-700">
                    {totalProduction.toLocaleString('sr-RS')} kWh
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">Prosečna mesečna proizvodnja</p>
                  <p className="text-xl font-semibold text-gray-900">
                    {data.length > 0 ? Math.round(totalProduction / data.length).toLocaleString('sr-RS') : 0} kWh
                  </p>
                </div>
                <div className="space-y-2">
                  <p className="text-sm text-gray-600">Maksimalna mesečna proizvodnja</p>
                  <p className="text-xl font-semibold text-gray-900">
                    {Math.max(...data.map(d => d.proizvodnja)).toLocaleString('sr-RS')} kWh
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Chart Display */}
          <div className="xl:col-span-3">
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-purple-700">
                    Mesečna proizvodnja - {formData.nazivProjekta || 'Solar sistem'}
                  </CardTitle>
                  <div className="text-sm text-gray-500">
                    {formData.snagaSistema} kWp
                  </div>
                </div>
                {!formData.mesecnaProizvodnja && (
                  <div className="mt-2 p-2 bg-blue-50 rounded-md border border-blue-200">
                    <p className="text-sm text-blue-700">
                      📊 Prikazuju se primer podaci jer nisu uneseni podaci o mesečnoj proizvodnji u formi
                    </p>
                  </div>
                )}
              </CardHeader>
              <CardContent>
                <div ref={chartRef} className="w-full">
                  {renderChart()}
                </div>
              </CardContent>
            </Card>

            {/* Data Preview */}
            <Card className="shadow-sm mt-8">
                <CardHeader>
                  <CardTitle className="text-purple-700">Pregled podataka</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-gray-200">
                          <th className="text-left py-2 font-medium text-gray-900">Mesec</th>
                          <th className="text-right py-2 font-medium text-gray-900">Proizvodnja (kWh)</th>
                          <th className="text-right py-2 font-medium text-gray-900">% od ukupne</th>
                        </tr>
                      </thead>
                      <tbody>
                        {data.map((item, index) => (
                          <tr key={index} className="border-b border-gray-100">
                            <td className="py-2 text-gray-900">{item.month}</td>
                            <td className="py-2 text-right text-gray-700">
                              {item.proizvodnja.toLocaleString('sr-RS')}
                            </td>
                            <td className="py-2 text-right text-gray-600">
                              {totalProduction > 0 ? ((item.proizvodnja / totalProduction) * 100).toFixed(1) : 0}%
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
          </div>
        </div>
      </main>
    </div>
  );
}