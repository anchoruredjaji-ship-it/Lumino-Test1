import React from 'react';
import { 
  ArrowLeft, 
  Download, 
  Users, 
  Wrench,
  ShieldCheck,
  Sun,
  Home,
  Zap,
  FileText,
  Star,
  Battery,
  Cpu,
  Package,
  Check,
  Settings,
  Shield,
  PanelTop,
  Gauge,
  HardHat,
  Plug,
  Cable,
  Building2,
  Lightbulb,
  Factory,
  SquareStack,
  Router,
  Archive,
  Hammer,
  Pickaxe,
  Construction,
  Network,
  MonitorSpeaker,
  Grid3x3,
  RectangleHorizontal,
  CircuitBoard,
  Activity,
  SquareStack,
  Database,
  Layers,
  Box,
  Grid2x2,
  Square,
  LayoutGrid,
  Boxes,
  Component
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { formatQuoteTitle, formatQuoteCode } from '../utils/QuoteIdGenerator';

interface SystemSpecificationScreenProps {
  onBack: () => void;
  formData?: any;
  stavke?: any[];
  artikli?: any[];
  tipKupca?: string;
  napomena?: boolean;
}

export default function SystemSpecificationScreen({ onBack, formData, stavke = [], artikli = [], tipKupca = 'pravno', napomena = false }: SystemSpecificationScreenProps) {
  // Extract data from formData or use defaults
  const sistemData = {
    nazivProjekta: formData?.nazivProjekta || 'Solar Sistem',
    snagaSistema: formData?.snagaSistema || '138',
    nazivKupca: formData?.nazivKupca || 'Klijent',
    datum: formData?.datum || new Date().toLocaleDateString('sr-RS'),
    tipKupca: tipKupca,
    napomena: napomena
  };

  // Use the standardized quote ID generator
  const getQuoteInfo = () => {
    const fullTitle = formatQuoteTitle(formData?.datum);
    const quoteCode = formatQuoteCode(formData?.datum);
    return { fullTitle, quoteCode };
  };

  // Generate dynamic title
  const generateDynamicTitle = () => {
    const power = parseInt(sistemData.snagaSistema) || 138;
    let systemType = '';
    
    if (power >= 100) {
      systemType = 'Huawei SUN2000 | Premium';
    } else if (power >= 50) {
      systemType = 'Huawei SUN2000 | Standard';
    } else {
      systemType = 'Huawei | Residential';
    }
    
    return `${systemType}`;
  };

  const dynamicTitle = generateDynamicTitle();
  const { fullTitle, quoteCode } = getQuoteInfo();

  // Calculate total components and panels
  const aktivneStavke = stavke.filter(stavka => 
    stavka.kolicina && stavka.kolicina !== 'Ne' && stavka.kolicina !== '0'
  );
  
  const ukupnoKomponenti = aktivneStavke.length + 1; // +1 for documentation
  
  // Try to get panel count from solarni-moduli stavka
  const solarniModuliStavka = stavke.find(stavka => 
    stavka.tip === 'solarni-moduli' || stavka.tip.startsWith('artikal-')
  );
  const brojPanela = solarniModuliStavka?.kolicina && 
    solarniModuliStavka.kolicina !== 'Da' && solarniModuliStavka.kolicina !== 'Ne' 
    ? solarniModuliStavka.kolicina : '88';



  // Icon mapping for different component types
  const getComponentIcon = (tip: string) => {
    const iconMap: Record<string, any> = {
      // Solarni moduli - različite ikone za različite tipove panela
      'solarni-moduli': LayoutGrid,
      'solarni-panel': Square,
      'modul': Grid3x3,
      'panel': RectangleHorizontal,
      'fotovoltaik': Layers,
      'solarski': Boxes,
      
      // Inverter - CircuitBoard predstavlja elektronski uređaj/inverter
      'inverter': CircuitBoard,
      'menjac': Activity,
      
      // Baterija - Database predstavlja skladište energije, Battery za male baterije
      'baterija': Database,
      'akumulator': Layers,
      'skladiste': Archive,
      'napojne': Box,
      
      // Ugradnja - različite ikone za specifične vrste ugradnji
      'ugradnja': HardHat,
      'montaza': Construction,
      'instalacija': Hammer,
      
      // EPS priključak - Plug za električne priključke
      'eps': Plug,
      'prikljucak': Plug,
      
      // Konstrukcija - Building2 za konstrukcijske elemente
      'konstrukcija': Building2,
      'nosac': Building2,
      'profil': SquareStack,
      
      // Kablovi - Cable za kabliranje
      'kablovi': Cable,
      'kabloviranje': Cable,
      
      // Projektovanje - FileText za dokumentaciju
      'projektovanje': FileText,
      'projekat': FileText,
      'dokumentacija': FileText,
      
      // Orman/razvodna tabla - različite ikone za električne komponente
      'orman': MonitorSpeaker,
      'razvodni': Network,
      'tabla': Router,
      'kontroler': Cpu,
      
      // Default fallback
      'default': Package
    };
    
    // Dodatno mapiranje po ključnim rečima u tipu
    if (tip.includes('panel')) return Square;
    if (tip.includes('modul')) return Grid3x3;
    if (tip.includes('solar') && !tip.includes('solarski')) return RectangleHorizontal;
    if (tip.includes('solarski')) return Boxes;
    if (tip.includes('fotovoltaik')) return Layers;
    if (tip.includes('inverter')) return CircuitBoard;
    if (tip.includes('menjac')) return Activity;
    if (tip.includes('baterij')) return Database;
    if (tip.includes('akumulator')) return tip.includes('industrijska') ? Archive : Layers;
    if (tip.includes('skladište') || tip.includes('skladiste')) return Archive;
    if (tip.includes('montaž') || tip.includes('montaza')) return Construction;
    if (tip.includes('ugradnja') || tip.includes('instal')) return HardHat;
    if (tip.includes('eps') || tip.includes('priključ') || tip.includes('prikljuc')) return Plug;
    if (tip.includes('konstrukcij') || tip.includes('nosač') || tip.includes('profil')) return Building2;
    if (tip.includes('kabl') || tip.includes('kabel')) return Cable;
    if (tip.includes('projekt') || tip.includes('dokument')) return FileText;
    if (tip.includes('orman')) return MonitorSpeaker;
    if (tip.includes('razvod')) return Network;
    if (tip.includes('tabla')) return Router;
    if (tip.includes('kontroler')) return Cpu;
    
    return iconMap[tip] || iconMap['default'];
  };

  // Color mapping for different component types
  const getComponentIconColor = (tip: string) => {
    const colorMap: Record<string, string> = {
      // Solarni moduli - različite nijanse plave za panele
      'solarni-moduli': 'text-blue-800',
      'solarni-panel': 'text-indigo-600', 
      'modul': 'text-blue-600',
      'panel': 'text-blue-700',
      'fotovoltaik': 'text-indigo-700',
      'solarski': 'text-blue-500',
      
      // Inverter - tamnoplava za elektronske komponente
      'inverter': 'text-slate-700',
      'menjac': 'text-gray-700',
      
      // Baterija - zelena za skladištenje energije
      'baterija': 'text-emerald-600',
      'akumulator': 'text-green-600',
      'skladiste': 'text-teal-600',
      'napojne': 'text-green-700',
      
      // Ugradnja - različite boje za različite tipove radova
      'ugradnja': 'text-amber-700',
      'montaza': 'text-orange-600',
      'instalacija': 'text-yellow-600',
      
      // EPS - crvena za električnu energiju
      'eps': 'text-red-600',
      'prikljucak': 'text-red-600',
      
      // Konstrukcija - siva za metalnu konstrukciju
      'konstrukcija': 'text-slate-600',
      'nosac': 'text-slate-600',
      'profil': 'text-slate-600',
      
      // Kablovi - tamnoplava za kablove
      'kablovi': 'text-indigo-600',
      'kabloviranje': 'text-indigo-600',
      
      // Projektovanje - ljubičasta za LuminOne brand
      'projektovanje': 'text-lumino-purple-start',
      'projekat': 'text-lumino-purple-start',
      'dokumentacija': 'text-lumino-purple-start',
      
      // Orman - različite boje za električne komponente  
      'orman': 'text-lumino-turquoise',
      'razvodni': 'text-blue-700',
      'tabla': 'text-indigo-700',
      'kontroler': 'text-purple-600',
      
      // Default
      'default': 'text-gray-600'
    };
    
    // Dodatno mapiranje po ključnim rečima u tipu
    if (tip.includes('panel')) return 'text-indigo-600';
    if (tip.includes('modul')) return 'text-blue-800';
    if (tip.includes('solar') && !tip.includes('solarski')) return 'text-blue-700';
    if (tip.includes('solarski')) return 'text-blue-500';
    if (tip.includes('fotovoltaik')) return 'text-indigo-700';
    if (tip.includes('inverter')) return 'text-slate-700';
    if (tip.includes('menjac')) return 'text-gray-700';
    if (tip.includes('baterij')) return 'text-emerald-600';
    if (tip.includes('akumulator')) return tip.includes('industrijska') ? 'text-teal-600' : 'text-green-600';
    if (tip.includes('skladište') || tip.includes('skladiste')) return 'text-teal-600';
    if (tip.includes('montaž') || tip.includes('montaza')) return 'text-orange-600';
    if (tip.includes('ugradnja') || tip.includes('instal')) return 'text-amber-700';
    if (tip.includes('eps') || tip.includes('priključ') || tip.includes('prikljuc')) return 'text-red-600';
    if (tip.includes('konstrukcij') || tip.includes('nosač') || tip.includes('profil')) return 'text-slate-600';
    if (tip.includes('kabl') || tip.includes('kabel')) return 'text-indigo-600';
    if (tip.includes('projekt') || tip.includes('dokument')) return 'text-lumino-purple-start';
    if (tip.includes('orman')) return 'text-lumino-turquoise';
    if (tip.includes('razvod')) return 'text-blue-700';
    if (tip.includes('tabla')) return 'text-indigo-700';
    if (tip.includes('kontroler')) return 'text-purple-600';
    
    return colorMap[tip] || colorMap['default'];
  };

  // Helper function to find artikal by ID
  const findArtikalById = (id: string) => {
    return artikli.find(artikal => artikal.id === id);
  };

  // Generate system components from form data
  const getSystemComponents = () => {
    const komponente: any[] = [];

    // Process stavke from props
    stavke.forEach((stavka: any, index: number) => {
      // Skip if no quantity or disabled
      if (!stavka.kolicina || stavka.kolicina === 'Ne' || stavka.kolicina === '0') {
        return;
      }

      let componentData: any = {};
      const ComponentIcon = getComponentIcon(stavka.tip);
      
      // Check if this is an artikal-based selection
      if (stavka.tip.startsWith('artikal-')) {
        const artikalId = stavka.tip.replace('artikal-', '');
        const artikal = findArtikalById(artikalId);
        
        if (artikal) {
          componentData = {
            id: komponente.length + 1,
            naziv: artikal.naziv,
            opis: artikal.opis,
            detaljnjiOpis: `${artikal.opis} - ${artikal.garancija} garancije`,
            garancija: artikal.garancija,
            kolicina: stavka.kolicina === 'Da' || stavka.kolicina === 'Ne' ? stavka.kolicina : `${stavka.kolicina} kom`,
            ikona: getComponentIcon(artikal.tip),
            boja: getComponentIconColor(artikal.tip),
            tip: artikal.tip
          };
        }
      } else {
        // Handle basic component types
        const baseKomponenta = {
          id: komponente.length + 1,
          ikona: ComponentIcon,
          boja: getComponentIconColor(stavka.tip),
          kolicina: stavka.kolicina === 'Da' || stavka.kolicina === 'Ne' ? stavka.kolicina : `${stavka.kolicina} kom`,
          tip: stavka.tip
        };

        switch (stavka.tip) {
          case 'solarni-moduli':
            componentData = {
              ...baseKomponenta,
              naziv: 'Solarni moduli 580W',
              opis: 'Visokoperformansni monokristalin paneli',
              detaljnjiOpis: 'N-type, bifacial technology sa visokom efikasnošću i dugogodišnjom garancijom',
              garancija: '30 godina'
            };
            break;
          case 'inverter':
            const snaga = parseInt(formData?.snagaSistema || '138');
            componentData = {
              ...baseKomponenta,
              naziv: snaga >= 50 ? 'Huawei SUN2000-50KTL' : 'Huawei SUN2000-20KTL',
              opis: `String inverter ${snaga >= 50 ? '50' : '20'} kW snage`,
              detaljnjiOpis: 'Napredni string inverter sa visokom efikasnošću i MPPT optimizacijom',
              garancija: '10 godina'
            };
            break;
          case 'baterija':
            componentData = {
              ...baseKomponenta,
              naziv: 'Litijum baterija 10kWh',
              opis: 'LiFePO4 baterija za skladištenje energije',
              detaljnjiOpis: 'Visokokvalitetna baterija sa dugim ciklusom rada i sigurnim sistemom upravljanja',
              garancija: '10 godina'
            };
            break;
          case 'ugradnja':
            if (stavka.kolicina === 'Da') {
              componentData = {
                ...baseKomponenta,
                naziv: 'Profesionalna ugradnja',
                opis: 'Kompletna instalacija sistema',
                detaljnjiOpis: 'Montaža panela, invertora, kablova i svih komponenti sa finalizacijom sistema',
                garancija: '2 godine'
              };
            }
            break;
          case 'eps':
            if (stavka.kolicina === 'Da') {
              componentData = {
                ...baseKomponenta,
                naziv: 'EPS priključak',
                opis: 'Priključak na elektroenergetsku mrežu',
                detaljnjiOpis: 'Koordinacija sa EPS-om, tehnička dokumentacija i finalno puštanje u rad',
                garancija: '1 godina'
              };
            }
            break;
        }
      }

      // Add component if we have valid data
      if (componentData.naziv) {
        komponente.push(componentData);
      }
    });

    // Always add project documentation
    komponente.push({
      id: komponente.length + 1,
      naziv: 'Projektovanje i dokumentacija',
      opis: 'Tehnička dokumentacija i obučavanje',
      detaljnjiOpis: 'Kompletna tehnička dokumentacija, plan realizacije i detaljno obučavanje korisnika',
      kolicina: '1 paket',
      garancija: '2 godine',
      ikona: FileText,
      boja: getComponentIconColor('dokumentacija'),
      tip: 'dokumentacija'
    });

    return komponente;
  };

  // Helper function to get gradient for component type
  const getComponentGradient = (tip: string) => {
    const gradientMap: Record<string, string> = {
      'solarni-moduli': 'bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise',
      'inverter': 'bg-gradient-to-r from-lumino-turquoise to-blue-500',
      'baterija': 'bg-gradient-to-r from-green-500 to-lumino-turquoise',
      'ugradnja': 'bg-gradient-to-r from-blue-500 to-lumino-purple-start',
      'eps': 'bg-gradient-to-r from-lumino-purple-end to-purple-600',
      'default': 'bg-gradient-to-r from-gray-500 to-gray-600'
    };
    return gradientMap[tip] || gradientMap['default'];
  };

  const komponente = getSystemComponents();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-border sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-6">
              <div className="h-8 w-32 bg-gradient-to-r from-lumino-purple-start to-lumino-purple-end rounded-lg flex items-center justify-center text-white font-semibold text-sm tracking-wide">
                LuminOne
              </div>
              <Button
                variant="ghost"
                onClick={onBack}
                className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
              >
                <ArrowLeft className="h-4 w-4" />
                Nazad na formu
              </Button>
            </div>
            <div className="flex gap-3">
              <Button
                className="flex items-center gap-2 px-6 py-2 bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise hover:shadow-lg transition-all duration-300 text-white rounded-lg font-medium"
              >
                <Download className="h-4 w-4" />
                Preuzmi PDF
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
        <div className="space-y-16">

          {/* Combined Intro Section */}
          <section className="space-y-6">
            {/* Compact Offer Header */}
            <div className="bg-gradient-to-r from-lumino-purple-start/10 via-white to-lumino-turquoise/10 p-6 rounded-xl border border-lumino-purple-start/20 shadow-lg">
              <div className="space-y-6">
                {/* Main Header */}
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-3">
                      <h1 className="text-2xl font-bold text-lumino-purple-start">
                        <span className="text-lumino-purple-start">Ponuda</span>
                        <span className="mx-2 text-lumino-turquoise">•</span>
                        <span className="text-lumino-purple-end">{quoteCode}</span>
                      </h1>
                      <div className="h-px bg-lumino-purple-start/30 flex-1 hidden sm:block mx-3"></div>
                      <Badge variant="outline" className="text-base px-3 py-1 border-lumino-turquoise/40 text-lumino-turquoise bg-lumino-turquoise/10 font-semibold self-start sm:self-center">
                        {dynamicTitle}
                      </Badge>
                    </div>
                    <p className="text-muted-foreground leading-relaxed max-w-2xl">
                      Kompletno solarno rešenje prilagođeno vašim potrebama.
                    </p>
                  </div>
                  <div className="flex flex-col gap-3 text-center lg:text-right">
                    <div className="flex flex-col gap-2">
                      <Badge variant="outline" className="text-xl px-4 py-2 border-lumino-purple-start/30 text-lumino-purple-start bg-lumino-purple-start/10 font-bold">
                        {sistemData.snagaSistema} kWp
                      </Badge>
                      <div className="text-sm text-muted-foreground">
                        {sistemData.nazivProjekta || 'Solar Sistem'}
                      </div>
                    </div>
                    <div className="text-xs text-lumino-purple-start/70 bg-lumino-purple-start/5 px-3 py-1 rounded-full">
                      {sistemData.datum}
                    </div>
                  </div>
                </div>

                {/* Compact Info Grid */}
                <div className="bg-white/60 backdrop-blur-sm rounded-lg p-4 border border-lumino-purple-start/10">
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 text-center">
                    <div className="space-y-1">
                      <div className="text-base font-bold text-lumino-purple-start">{sistemData.tipKupca === 'pravno' ? '30' : '25'} god</div>
                      <div className="text-xs text-muted-foreground">Garancija</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-base font-bold text-lumino-turquoise">Huawei</div>
                      <div className="text-xs text-muted-foreground">Inverter</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-base font-bold text-lumino-purple-start">
                        {parseInt(sistemData.snagaSistema) >= 100 ? 'Premium' : 
                         parseInt(sistemData.snagaSistema) >= 50 ? 'Standard' : 'Residential'}
                      </div>
                      <div className="text-xs text-muted-foreground">Tip sistema</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-base font-bold text-lumino-purple-start">{sistemData.nazivKupca || 'Klijent'}</div>
                      <div className="text-xs text-muted-foreground">Kupac</div>
                    </div>
                  </div>
                </div>

                {/* Mini Services */}
                <div className="border-t border-lumino-purple-start/20 pt-4">
                  <h3 className="text-center text-base font-semibold text-lumino-purple-start mb-4">Usluge ključ u ruke</h3>
                  <div className="grid grid-cols-4 gap-3">
                    <div className="text-center">
                      <div className="w-8 h-8 mx-auto mb-2 rounded-lg bg-lumino-purple-start/10 flex items-center justify-center">
                        <Users className="h-4 w-4 text-lumino-purple-start" />
                      </div>
                      <div className="text-xs text-muted-foreground">Savetovanje</div>
                    </div>
                    <div className="text-center">
                      <div className="w-8 h-8 mx-auto mb-2 rounded-lg bg-lumino-turquoise/10 flex items-center justify-center">
                        <FileText className="h-4 w-4 text-lumino-turquoise" />
                      </div>
                      <div className="text-xs text-muted-foreground">Projektovanje</div>
                    </div>
                    <div className="text-center">
                      <div className="w-8 h-8 mx-auto mb-2 rounded-lg bg-lumino-purple-start/10 flex items-center justify-center">
                        <Wrench className="h-4 w-4 text-lumino-purple-start" />
                      </div>
                      <div className="text-xs text-muted-foreground">Montaža</div>
                    </div>
                    <div className="text-center">
                      <div className="w-8 h-8 mx-auto mb-2 rounded-lg bg-lumino-turquoise/10 flex items-center justify-center">
                        <ShieldCheck className="h-4 w-4 text-lumino-turquoise" />
                      </div>
                      <div className="text-xs text-muted-foreground">Podrška</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* Components from Stavke Section */}
          <section className="space-y-12">
            <div className="text-center space-y-4">
              <h2 className="text-3xl font-semibold bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise bg-clip-text text-transparent">
                Komponente sistema
              </h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Detaljni pregled svih komponenti uključenih u vaš solarni sistem
              </p>
            </div>

            {komponente.length > 0 ? (
              <div className="space-y-8">

                {/* Traditional Table with Modern Styling */}
                <div className="bg-white rounded-xl shadow-lg border border-gray-200 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full border-collapse">
                      <thead>
                        <tr className="bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise text-white">
                          <th className="px-4 py-4 text-left text-sm font-semibold w-16">
                            Poz.
                          </th>
                          <th className="px-4 py-4 text-left text-sm font-semibold">
                            Opis
                          </th>
                          <th className="px-4 py-4 text-center text-sm font-semibold w-24">
                            Slika
                          </th>
                          <th className="px-4 py-4 text-center text-sm font-semibold w-20">
                            J.M.
                          </th>
                          <th className="px-4 py-4 text-center text-sm font-semibold w-20">
                            Kol.
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {komponente.map((komponenta, index) => {
                          // Find corresponding artikal for image
                          let slikaUrl = null;
                          if (komponenta.tip?.startsWith('artikal-')) {
                            const artikalId = komponenta.tip.replace('artikal-', '');
                            const artikal = findArtikalById(artikalId);
                            slikaUrl = artikal?.slika;
                          }

                          return (
                            <tr key={komponenta.id} className="border-b border-gray-200 hover:bg-gradient-to-r hover:from-lumino-purple-start/5 hover:to-lumino-turquoise/5 transition-colors duration-200">
                              <td className="px-4 py-6 text-center text-sm font-medium text-lumino-purple-start">
                                {index + 1}.
                              </td>
                              <td className="px-4 py-6">
                                <div className="space-y-2">
                                  <h4 className="font-semibold text-foreground text-base">
                                    {komponenta.naziv}
                                  </h4>
                                  <p className="text-sm text-lumino-turquoise font-medium">
                                    {komponenta.opis}
                                  </p>
                                  <div className="text-xs text-muted-foreground leading-relaxed">
                                    {komponenta.detaljnjiOpis?.split('\n').map((line, i) => (
                                      <div key={i} className="mb-1">
                                        {line.trim().startsWith('•') ? (
                                          <div className="flex items-start gap-2">
                                            <span className="text-lumino-turquoise">•</span>
                                            <span>{line.trim().slice(1).trim()}</span>
                                          </div>
                                        ) : (
                                          line.trim()
                                        )}
                                      </div>
                                    ))}
                                  </div>
                                  {komponenta.garancija && (
                                    <div className="mt-2">
                                      <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-300">
                                        Garancija: {komponenta.garancija}
                                      </Badge>
                                    </div>
                                  )}
                                </div>
                              </td>
                              <td className="px-2 py-6 text-center">
                                {slikaUrl ? (
                                  <div className="w-16 h-12 mx-auto bg-gray-100 rounded-lg border-2 border-lumino-purple-start/20 overflow-hidden shadow-sm">
                                    <img 
                                      src={slikaUrl} 
                                      alt={komponenta.naziv}
                                      className="w-full h-full object-cover"
                                    />
                                  </div>
                                ) : (
                                  <div className="w-16 h-12 mx-auto bg-gradient-to-br from-gray-50 to-white rounded-lg border-2 border-gray-200 flex items-center justify-center shadow-sm hover:shadow-md transition-shadow">
                                    <komponenta.ikona className={`h-7 w-7 ${komponenta.boja || 'text-lumino-purple-start'}`} />
                                  </div>
                                )}
                              </td>
                              <td className="px-4 py-6 text-center text-sm font-medium text-foreground">
                                {(() => {
                                  if (komponenta.tip?.startsWith('artikal-')) {
                                    const artikalId = komponenta.tip.replace('artikal-', '');
                                    const artikal = findArtikalById(artikalId);
                                    return artikal?.jedinicaMere || 'kom.';
                                  }
                                  return 'kom.';
                                })()}
                              </td>
                              <td className="px-4 py-6 text-center">
                                <Badge variant="outline" className="bg-lumino-turquoise/10 text-lumino-turquoise border-lumino-turquoise/30 font-semibold">
                                  {komponenta.kolicina}
                                </Badge>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Modern Footer with Traditional Info */}
                <div className="bg-gradient-to-r from-gray-50 to-white rounded-xl border border-gray-200 shadow-lg overflow-hidden">
                  <div className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-2">
                        <h4 className="font-semibold text-lumino-purple-start">Način plaćanja:</h4>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <p>50% avans pre isporuke opreme na lokaciju</p>
                          <p>50% nakon puštanja elektrane u rad</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-semibold text-lumino-purple-start">Valuta plaćanja:</h4>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <p>Uplate u dinarima, kurs se obračunava po srednjem</p>
                          <p>kursu NBS na dan plaćanja.</p>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-semibold text-lumino-purple-start">Vreme realizacije projekta:</h4>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <p>Oprema se nalazi na stanju, moguća je realizacija u</p>
                          <p>roku od 10 dana od prihvatanja ponude.</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Total Price Section */}
                  <div className="bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise p-4">
                    <div className="text-center text-white">
                      <p className="text-lg font-semibold">
                        Ukupna cena sistema ključ u ruke, bez PDV-a (EUR): 24.900,00 €
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <Card className="shadow-sm border border-border">
                <CardContent className="p-12 text-center">
                  <Package className="h-16 w-16 mx-auto mb-4 text-muted-foreground/50" />
                  <h3 className="text-xl font-semibold text-muted-foreground mb-2">Nema aktivnih komponenti</h3>
                  <p className="text-muted-foreground mb-4">
                    Dodajte komponente u glavnoj formi (sekcija "Stavke") da biste videli specifikaciju sistema
                  </p>
                  <div className="text-left text-sm text-muted-foreground bg-muted/50 p-4 rounded-lg max-w-md mx-auto">
                    <p className="font-medium mb-2">Trenutno stanje stavki:</p>
                    <ul className="space-y-1">
                      {stavke.map((stavka, index) => (
                        <li key={stavka.id} className="flex justify-between">
                          <span>{stavka.tip}:</span>
                          <span className={stavka.kolicina && stavka.kolicina !== 'Ne' && stavka.kolicina !== '0' ? 'text-green-600' : 'text-red-500'}>
                            {stavka.kolicina || 'Nije uneto'}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
              </Card>
            )}

          </section>
        </div>
      </main>
    </div>
  );
}