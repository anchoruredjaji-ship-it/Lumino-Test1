import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Settings, Zap, Battery, Shield } from 'lucide-react';

export function SystemSpecification() {
  const systemData = {
    totalPower: 51.04,
    panelCount: 124,
    panelType: "Leapton LP182*182-M-78-H-450M",
    panelPower: 450,
    inverterType: "Huawei SUN2000-50KTL-M3",
    inverterCount: 1,
    inverterPower: 50,
    rackingSystem: "Aluminijumski sistem za ravni krov",
    warranty: "25 godina na panele, 10 godina na invertere"
  };
  const specifications = [
    {
      icon: Settings,
      title: "Solarni paneli",
      details: [
        { label: "Model", value: systemData.panelType },
        { label: "Snaga po panelu", value: `${systemData.panelPower}W` },
        { label: "Broj panela", value: systemData.panelCount.toString() },
        { label: "Ukupna snaga", value: `${systemData.totalPower} kWp` }
      ]
    },
    {
      icon: Zap,
      title: "Inverter",
      details: [
        { label: "Model", value: systemData.inverterType },
        { label: "Broj invertera", value: systemData.inverterCount.toString() },
        { label: "Snaga invertera", value: `${systemData.inverterPower} kW` },
        { label: "Efikasnost", value: "97.5%" }
      ]
    },
    {
      icon: Battery,
      title: "Montažni sistem",
      details: [
        { label: "Tip", value: systemData.rackingSystem },
        { label: "Material", value: "Aluminijum" },
        { label: "Otpornost na vetar", value: "250 km/h" },
        { label: "Garancija", value: "15 godina" }
      ]
    },
    {
      icon: Shield,
      title: "Garancija i kvalitet",
      details: [
        { label: "Garancija panela", value: "25 godina" },
        { label: "Garancija invertera", value: "10 godina" },
        { label: "Garancija radova", value: "2 godine" },
        { label: "Servisna podrška", value: "Doživotna" }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Specifikacija sistema
          </h1>
          <p className="text-xl text-gray-600">
            Detaljni pregled komponenti vašeg solarnog sistema
          </p>
          <div className="mt-6">
            <Badge variant="outline" className="text-lg px-4 py-2 border-purple-300 text-purple-700">
              Ukupna snaga: {systemData.totalPower} kWp
            </Badge>
          </div>
        </div>

        {/* System Overview Card */}
        <Card className="mb-12 border-purple-200 bg-gradient-to-r from-purple-50 to-white">
          <CardHeader>
            <CardTitle className="text-2xl text-purple-700 text-center">
              Pregled sistema
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-purple-700">{systemData.panelCount}</div>
                <div className="text-gray-600">Solarni paneli</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-teal-700">{systemData.inverterCount}</div>
                <div className="text-gray-600">Inverter</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-700">{systemData.totalPower}</div>
                <div className="text-gray-600">kWp ukupno</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-700">25</div>
                <div className="text-gray-600">godina garancije</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Detailed Specifications */}
        <div className="grid lg:grid-cols-2 gap-8">
          {specifications.map((spec, index) => (
            <Card key={index} className="shadow-lg hover:shadow-xl transition-shadow">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-gradient-to-r from-purple-100 to-teal-100 rounded-lg flex items-center justify-center">
                    <spec.icon className="w-5 h-5 text-purple-700" />
                  </div>
                  <span className="text-xl text-gray-900">{spec.title}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {spec.details.map((detail, detailIndex) => (
                    <div key={detailIndex} className="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                      <span className="text-gray-600">{detail.label}:</span>
                      <span className="font-medium text-gray-900">{detail.value}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Performance Highlights */}
        <Card className="mt-12 bg-gradient-to-br from-green-50 to-white border-green-200">
          <CardHeader>
            <CardTitle className="text-2xl text-green-700 text-center">
              Očekivane performanse
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-2xl font-bold text-green-700 mb-2">
                  {Math.round(systemData.totalPower * 1200)} kWh
                </div>
                <div className="text-gray-600">Godišnja proizvodnja</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-blue-700 mb-2">85%</div>
                <div className="text-gray-600">Efikasnost sistema</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-700 mb-2">
                  {Math.round(systemData.totalPower * 1200 * 0.5)} t
                </div>
                <div className="text-gray-600">CO₂ ušteda godišnje</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}