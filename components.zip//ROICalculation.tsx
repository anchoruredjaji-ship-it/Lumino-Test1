import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';

import { TrendingUp, DollarSign, Calendar, Target } from 'lucide-react';

interface ROICalculationProps {
  annualProduction?: string;
  electricityPrice?: string;
  degradationAfter30?: string;
  systemPrice?: string;
}

export function ROICalculation({ 
  annualProduction = '55870', 
  electricityPrice = '0.158',
  degradationAfter30 = '20',
  systemPrice = '85000'
}: ROICalculationProps) {
  
  // Calculate degradation parameters
  const degradationPercent = parseFloat(degradationAfter30) / 100; // Convert to decimal
  const annualDegradationRate = degradationPercent / 30; // Linear degradation over 30 years
  const electricityPricePerKwh = parseFloat(electricityPrice);
  const initialProduction = parseFloat(annualProduction);
  const totalSystemCost = parseFloat(systemPrice);
  
  const yearlyBreakdown = [];
  const growthRate = 0.03; // 3% annual electricity price increase
  let cumulativeSavings = 0;
  
  for (let year = 1; year <= 30; year++) {
    // Calculate production with degradation (linear degradation)
    const productionEfficiency = 1 - (annualDegradationRate * (year - 1));
    const adjustedProduction = initialProduction * productionEfficiency;
    
    // Calculate electricity price with inflation
    const adjustedElectricityPrice = electricityPricePerKwh * Math.pow(1 + growthRate, year - 1);
    
    // Calculate savings for this year
    const yearlySavings = adjustedProduction * adjustedElectricityPrice;
    cumulativeSavings += yearlySavings;
    
    yearlyBreakdown.push({
      year,
      production: Math.round(adjustedProduction),
      electricityPrice: adjustedElectricityPrice,
      savings: Math.round(yearlySavings),
      cumulative: Math.round(cumulativeSavings),
      efficiency: Math.round(productionEfficiency * 100)
    });
  }
  
  // Calculate payback period
  let paybackYear = 0;
  for (let i = 0; i < yearlyBreakdown.length; i++) {
    if (yearlyBreakdown[i].cumulative >= totalSystemCost) {
      paybackYear = i + 1;
      break;
    }
  }
  
  const roiData = {
    paybackPeriod: paybackYear > 0 ? `${paybackYear} ${paybackYear === 1 ? 'godina' : 'godina'}` : "Više od 30 godina",
    firstYearSavings: yearlyBreakdown[0]?.savings || 0,
    annualSavings: Math.round(yearlyBreakdown.slice(0, 5).reduce((sum, year) => sum + year.savings, 0) / 5), // Average of first 5 years
    twentyFiveYearSavings: yearlyBreakdown[24]?.cumulative || 0,
    thirtyYearSavings: yearlyBreakdown[29]?.cumulative || 0,
    electricityPrice: electricityPricePerKwh,
    degradationAfter30: parseFloat(degradationAfter30),
    totalSystemCost
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-white p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            ROI kalkulacija
          </h1>
          <p className="text-xl text-gray-600">
            Detaljana finansijska analiza povrata investicije sa kalkuliranom degradacijom
          </p>
        </div>

        {/* Key ROI Metrics */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          <Card className="text-center bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardContent className="p-6">
              <Target className="w-8 h-8 text-green-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-green-700">
                {roiData.paybackPeriod}
              </div>
              <div className="text-sm text-gray-600">Povrat investicije</div>
            </CardContent>
          </Card>
          
          <Card className="text-center bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardContent className="p-6">
              <DollarSign className="w-8 h-8 text-blue-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-blue-700">
                €{roiData.firstYearSavings.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Prva godina ušteda</div>
            </CardContent>
          </Card>
          
          <Card className="text-center bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardContent className="p-6">
              <TrendingUp className="w-8 h-8 text-purple-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-purple-700">
                €{roiData.annualSavings.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">Prosečna godišnja ušteda</div>
            </CardContent>
          </Card>
          
          <Card className="text-center bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardContent className="p-6">
              <Calendar className="w-8 h-8 text-orange-600 mx-auto mb-3" />
              <div className="text-2xl font-bold text-orange-700">
                €{roiData.thirtyYearSavings.toLocaleString()}
              </div>
              <div className="text-sm text-gray-600">30 godina ukupno</div>
            </CardContent>
          </Card>
        </div>

        {/* ROI Breakdown */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-2xl text-gray-900 text-center">
              Detaljna finansijska analiza sa degradacijom
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Investment Recovery Chart */}
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6">
                  Povrat investicije kroz godine
                </h3>
                <div className="space-y-3">
                  {[1, 3, 5, 7, 10, 15, 20, 25, 30].map(year => {
                    const data = yearlyBreakdown[year - 1];
                    const isPaybackPeriod = year <= paybackYear;
                    
                    return (
                      <div key={year} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Badge 
                            variant={isPaybackPeriod ? "default" : "secondary"}
                            className={isPaybackPeriod ? "bg-orange-100 text-orange-800" : "bg-green-100 text-green-800"}
                          >
                            Godina {year}
                          </Badge>
                          <span className="text-gray-600">Kumulativna ušteda:</span>
                          <span className="text-xs text-gray-500">({data?.efficiency}% efikasnost)</span>
                        </div>
                        <div className="text-lg font-bold text-gray-900">
                          €{data?.cumulative.toLocaleString()}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Annual Savings Projection with Degradation */}
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6">
                  Godišnje uštede (sa degradacijom i rastom cena)
                </h3>
                <div className="space-y-3">
                  {[1, 5, 10, 15, 20, 25, 30].map(year => {
                    const data = yearlyBreakdown[year - 1];
                    
                    return (
                      <div key={year} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Badge variant="outline" className="border-purple-300 text-purple-700">
                            Godina {year}
                          </Badge>
                          <span className="text-gray-600">Proizvodnja: {data?.production.toLocaleString()} kWh</span>
                        </div>
                        <div className="text-lg font-bold text-purple-700">
                          €{data?.savings.toLocaleString()}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Key Assumptions */}
        <Card className="mb-12">
          <CardHeader>
            <CardTitle className="text-xl text-gray-900">
              Pretpostavke kalkulacije
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-8">
              <div className="space-y-4">
                <h4 className="font-semibold text-gray-900">Finansijske pretpostavke:</h4>
                <ul className="space-y-2 text-gray-600">
                  <li>• Početna cena električne energije: €{roiData.electricityPrice.toFixed(3)}/kWh</li>
                  <li>• Godišnji rast cene energije: 3%</li>
                  <li>• Degradacija panela nakon 30 godina: {roiData.degradationAfter30}%</li>
                  <li>• Godišnja degradacija: {(roiData.degradationAfter30/30).toFixed(2)}% linearno</li>
                  <li>• Početna godišnja proizvodnja: {initialProduction.toLocaleString()} kWh</li>
                  <li>• Ukupna cena sistema: €{totalSystemCost.toLocaleString()}</li>
                  <li>• Očekivani radni vek: 30+ godina</li>
                </ul>
              </div>
              <div className="space-y-4">
                <h4 className="font-semibold text-gray-900">Dodatne koristi:</h4>
                <ul className="space-y-2 text-gray-600">
                  <li>• Povećanje vrednosti nekretnine: 10-15%</li>
                  <li>• Nezavisnost od rasta cena energije</li>
                  <li>• Pozitivan uticaj na životnu sredinu</li>
                  <li>• Mogućnost učešća u programima podsticaja</li>
                  <li>• Stabilnost i predvidljivost troškova energije</li>
                </ul>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ROI Summary */}
        <Card className="bg-gradient-to-r from-green-100 to-blue-100 border-green-200">
          <CardContent className="p-8">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-gray-900 mb-6">
                Rezime investicije sa kalkuliranom degradacijom
              </h3>
              
              <div className="grid md:grid-cols-3 gap-8">
                <div>
                  <div className="text-3xl font-bold text-green-700 mb-2">
                    {Math.round((roiData.thirtyYearSavings / totalSystemCost) * 100)}%
                  </div>
                  <div className="text-gray-600">Ukupni povrat na investiciju (30 godina)</div>
                </div>
                
                <div>
                  <div className="text-3xl font-bold text-blue-700 mb-2">
                    €{Math.round(roiData.thirtyYearSavings / 30).toLocaleString()}
                  </div>
                  <div className="text-gray-600">Prosečna godišnja ušteda</div>
                </div>
                
                <div>
                  <div className="text-3xl font-bold text-purple-700 mb-2">
                    {yearlyBreakdown[29]?.efficiency}%
                  </div>
                  <div className="text-gray-600">Efikasnost nakon 30 godina</div>
                </div>
              </div>
              
              <div className="mt-8 p-6 bg-white rounded-lg shadow-sm">
                <p className="text-lg text-gray-700">
                  <strong>Zaključak:</strong> Vaša investicija u solarni sistem se isplati već nakon{' '}
                  <span className="text-green-700 font-bold">{roiData.paybackPeriod}</span>, 
                  a tokom sledećih 30 godina ostvarićete ukupnu uštedu od{' '}
                  <span className="text-green-700 font-bold">€{roiData.thirtyYearSavings.toLocaleString()}</span>.
                  Kalkulacija uključuje realnu degradaciju panela od {roiData.degradationAfter30}% nakon 30 godina, 
                  što znači da će sistem i dalje proizvoditi {yearlyBreakdown[29]?.efficiency}% početne snage.
                </p>

              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}