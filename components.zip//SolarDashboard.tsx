import React from 'react';
import { 
  MapPin, 
  RotateCcw, 
  TrendingUp, 
  BarChart3, 
  Zap, 
  ArrowLeft,
  Download,
  Leaf,
  Snowflake,
  Flower,
  Sun,
  Leaf as LeafFall
} from 'lucide-react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  ResponsiveContainer, 
  Cell,
  Tooltip
} from 'recharts';
import { Button } from './ui/button';

// UI Components - Card
interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
}

const Card: React.FC<CardProps> = ({ className = '', children, ...props }) => (
  <div 
    className={`rounded-xl border bg-card text-card-foreground shadow-sm ${className}`} 
    {...props}
  >
    {children}
  </div>
);

const CardHeader: React.FC<CardProps> = ({ className = '', children, ...props }) => (
  <div className={`flex flex-col space-y-1.5 p-6 ${className}`} {...props}>
    {children}
  </div>
);

const CardTitle: React.FC<CardProps> = ({ className = '', children, ...props }) => (
  <h3 className={`text-2xl font-semibold leading-none tracking-tight ${className}`} {...props}>
    {children}
  </h3>
);

const CardContent: React.FC<CardProps> = ({ className = '', children, ...props }) => (
  <div className={`p-6 pt-0 ${className}`} {...props}>
    {children}
  </div>
);

// Props interface for the main component
interface SolarDashboardProps {
  onBack: () => void;
  formData?: any;
}

// Header Component
const Header: React.FC<{ onBack: () => void; formData?: any }> = ({ onBack, formData }) => {
  return (
    <div className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-4">
            <button
              onClick={onBack}
              className="flex items-center gap-2 text-gray-600 hover:text-gray-900 px-3 py-2 rounded-md hover:bg-gray-100 transition-colors"
            >
              <ArrowLeft className="h-4 w-4" />
              Nazad na formu
            </button>
            <div>
              <h1 className="text-2xl font-semibold text-gray-900">Analiza proizvodnje</h1>
              <p className="text-gray-600 mt-1">{formData?.nazivProjekta || 'FM Pharm'}</p>
            </div>
          </div>
          <Button className="bg-gray-800 hover:bg-gray-900 text-white">
            <Download className="h-4 w-4 mr-2" />
            Preuzmi PDF
          </Button>
        </div>
      </div>
    </div>
  );
};

// Summary Cards Component
const SummaryCards: React.FC<{ formData?: any }> = ({ formData }) => {
  // Calculate totals from monthly data or use defaults
  const getMonthlyData = () => {
    const defaultValues = [2850, 3200, 4500, 5800, 6900, 7200, 7350, 6800, 5400, 4100, 3200, 2800];
    let monthlyProduction = defaultValues;
    
    if (formData?.mesecnaProizvodnja) {
      // Parse monthly production data - ignore commas and dots as they are thousands separators
      const values = formData.mesecnaProizvodnja
        .split(/[\n]/)
        .map((val: string) => {
          // Remove all commas and dots, then parse as integer
          const cleanedVal = val.trim().replace(/[,.]/g, '');
          return parseInt(cleanedVal) || 0;
        })
        .filter((val: number) => val > 0);
      
      if (values.length >= 12) {
        monthlyProduction = values.slice(0, 12);
      }
    }
    
    return monthlyProduction;
  };

  const monthlyData = getMonthlyData();
  const totalProduction = monthlyData.reduce((sum, val) => sum + val, 0);
  
  // Calculate CO2 savings (approximate: 0.53 kg CO2 per kWh)
  const co2Savings = Math.round(totalProduction * 0.53);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
      {/* Godišnja proizvodnja */}
      <Card className="bg-gradient-to-br from-teal-400 to-teal-600 text-white border-0 shadow-lg">
        <CardContent className="p-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <TrendingUp className="h-8 w-8" />
                <h3 className="text-xl font-medium">Godišnja proizvodnja</h3>
              </div>
              <p className="text-4xl font-bold mb-2">{totalProduction.toLocaleString('sr-RS')}</p>
              <p className="text-teal-100 text-lg">kWh</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Smanjenje CO₂ */}
      <Card className="bg-gradient-to-br from-green-400 to-green-600 text-white border-0 shadow-lg">
        <CardContent className="p-8">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-3 mb-3">
                <Leaf className="h-8 w-8" />
                <h3 className="text-xl font-medium">Smanjenje CO₂</h3>
              </div>
              <p className="text-4xl font-bold mb-2">{co2Savings.toLocaleString('sr-RS')}</p>
              <p className="text-green-100 text-lg">kg godišnje</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

// Seasonal Analysis Component
const SeasonalAnalysis: React.FC<{ formData?: any }> = ({ formData }) => {
  const getMonthlyData = () => {
    const defaultValues = [2850, 3200, 4500, 5800, 6900, 7200, 7350, 6800, 5400, 4100, 3200, 2800];
    let monthlyProduction = defaultValues;
    
    if (formData?.mesecnaProizvodnja) {
      // Parse monthly production data - ignore commas and dots as they are thousands separators
      const values = formData.mesecnaProizvodnja
        .split(/[\n]/)
        .map((val: string) => {
          // Remove all commas and dots, then parse as integer
          const cleanedVal = val.trim().replace(/[,.]/g, '');
          return parseInt(cleanedVal) || 0;
        })
        .filter((val: number) => val > 0);
      
      if (values.length >= 12) {
        monthlyProduction = values.slice(0, 12);
      }
    }
    
    return monthlyProduction;
  };

  const monthlyData = getMonthlyData();
  const totalProduction = monthlyData.reduce((sum, val) => sum + val, 0);

  // Calculate seasonal totals
  const winter = monthlyData[11] + monthlyData[0] + monthlyData[1]; // Dec, Jan, Feb
  const spring = monthlyData[2] + monthlyData[3] + monthlyData[4]; // Mar, Apr, May
  const summer = monthlyData[5] + monthlyData[6] + monthlyData[7]; // Jun, Jul, Aug
  const autumn = monthlyData[8] + monthlyData[9] + monthlyData[10]; // Sep, Oct, Nov

  const seasons = [
    {
      name: 'Zima',
      production: winter,
      months: 'kWh (Dec-Feb)',
      percentage: ((winter / totalProduction) * 100).toFixed(1),
      icon: Snowflake,
      bgColor: 'bg-gradient-to-br from-purple-100 to-purple-200',
      textColor: 'text-purple-700',
      iconColor: 'text-purple-500'
    },
    {
      name: 'Proleće',
      production: spring,
      months: 'kWh (Mar-Maj)',
      percentage: ((spring / totalProduction) * 100).toFixed(1),
      icon: Flower,
      bgColor: 'bg-gradient-to-br from-green-100 to-green-200',
      textColor: 'text-green-700',
      iconColor: 'text-green-500'
    },
    {
      name: 'Leto',
      production: summer,
      months: 'kWh (Jun-Avg)',
      percentage: ((summer / totalProduction) * 100).toFixed(1),
      icon: Sun,
      bgColor: 'bg-gradient-to-br from-yellow-100 to-yellow-200',
      textColor: 'text-yellow-700',
      iconColor: 'text-yellow-500'
    },
    {
      name: 'Jesen',
      production: autumn,
      months: 'kWh (Sep-Nov)',
      percentage: ((autumn / totalProduction) * 100).toFixed(1),
      icon: LeafFall,
      bgColor: 'bg-gradient-to-br from-orange-100 to-orange-200',
      textColor: 'text-orange-700',
      iconColor: 'text-orange-500'
    }
  ];

  return (
    <div className="mb-8">
      <h2 className="text-2xl font-semibold text-gray-800 text-center mb-6">Sezonska analiza proizvodnje</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {seasons.map((season, index) => (
          <Card key={index} className={`${season.bgColor} border-0 shadow-md`}>
            <CardContent className="p-6">
              <div className="text-center">
                <season.icon className={`h-12 w-12 mx-auto mb-4 ${season.iconColor}`} />
                <h3 className={`text-lg font-semibold mb-2 ${season.textColor}`}>{season.name}</h3>
                <p className={`text-2xl font-bold mb-1 ${season.textColor}`}>
                  {season.production.toLocaleString('sr-RS')}
                </p>
                <p className={`text-sm ${season.textColor} opacity-80 mb-2`}>{season.months}</p>
                <p className={`text-sm font-medium ${season.textColor}`}>
                  {season.percentage}% ukupne
                </p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

// Location Parameters Component
const LocationParameters: React.FC<{ formData?: any }> = ({ formData }) => {
  const parameters = [
    { 
      icon: MapPin, 
      label: "Adresa:", 
      value: formData?.objekatLokacija || "Subotica"
    },
    { 
      icon: RotateCcw, 
      label: "Orijentacija:", 
      value: "SE 146°"
    },
    { 
      icon: TrendingUp, 
      label: "Nagib:", 
      value: "15°"
    },
    { 
      icon: BarChart3, 
      label: "Performance ratio:", 
      value: "93.12%"
    },
    { 
      icon: Zap, 
      label: "Degradacija:", 
      value: "1% godina 1, zatim 0.4% godišnje"
    }
  ];

  return (
    <div>
      <h2 className="text-xl font-semibold mb-6 text-gray-800">Parametri lokacije</h2>
      <div className="space-y-6">
        {parameters.map((param, index) => (
          <div key={index} className="flex items-start gap-4">
            <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center flex-shrink-0">
              <param.icon className="w-5 h-5 text-purple-600" />
            </div>
            <div className="flex-1 pt-1">
              <p className="text-gray-700 font-medium">{param.label}</p>
              <p className="text-gray-900 font-semibold">{param.value}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

// Monthly Production Chart Component
const MonthlyProductionChart: React.FC<{ formData?: any }> = ({ formData }) => {
  // Generate monthly data from form data or use defaults
  const getMonthlyData = () => {
    const defaultValues = [2850, 3200, 4500, 5800, 6900, 7200, 7350, 6800, 5400, 4100, 3200, 2800];
    let monthlyProduction = defaultValues;
    
    if (formData?.mesecnaProizvodnja) {
      // Parse monthly production data - ignore commas and dots as they are thousands separators
      const values = formData.mesecnaProizvodnja
        .split(/[\n]/)
        .map((val: string) => {
          // Remove all commas and dots, then parse as integer
          const cleanedVal = val.trim().replace(/[,.]/g, '');
          return parseInt(cleanedVal) || 0;
        })
        .filter((val: number) => val > 0);
      
      if (values.length >= 12) {
        monthlyProduction = values.slice(0, 12);
      }
    }

    const months = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'];
    
    // Beautiful gradient colors from blue/purple to pink to yellow to green/teal
    const colors = [
      '#6366f1', '#7c3aed', '#8b5cf6', '#a855f7', // Jan-Apr: Blue to Purple
      '#c084fc', '#e879f9', '#f472b6', '#fb7185', // May-Aug: Purple to Pink
      '#fbbf24', '#f59e0b', '#14b8a6', '#0d9488'  // Sep-Dec: Yellow to Teal
    ];
    
    return monthlyProduction.map((production, index) => ({
      month: months[index],
      production: production,
      color: colors[index]
    }));
  };

  const monthlyData = getMonthlyData();
  const totalProduction = monthlyData.reduce((sum, item) => sum + item.production, 0);
  const maxProduction = Math.max(...monthlyData.map(item => item.production));
  const maxMonth = monthlyData.find(item => item.production === maxProduction);

  return (
    <Card className="bg-white border border-gray-200 shadow-sm">
      <CardHeader>
        <CardTitle className="text-xl font-semibold text-gray-800">Mesečna proizvodnja</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={monthlyData}
              margin={{
                top: 20,
                right: 30,
                left: 20,
                bottom: 5,
              }}
            >
              <CartesianGrid 
                strokeDasharray="3 3" 
                stroke="#f3f4f6"
                strokeOpacity={0.8}
              />
              <XAxis 
                dataKey="month" 
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 14, fill: '#6b7280' }}
              />
              <YAxis 
                axisLine={false}
                tickLine={false}
                tick={{ fontSize: 14, fill: '#6b7280' }}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
                domain={[0, 8000]}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: '#ffffff',
                  border: '1px solid #e5e7eb',
                  borderRadius: '12px',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                  color: '#1f2937'
                }}
                labelStyle={{ color: '#1f2937', fontWeight: '600' }}
                itemStyle={{ color: '#1f2937' }}
                formatter={(value: number) => [`${value.toLocaleString('sr-RS')} kWh`, 'Proizvodnja']}
                labelFormatter={(label) => `Mesec: ${label}`}
              />
              <Bar 
                dataKey="production" 
                radius={[6, 6, 0, 0]}
              >
                {monthlyData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        {/* Bottom info */}
        <div className="mt-6 pt-4 border-t border-gray-100">
          <div className="flex flex-col sm:flex-row justify-between gap-4 text-sm">
            <div className="text-gray-700">
              <span className="font-medium">Najveća proizvodnja:</span>
              <span className="ml-2 font-semibold">
                {maxMonth?.month === 'J' && monthlyData[6].production === maxProduction ? 'Jul' : 
                 maxMonth?.month === 'J' ? 'Jan' : 
                 maxMonth?.month === 'F' ? 'Feb' :
                 maxMonth?.month === 'M' && monthlyData.indexOf(maxMonth) === 2 ? 'Mar' :
                 maxMonth?.month === 'M' && monthlyData.indexOf(maxMonth) === 4 ? 'Maj' :
                 maxMonth?.month === 'A' && monthlyData.indexOf(maxMonth) === 3 ? 'Apr' :
                 maxMonth?.month === 'A' && monthlyData.indexOf(maxMonth) === 7 ? 'Avg' :
                 maxMonth?.month === 'J' && monthlyData.indexOf(maxMonth) === 5 ? 'Jun' :
                 maxMonth?.month === 'S' ? 'Sep' :  
                 maxMonth?.month === 'O' ? 'Okt' :
                 maxMonth?.month === 'N' ? 'Nov' :
                 maxMonth?.month === 'D' ? 'Dec' : 'Jul'} ({maxProduction.toLocaleString('sr-RS')} kWh)
              </span>
            </div>
            <div className="text-gray-700">
              <span className="font-medium">Ukupna godišnja proizvodnja:</span>
              <span className="ml-2 font-semibold">{totalProduction.toLocaleString('sr-RS')} kWh</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

// Main Solar Dashboard Component
const SolarDashboard: React.FC<SolarDashboardProps> = ({ onBack, formData }) => {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <Header onBack={onBack} formData={formData} />

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Summary Cards */}
        <SummaryCards formData={formData} />
        
        {/* Seasonal Analysis */}
        <SeasonalAnalysis formData={formData} />

        {/* Main Chart Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Parameters */}
          <div className="lg:col-span-1">
            <LocationParameters formData={formData} />
          </div>
          
          {/* Right Column - Chart */}
          <div className="lg:col-span-2">
            <MonthlyProductionChart formData={formData} />
          </div>
        </div>
      </div>
    </div>
  );
};

export default SolarDashboard;