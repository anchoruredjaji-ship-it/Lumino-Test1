import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { formatQuoteTitle } from '../utils/QuoteIdGenerator';

// Types
interface FormData {
  nazivProjekta: string;
  datum: string;
  tipKupca: string;
  nazivKupca: string;
  adresaKupca: string;
  pib: string;
  mb: string;
  telefon: string;
  email: string;
  objekatLokacija: string;
  snagaSistema: string;
  cena: string;
  cenaKwh: string;
  godisnjaProizvodnja: string;
  godisnjaUsteda: string;
  povratInvesticije: string;
  mesecnaProizvodnja: string;
}

interface Stavka {
  id: string;
  tip: string;
  kolicina: string;
}

interface KrovSlika {
  id: string;
  file: File;
  url: string;
  naziv: string;
}

interface Krov {
  id: string;
  brojModula: string;
  orijentacija: string;
  procenatNagiba: string;
  slike: KrovSlika[];
}

interface Artikal {
  id: string;
  naziv: string;
  opis: string;
  garancija: string;
  tip: string;
}

interface UsloviPlacanja {
  prvi: string;
  drugi: string;
  treci: string;
}

interface PdfPreviewProps {
  formData: FormData;
  tipKupca: string;
  stavke: Stavka[];
  krovovi: Krov[];
  artikli: Artikal[];
  usloviPlacanja: UsloviPlacanja;
  napomenaClan10: boolean;
}

const PdfPreview: React.FC<PdfPreviewProps> = ({
  formData,
  tipKupca,
  stavke,
  krovovi,
  artikli,
  usloviPlacanja,
  napomenaClan10
}) => {
  // Helper functions
  const getSelectedArtikli = () => {
    return stavke.map(stavka => {
      if (stavka.tip.startsWith('artikal-')) {
        const artikalId = stavka.tip.replace('artikal-', '');
        const artikal = artikli.find(a => a.id === artikalId);
        return { ...artikal, kolicina: stavka.kolicina };
      }
      return null;
    }).filter(Boolean);
  };

  const parseMonthlyProduction = (data: string) => {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'Maj', 'Jun', 'Jul', 'Avg', 'Sep', 'Okt', 'Nov', 'Dec'];
    const values = data.split('\n').map(line => parseFloat(line.replace(',', '.')) || 0);
    return months.map((month, index) => ({
      month,
      production: values[index] || 0
    }));
  };

  const selectedArtikli = getSelectedArtikli();
  const monthlyData = parseMonthlyProduction(formData.mesecnaProizvodnja || '');
  const totalProduction = monthlyData.reduce((sum, item) => sum + item.production, 0);

  return (
    <div className="bg-white min-h-screen">
      {/* Page 1 - Cover Page */}
      <div 
        className="mx-auto bg-white relative overflow-hidden"
        style={{ 
          width: '210mm', 
          minHeight: '297mm',
          padding: '40px',
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'space-between'
        }}
      >
        {/* Header with Logo */}
        <div className="flex justify-between items-start mb-12">
          {/* Lumino Logo */}
          <div className="relative">
            <svg width="120" height="32" viewBox="0 0 120 32" className="mb-2">
              {/* Lumino logo with sun/star burst design */}
              <defs>
                <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" style={{stopColor: '#6C4EE7'}} />
                  <stop offset="100%" style={{stopColor: '#4C3BAE'}} />
                </linearGradient>
              </defs>
              
              {/* Sun burst rays */}
              <g transform="translate(16,16)">
                <path d="M0,-12 L0,-8" stroke="url(#logoGradient)" strokeWidth="2"/>
                <path d="M8.5,-8.5 L6,-6" stroke="url(#logoGradient)" strokeWidth="2"/>
                <path d="M12,0 L8,0" stroke="url(#logoGradient)" strokeWidth="2"/>
                <path d="M8.5,8.5 L6,6" stroke="url(#logoGradient)" strokeWidth="2"/>
                <path d="M0,12 L0,8" stroke="url(#logoGradient)" strokeWidth="2"/>
                <path d="M-8.5,8.5 L-6,6" stroke="url(#logoGradient)" strokeWidth="2"/>
                <path d="M-12,0 L-8,0" stroke="url(#logoGradient)" strokeWidth="2"/>
                <path d="M-8.5,-8.5 L-6,-6" stroke="url(#logoGradient)" strokeWidth="2"/>
              </g>
              
              {/* Lumino text */}
              <text x="40" y="20" fill="url(#logoGradient)" fontSize="16" fontWeight="600" fontFamily="Inter, sans-serif">
                lumino
              </text>
            </svg>
          </div>
          
          {/* Top right info */}
          <div className="text-right" style={{ fontSize: '11px', color: '#666' }}>
            <p>{formatQuoteTitle(formData.datum)}</p>
            <p>Datum: {formData.datum || new Date().toLocaleDateString('sr-RS')}</p>
            <p>Stranica: 1</p>
          </div>
        </div>

        {/* Main Content - Centered */}
        <div className="flex-1 flex flex-col justify-center items-center text-center space-y-8">
          {/* Project Title */}
          <div>
            <h1 style={{ 
              fontSize: '42px', 
              fontWeight: 'bold', 
              color: '#4C3BAE',
              marginBottom: '16px',
              letterSpacing: '-0.5px'
            }}>
              PONUDA
            </h1>
            <h2 style={{ 
              fontSize: '28px', 
              fontWeight: '600', 
              color: '#333',
              marginBottom: '8px'
            }}>
              {formData.nazivProjekta || 'Solar Project'}
            </h2>
            <p style={{ fontSize: '18px', color: '#666' }}>
              Projektovanu snagu od {formData.snagaSistema || '138'} kWp
            </p>
          </div>

          {/* Solar Panel Image */}
          <div className="my-12">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1756157841473-f64d810ee17c?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdW1pbm8lMjBzb2xhcnxlbnwxfHx8fDE3NTcyNjA1MzF8MA&ixlib=rb-4.1.0&q=80&w=1080"
              alt="Solar panels"
              style={{
                width: '400px',
                height: '250px',
                objectFit: 'cover',
                borderRadius: '12px',
                boxShadow: '0 8px 32px rgba(0,0,0,0.1)'
              }}
            />
          </div>

          {/* Client Info */}
          <div className="bg-gray-50 p-6 rounded-lg" style={{ minWidth: '400px' }}>
            <h3 style={{ fontSize: '16px', fontWeight: '600', color: '#4C3BAE', marginBottom: '12px' }}>
              Pripremljena za:
            </h3>
            <div style={{ fontSize: '14px', color: '#333', lineHeight: '1.6' }}>
              <p><strong>{formData.nazivKupca || 'Naziv kupca'}</strong></p>
              <p>{formData.adresaKupca || 'Adresa kupca'}</p>
              {tipKupca === 'pravno' && formData.pib && (
                <p>PIB: {formData.pib}</p>
              )}
              <p>{formData.telefon || 'Telefon'}</p>
              <p>{formData.email || 'Email'}</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center" style={{ fontSize: '11px', color: '#666' }}>
          <p>Lumino d.o.o. | Beograd | PIB: 123456789</p>
          <p>www.lumino.rs | info@lumino.rs | +381 11 123 4567</p>
        </div>
      </div>

      {/* Page Break */}
      <div style={{ pageBreakBefore: 'always' }} />

      {/* Page 2 - Detailed Offer */}
      <div 
        className="mx-auto bg-white relative overflow-hidden"
        style={{ 
          width: '210mm', 
          minHeight: '297mm',
          padding: '30px',
          fontSize: '12px'
        }}
      >
        {/* Header */}
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-200">
          <div>
            <svg width="80" height="20" viewBox="0 0 120 32" className="mb-1">
              <defs>
                <linearGradient id="logoGradient2" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" style={{stopColor: '#6C4EE7'}} />
                  <stop offset="100%" style={{stopColor: '#4C3BAE'}} />
                </linearGradient>
              </defs>
              <g transform="translate(10,10) scale(0.6)">
                <path d="M0,-12 L0,-8" stroke="url(#logoGradient2)" strokeWidth="2"/>
                <path d="M8.5,-8.5 L6,-6" stroke="url(#logoGradient2)" strokeWidth="2"/>
                <path d="M12,0 L8,0" stroke="url(#logoGradient2)" strokeWidth="2"/>
                <path d="M8.5,8.5 L6,6" stroke="url(#logoGradient2)" strokeWidth="2"/>
                <path d="M0,12 L0,8" stroke="url(#logoGradient2)" strokeWidth="2"/>
                <path d="M-8.5,8.5 L-6,6" stroke="url(#logoGradient2)" strokeWidth="2"/>
                <path d="M-12,0 L-8,0" stroke="url(#logoGradient2)" strokeWidth="2"/>
                <path d="M-8.5,-8.5 L-6,-6" stroke="url(#logoGradient2)" strokeWidth="2"/>
              </g>
              <text x="30" y="14" fill="url(#logoGradient2)" fontSize="11" fontWeight="600" fontFamily="Inter, sans-serif">
                lumino
              </text>
            </svg>
          </div>
          <div className="text-right" style={{ fontSize: '10px', color: '#666' }}>
            <p>Datum: {formData.datum || new Date().toLocaleDateString('sr-RS')}</p>
            <p>Stranica: 2</p>
          </div>
        </div>

        {/* Customer and Project Info */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          <div>
            <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
              PODACI O KUPCU
            </h3>
            <div style={{ fontSize: '11px', lineHeight: '1.5', color: '#333' }}>
              <p><span style={{ fontWeight: '500' }}>Naziv:</span> {formData.nazivKupca || 'N/A'}</p>
              <p><span style={{ fontWeight: '500' }}>Adresa:</span> {formData.adresaKupca || 'N/A'}</p>
              {tipKupca === 'pravno' && (
                <>
                  <p><span style={{ fontWeight: '500' }}>PIB:</span> {formData.pib || 'N/A'}</p>
                  <p><span style={{ fontWeight: '500' }}>MB:</span> {formData.mb || 'N/A'}</p>
                </>
              )}
              <p><span style={{ fontWeight: '500' }}>Telefon:</span> {formData.telefon || 'N/A'}</p>
              <p><span style={{ fontWeight: '500' }}>Email:</span> {formData.email || 'N/A'}</p>
            </div>
          </div>
          <div>
            <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
              PODACI O PROJEKTU
            </h3>
            <div style={{ fontSize: '11px', lineHeight: '1.5', color: '#333' }}>
              <p><span style={{ fontWeight: '500' }}>Naziv:</span> {formData.nazivProjekta || 'N/A'}</p>
              <p><span style={{ fontWeight: '500' }}>Lokacija:</span> {formData.objekatLokacija || 'N/A'}</p>
              <p><span style={{ fontWeight: '500' }}>Snaga sistema:</span> {formData.snagaSistema || 'N/A'} kWp</p>
              <p><span style={{ fontWeight: '500' }}>Tip kupca:</span> {tipKupca === 'pravno' ? 'Pravno lice' : 'Fizičko lice'}</p>
              <p><span style={{ fontWeight: '500' }}>Validnost:</span> 30 dana</p>
            </div>
          </div>
        </div>

        {/* Equipment Specification Table */}
        <div className="mb-6">
          <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
            SPECIFIKACIJA OPREME I USLUGA
          </h3>
          <table 
            className="w-full"
            style={{ 
              border: '1px solid #ddd',
              borderCollapse: 'collapse',
              fontSize: '10px'
            }}
          >
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa' }}>
                <th style={{ 
                  border: '1px solid #ddd', 
                  padding: '8px 6px', 
                  textAlign: 'left',
                  fontWeight: '600',
                  width: '30px'
                }}>
                  Rb.
                </th>
                <th style={{ 
                  border: '1px solid #ddd', 
                  padding: '8px 6px', 
                  textAlign: 'left',
                  fontWeight: '600'
                }}>
                  Naziv
                </th>
                <th style={{ 
                  border: '1px solid #ddd', 
                  padding: '8px 6px', 
                  textAlign: 'left',
                  fontWeight: '600'
                }}>
                  Opis
                </th>
                <th style={{ 
                  border: '1px solid #ddd', 
                  padding: '8px 6px', 
                  textAlign: 'center',
                  fontWeight: '600',
                  width: '60px'
                }}>
                  Količina
                </th>
                <th style={{ 
                  border: '1px solid #ddd', 
                  padding: '8px 6px', 
                  textAlign: 'left',
                  fontWeight: '600',
                  width: '80px'
                }}>
                  Garancija
                </th>
              </tr>
            </thead>
            <tbody>
              {selectedArtikli.map((artikal: any, index: number) => (
                <tr key={index}>
                  <td style={{ 
                    border: '1px solid #ddd', 
                    padding: '8px 6px',
                    textAlign: 'center'
                  }}>
                    {index + 1}.
                  </td>
                  <td style={{ 
                    border: '1px solid #ddd', 
                    padding: '8px 6px',
                    fontWeight: '500'
                  }}>
                    {artikal?.naziv || 'N/A'}
                  </td>
                  <td style={{ 
                    border: '1px solid #ddd', 
                    padding: '8px 6px',
                    lineHeight: '1.3'
                  }}>
                    {artikal?.opis || 'N/A'}
                  </td>
                  <td style={{ 
                    border: '1px solid #ddd', 
                    padding: '8px 6px',
                    textAlign: 'center'
                  }}>
                    {artikal?.kolicina || 'N/A'}
                  </td>
                  <td style={{ 
                    border: '1px solid #ddd', 
                    padding: '8px 6px'
                  }}>
                    {artikal?.garancija || 'N/A'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Price and Terms Section */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          <div>
            <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
              CENA
            </h3>
            <div 
              style={{ 
                backgroundColor: '#f8f9fa',
                border: '1px solid #ddd',
                padding: '12px',
                borderRadius: '4px'
              }}
            >
              <p style={{ 
                fontSize: '18px', 
                fontWeight: 'bold', 
                color: '#4C3BAE',
                margin: '0 0 4px 0'
              }}>
                {formData.cena ? `${parseFloat(formData.cena).toLocaleString('sr-RS')} EUR` : 'Na upit'}
              </p>
              <p style={{ fontSize: '10px', color: '#666', margin: '0' }}>
                *Cena ne uključuje PDV
              </p>
            </div>
          </div>
          <div>
            <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
              USLOVI PLAĆANJA
            </h3>
            <div style={{ fontSize: '10px', lineHeight: '1.4', color: '#333' }}>
              {usloviPlacanja.prvi && <p>• {usloviPlacanja.prvi}</p>}
              {usloviPlacanja.drugi && <p>• {usloviPlacanja.drugi}</p>}
              {usloviPlacanja.treci && <p>• {usloviPlacanja.treci}</p>}
              {!usloviPlacanja.prvi && !usloviPlacanja.drugi && !usloviPlacanja.treci && (
                <p>• Po dogovoru</p>
              )}
            </div>
          </div>
        </div>

        {/* Technical Parameters */}
        <div className="mb-6">
          <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
            TEHNIČKI PARAMETRI / KONFIGURACIJA KROVOVA
          </h3>
          <div className="grid grid-cols-3 gap-4">
            {krovovi.map((krov, index) => (
              <div 
                key={krov.id}
                style={{ 
                  backgroundColor: '#f8f9fa',
                  border: '1px solid #ddd',
                  padding: '8px',
                  borderRadius: '4px'
                }}
              >
                <h4 style={{ fontSize: '11px', fontWeight: '600', margin: '0 0 6px 0', color: '#4C3BAE' }}>
                  KROV {index + 1}
                </h4>
                <div style={{ fontSize: '9px', lineHeight: '1.3', color: '#333' }}>
                  <p><span style={{ fontWeight: '500' }}>Broj modula:</span> {krov.brojModula || 'N/A'}</p>
                  <p><span style={{ fontWeight: '500' }}>Orijentacija:</span> {krov.orijentacija || 'N/A'}</p>
                  <p><span style={{ fontWeight: '500' }}>Nagib:</span> {krov.procenatNagiba || 'N/A'}%</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Terms and Conditions */}
        <div className="mb-6">
          <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
            USLOVI ISPORUKE I UGRADNJE
          </h3>
          <div className="grid grid-cols-2 gap-6" style={{ fontSize: '10px', lineHeight: '1.4', color: '#333' }}>
            <div>
              <p style={{ margin: '0 0 4px 0' }}>• <span style={{ fontWeight: '500' }}>Rok isporuke:</span> 4-6 nedelja od potpisivanja ugovora</p>
              <p style={{ margin: '0 0 4px 0' }}>• <span style={{ fontWeight: '500' }}>Ugradnja:</span> Uključena u cenu</p>
              <p style={{ margin: '0 0 4px 0' }}>• <span style={{ fontWeight: '500' }}>Puštanje u rad:</span> Do 7 dana nakon ugradnje</p>
              <p style={{ margin: '0' }}>• <span style={{ fontWeight: '500' }}>Validnost ponude:</span> 30 dana</p>
            </div>
            <div>
              <p style={{ margin: '0 0 4px 0' }}>• <span style={{ fontWeight: '500' }}>Garancija na radove:</span> 2 godine</p>
              <p style={{ margin: '0 0 4px 0' }}>• <span style={{ fontWeight: '500' }}>Tehnička podrška:</span> Doživotna</p>
              <p style={{ margin: '0 0 4px 0' }}>• <span style={{ fontWeight: '500' }}>Servis:</span> Preventivni jednom godišnje</p>
              <p style={{ margin: '0' }}>• <span style={{ fontWeight: '500' }}>Održavanje:</span> Minimalno, čišćenje 2x godišnje</p>
            </div>
          </div>
        </div>

        {/* Special Notes */}
        {napomenaClan10 && tipKupca === 'pravno' && (
          <div className="mb-6">
            <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
              NAPOMENE
            </h3>
            <div 
              style={{ 
                backgroundColor: '#fff7e6',
                border: '1px solid #E2B93B',
                padding: '8px',
                borderRadius: '4px'
              }}
            >
              <p style={{ fontSize: '10px', color: '#B8860B', margin: '0', lineHeight: '1.4' }}>
                • Član 10 se primenjuje – investicija u obnovljive izvore energije
              </p>
            </div>
          </div>
        )}

        {/* Footer with contact */}
        <div className="text-center border-t border-gray-200 pt-4" style={{ fontSize: '10px', color: '#666' }}>
          <p style={{ margin: '0 0 2px 0' }}>Lumino d.o.o. | Beograd | PIB: 123456789</p>
          <p style={{ margin: '0' }}>www.lumino.rs | info@lumino.rs | +381 11 123 4567</p>
        </div>
      </div>

      {/* Page Break */}
      <div style={{ pageBreakBefore: 'always' }} />

      {/* Page 3 - Monthly Production Chart */}
      <div 
        className="mx-auto bg-white relative overflow-hidden"
        style={{ 
          width: '210mm', 
          minHeight: '297mm',
          padding: '30px',
          fontSize: '12px'
        }}
      >
        {/* Header */}
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-200">
          <div>
            <svg width="80" height="20" viewBox="0 0 120 32" className="mb-1">
              <defs>
                <linearGradient id="logoGradient3" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" style={{stopColor: '#6C4EE7'}} />
                  <stop offset="100%" style={{stopColor: '#4C3BAE'}} />
                </linearGradient>
              </defs>
              <g transform="translate(10,10) scale(0.6)">
                <path d="M0,-12 L0,-8" stroke="url(#logoGradient3)" strokeWidth="2"/>
                <path d="M8.5,-8.5 L6,-6" stroke="url(#logoGradient3)" strokeWidth="2"/>
                <path d="M12,0 L8,0" stroke="url(#logoGradient3)" strokeWidth="2"/>
                <path d="M8.5,8.5 L6,6" stroke="url(#logoGradient3)" strokeWidth="2"/>
                <path d="M0,12 L0,8" stroke="url(#logoGradient3)" strokeWidth="2"/>
                <path d="M-8.5,8.5 L-6,6" stroke="url(#logoGradient3)" strokeWidth="2"/>
                <path d="M-12,0 L-8,0" stroke="url(#logoGradient3)" strokeWidth="2"/>
                <path d="M-8.5,-8.5 L-6,-6" stroke="url(#logoGradient3)" strokeWidth="2"/>
              </g>
              <text x="30" y="14" fill="url(#logoGradient3)" fontSize="11" fontWeight="600" fontFamily="Inter, sans-serif">
                lumino
              </text>
            </svg>
          </div>
          <div className="text-right" style={{ fontSize: '10px', color: '#666' }}>
            <p>Datum: {formData.datum || new Date().toLocaleDateString('sr-RS')}</p>
            <p>Stranica: 3</p>
          </div>
        </div>

        {/* Project Title */}
        <div className="text-center mb-8">
          <h1 style={{ fontSize: '18px', fontWeight: '600', color: '#4C3BAE', margin: '0 0 4px 0' }}>
            PRORACUN PROIZVODNJE I UŠTEDE ELEKTRICNE ENERGIJE ZA OBJEKAT
          </h1>
          <h2 style={{ fontSize: '16px', fontWeight: '500', color: '#333', margin: '0' }}>
            {formData.nazivProjekta || 'Solar Project'} - {formData.objekatLokacija || 'Lokacija'}
          </h2>
        </div>

        {/* Monthly Production Chart */}
        {formData.mesecnaProizvodnja && (
          <div className="mb-8">
            <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '12px', textAlign: 'center' }}>
              MESEČNA PROIZVODNJA ELEKTRICNE ENERGIJE (kWh)
            </h3>
            <div 
              style={{ 
                border: '1px solid #ddd',
                backgroundColor: 'white',
                padding: '16px',
                borderRadius: '4px'
              }}
            >
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                  <CartesianGrid strokeDasharray="2 2" stroke="#e0e0e0" />
                  <XAxis 
                    dataKey="month" 
                    axisLine={false}
                    tickLine={false}
                    style={{ fontSize: '10px', fill: '#666' }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    style={{ fontSize: '10px', fill: '#666' }}
                  />
                  <Tooltip 
                    formatter={(value: any) => [`${value} kWh`, 'Proizvodnja']}
                    contentStyle={{
                      backgroundColor: 'white',
                      border: '1px solid #ddd',
                      borderRadius: '4px',
                      fontSize: '10px'
                    }}
                  />
                  <Bar 
                    dataKey="production" 
                    fill="#4C3BAE" 
                    radius={[2, 2, 0, 0]}
                    stroke="#4C3BAE"
                    strokeWidth={1}
                  />
                </BarChart>
              </ResponsiveContainer>
              <div className="text-center mt-4" style={{ fontSize: '11px', color: '#666' }}>
                <p style={{ margin: '0' }}>
                  <strong>Ukupna godišnja proizvodnja: {totalProduction.toFixed(0)} kWh</strong>
                </p>
                <p style={{ margin: '4px 0 0 0' }}>
                  Prosečna mesečna proizvodnja: {(totalProduction / 12).toFixed(0)} kWh
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Technical and Financial Summary */}
        <div className="grid grid-cols-2 gap-6 mb-6">
          {/* Technical Data */}
          <div>
            <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
              TEHNIČKI PODACI
            </h3>
            <div 
              style={{ 
                backgroundColor: '#f8f9fa',
                border: '1px solid #ddd',
                padding: '12px',
                borderRadius: '4px'
              }}
            >
              <div style={{ fontSize: '10px', lineHeight: '1.4', color: '#333' }}>
                <p style={{ margin: '0 0 4px 0' }}>
                  <span style={{ fontWeight: '500' }}>Snaga sistema:</span> {formData.snagaSistema || 'N/A'} kWp
                </p>
                <p style={{ margin: '0 0 4px 0' }}>
                  <span style={{ fontWeight: '500' }}>Godišnja proizvodnja:</span> {totalProduction.toFixed(0)} kWh
                </p>
                <p style={{ margin: '0 0 4px 0' }}>
                  <span style={{ fontWeight: '500' }}>Specifična proizvodnja:</span> {
                    formData.snagaSistema 
                      ? `${(totalProduction / parseFloat(formData.snagaSistema)).toFixed(0)} kWh/kWp` 
                      : 'N/A'
                  }
                </p>
                <p style={{ margin: '0' }}>
                  <span style={{ fontWeight: '500' }}>Efikasnost sistema:</span> 85%
                </p>
              </div>
            </div>
          </div>

          {/* Environmental Impact */}
          <div>
            <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
              EKOLOSKI UTICAJ
            </h3>
            <div 
              style={{ 
                backgroundColor: '#f0fff4',
                border: '1px solid #1AA987',
                padding: '12px',
                borderRadius: '4px'
              }}
            >
              <div style={{ fontSize: '10px', lineHeight: '1.4', color: '#333' }}>
                <p style={{ margin: '0 0 4px 0' }}>
                  <span style={{ fontWeight: '500' }}>CO₂ ušteda godišnje:</span> {formData.godisnjaUsteda || 'N/A'} t
                </p>
                <p style={{ margin: '0 0 4px 0' }}>
                  <span style={{ fontWeight: '500' }}>Ekvivalent stabala:</span> {
                    formData.godisnjaUsteda 
                      ? Math.round(parseFloat(formData.godisnjaUsteda) * 2.5) 
                      : 'N/A'
                  }
                </p>
                <p style={{ margin: '0 0 4px 0' }}>
                  <span style={{ fontWeight: '500' }}>CO₂ ušteda za 25 god:</span> {
                    formData.godisnjaUsteda 
                      ? (parseFloat(formData.godisnjaUsteda) * 25).toFixed(1) + ' t'
                      : 'N/A'
                  }
                </p>
                <p style={{ margin: '0' }}>
                  <span style={{ fontWeight: '500' }}>Očekivani radni vek:</span> 25+ godina
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* ROI Analysis - Only for Legal Entities */}
        {tipKupca === 'pravno' && (
          <div className="mb-6">
            <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px', textAlign: 'center' }}>
              FINANSIJSKA ANALIZA - POVRAT INVESTICIJE (ROI)
            </h3>
            
            {/* Financial Summary Table */}
            <table 
              className="w-full mb-4"
              style={{ 
                border: '1px solid #ddd',
                borderCollapse: 'collapse',
                fontSize: '10px'
              }}
            >
              <thead>
                <tr style={{ backgroundColor: '#f8f9fa' }}>
                  <th style={{ 
                    border: '1px solid #ddd', 
                    padding: '8px', 
                    textAlign: 'left',
                    fontWeight: '600'
                  }}>
                    Parametar
                  </th>
                  <th style={{ 
                    border: '1px solid #ddd', 
                    padding: '8px', 
                    textAlign: 'right',
                    fontWeight: '600'
                  }}>
                    Vrednost
                  </th>
                  <th style={{ 
                    border: '1px solid #ddd', 
                    padding: '8px', 
                    textAlign: 'left',
                    fontWeight: '600'
                  }}>
                    Napomena
                  </th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={{ border: '1px solid #ddd', padding: '6px' }}>
                    Investicija (bez PDV)
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '6px', textAlign: 'right', fontWeight: '500' }}>
                    {formData.cena ? `${parseFloat(formData.cena).toLocaleString('sr-RS')} EUR` : 'N/A'}
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '6px' }}>
                    Ukupna cena sistema
                  </td>
                </tr>
                <tr>
                  <td style={{ border: '1px solid #ddd', padding: '6px' }}>
                    Godišnja proizvodnja
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '6px', textAlign: 'right', fontWeight: '500' }}>
                    {formData.godisnjaProizvodnja || totalProduction.toFixed(0)} kWh
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '6px' }}>
                    Očekivana proizvodnja
                  </td>
                </tr>
                <tr>
                  <td style={{ border: '1px solid #ddd', padding: '6px' }}>
                    Cena električne energije
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '6px', textAlign: 'right', fontWeight: '500' }}>
                    {formData.cenaKwh || 'N/A'} EUR/kWh
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '6px' }}>
                    Trenutna cena
                  </td>
                </tr>
                <tr style={{ backgroundColor: '#f0fff4' }}>
                  <td style={{ border: '1px solid #ddd', padding: '6px', fontWeight: '500' }}>
                    Godišnja ušteda
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '6px', textAlign: 'right', fontWeight: '600', color: '#1AA987' }}>
                    {
                      (formData.godisnjaProizvodnja || totalProduction) && formData.cenaKwh 
                        ? `${((parseFloat(formData.godisnjaProizvodnja || totalProduction.toString())) * parseFloat(formData.cenaKwh)).toFixed(0)} EUR`
                        : 'N/A'
                    }
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '6px' }}>
                    Proizvodnja × Cena kWh
                  </td>
                </tr>
                <tr style={{ backgroundColor: '#f8f7ff' }}>
                  <td style={{ border: '1px solid #ddd', padding: '6px', fontWeight: '500' }}>
                    Povrat investicije
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '6px', textAlign: 'right', fontWeight: '600', color: '#4C3BAE' }}>
                    {formData.povratInvesticije || 'N/A'}
                  </td>
                  <td style={{ border: '1px solid #ddd', padding: '6px' }}>
                    Investicija / Godišnja ušteda
                  </td>
                </tr>
              </tbody>
            </table>

            {/* Long-term Savings */}
            <div className="grid grid-cols-3 gap-4">
              <div style={{ 
                backgroundColor: '#f0fff4',
                border: '1px solid #1AA987',
                padding: '8px',
                borderRadius: '4px',
                textAlign: 'center'
              }}>
                <p style={{ fontSize: '16px', fontWeight: '600', color: '#1AA987', margin: '0 0 4px 0' }}>
                  {
                    (formData.godisnjaProizvodnja || totalProduction) && formData.cenaKwh 
                      ? `${((parseFloat(formData.godisnjaProizvodnja || totalProduction.toString())) * parseFloat(formData.cenaKwh) * 10).toFixed(0)} EUR`
                      : 'N/A'
                  }
                </p>
                <p style={{ fontSize: '9px', color: '#1AA987', margin: '0' }}>
                  Ušteda za 10 godina
                </p>
              </div>
              <div style={{ 
                backgroundColor: '#f8f7ff',
                border: '1px solid #4C3BAE',
                padding: '8px',
                borderRadius: '4px',
                textAlign: 'center'
              }}>
                <p style={{ fontSize: '16px', fontWeight: '600', color: '#4C3BAE', margin: '0 0 4px 0' }}>
                  {
                    (formData.godisnjaProizvodnja || totalProduction) && formData.cenaKwh 
                      ? `${((parseFloat(formData.godisnjaProizvodnja || totalProduction.toString())) * parseFloat(formData.cenaKwh) * 20).toFixed(0)} EUR`
                      : 'N/A'
                  }
                </p>
                <p style={{ fontSize: '9px', color: '#4C3BAE', margin: '0' }}>
                  Ušteda za 20 godina
                </p>
              </div>
              <div style={{ 
                backgroundColor: '#fff7e6',
                border: '1px solid #E2B93B',
                padding: '8px',
                borderRadius: '4px',
                textAlign: 'center'
              }}>
                <p style={{ fontSize: '16px', fontWeight: '600', color: '#B8860B', margin: '0 0 4px 0' }}>
                  {
                    (formData.godisnjaProizvodnja || totalProduction) && formData.cenaKwh 
                      ? `${((parseFloat(formData.godisnjaProizvodnja || totalProduction.toString())) * parseFloat(formData.cenaKwh) * 25).toFixed(0)} EUR`
                      : 'N/A'
                  }
                </p>
                <p style={{ fontSize: '9px', color: '#B8860B', margin: '0' }}>
                  Ušteda za 25 godina
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Solar Installation Images */}
        {krovovi.some(krov => krov.slike.length > 0) && (
          <div className="mb-6">
            <h3 style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px', textAlign: 'center' }}>
              MODELI SOLARNE ELEKTRANE NA OBJEKTU
            </h3>
            
            {krovovi.map((krov, krovIndex) => {
              if (krov.slike.length === 0) return null;
              
              return (
                <div key={krov.id} className="mb-6">
                  <h4 style={{ fontSize: '12px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
                    KROV {krovIndex + 1} - {krov.orijentacija ? krov.orijentacija.toUpperCase() : 'N/A'} ({krov.brojModula || 'N/A'} modula)
                  </h4>
                  
                  <div className="grid grid-cols-2 gap-4">
                    {krov.slike.slice(0, 4).map((slika, slikaIndex) => (
                      <div 
                        key={slika.id}
                        style={{ 
                          border: '1px solid #ddd',
                          borderRadius: '4px',
                          overflow: 'hidden',
                          backgroundColor: 'white'
                        }}
                      >
                        <img
                          src={slika.url}
                          alt={`Model elektrane - ${slika.naziv}`}
                          style={{
                            width: '100%',
                            height: '120px',
                            objectFit: 'cover'
                          }}
                        />
                        <div style={{ padding: '6px' }}>
                          <p style={{ 
                            fontSize: '9px', 
                            color: '#666', 
                            margin: '0',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap'
                          }}>
                            {slika.naziv}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  {krov.slike.length > 4 && (
                    <p style={{ 
                      fontSize: '10px', 
                      color: '#666', 
                      textAlign: 'center', 
                      margin: '8px 0 0 0',
                      fontStyle: 'italic'
                    }}>
                      + {krov.slike.length - 4} dodatnih slika
                    </p>
                  )}
                </div>
              );
            })}
          </div>
        )}

        {/* Footer with contact */}
        <div className="text-center border-t border-gray-200 pt-4" style={{ fontSize: '10px', color: '#666' }}>
          <p style={{ margin: '0 0 2px 0' }}>Lumino d.o.o. | Beograd | PIB: 123456789</p>
          <p style={{ margin: '0' }}>www.lumino.rs | info@lumino.rs | +381 11 123 4567</p>
        </div>
      </div>

      {/* Page Break */}
      <div style={{ pageBreakBefore: 'always' }} />

      {/* Page 4 - Final Page with Contact and Additional Info */}
      <div 
        className="mx-auto bg-white relative overflow-hidden"
        style={{ 
          width: '210mm', 
          minHeight: '297mm',
          padding: '30px',
          fontSize: '12px'
        }}
      >
        {/* Header */}
        <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-200">
          <div>
            <svg width="80" height="20" viewBox="0 0 120 32" className="mb-1">
              <defs>
                <linearGradient id="logoGradient4" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" style={{stopColor: '#6C4EE7'}} />
                  <stop offset="100%" style={{stopColor: '#4C3BAE'}} />
                </linearGradient>
              </defs>
              <g transform="translate(10,10) scale(0.6)">
                <path d="M0,-12 L0,-8" stroke="url(#logoGradient4)" strokeWidth="2"/>
                <path d="M8.5,-8.5 L6,-6" stroke="url(#logoGradient4)" strokeWidth="2"/>
                <path d="M12,0 L8,0" stroke="url(#logoGradient4)" strokeWidth="2"/>
                <path d="M8.5,8.5 L6,6" stroke="url(#logoGradient4)" strokeWidth="2"/>
                <path d="M0,12 L0,8" stroke="url(#logoGradient4)" strokeWidth="2"/>
                <path d="M-8.5,8.5 L-6,6" stroke="url(#logoGradient4)" strokeWidth="2"/>
                <path d="M-12,0 L-8,0" stroke="url(#logoGradient4)" strokeWidth="2"/>
                <path d="M-8.5,-8.5 L-6,-6" stroke="url(#logoGradient4)" strokeWidth="2"/>
              </g>
              <text x="30" y="14" fill="url(#logoGradient4)" fontSize="11" fontWeight="600" fontFamily="Inter, sans-serif">
                lumino
              </text>
            </svg>
          </div>
          <div className="text-right" style={{ fontSize: '10px', color: '#666' }}>
            <p>Datum: {formData.datum || new Date().toLocaleDateString('sr-RS')}</p>
            <p>Stranica: 4</p>
          </div>
        </div>

        {/* Additional Information */}
        <div className="mb-8">
          <h3 style={{ fontSize: '16px', fontWeight: '600', color: '#4C3BAE', marginBottom: '12px', textAlign: 'center' }}>
            DODATNE INFORMACIJE I USLOVI
          </h3>
          
          <div className="grid grid-cols-2 gap-6 mb-6">
            {/* System Benefits */}
            <div>
              <h4 style={{ fontSize: '12px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
                PREDNOSTI SOLARNOG SISTEMA
              </h4>
              <ul style={{ fontSize: '10px', lineHeight: '1.5', color: '#333', paddingLeft: '16px', margin: '0' }}>
                <li>Značajno smanjenje računa za struju</li>
                <li>Povrat investicije za 6-8 godina</li>
                <li>Garancija na panele do 25 godina</li>
                <li>Minimalno održavanje sistema</li>
                <li>Povećanje vrednosti nekretnine</li>
                <li>Zaštita od rasta cena električne energije</li>
                <li>Doprinos očuvanju životne sredine</li>
              </ul>
            </div>

            {/* Process Steps */}
            <div>
              <h4 style={{ fontSize: '12px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
                PROCES REALIZACIJE
              </h4>
              <div style={{ fontSize: '10px', lineHeight: '1.5', color: '#333' }}>
                <p style={{ margin: '0 0 4px 0' }}><strong>1.</strong> Potpisivanje ugovora i avans</p>
                <p style={{ margin: '0 0 4px 0' }}><strong>2.</strong> Nabavka opreme i priprema</p>
                <p style={{ margin: '0 0 4px 0' }}><strong>3.</strong> Ugradnja sistema (3-5 dana)</p>
                <p style={{ margin: '0 0 4px 0' }}><strong>4.</strong> Tehnički pregled i puštanje</p>
                <p style={{ margin: '0 0 4px 0' }}><strong>5.</strong> Priključak na EPS mrežu</p>
                <p style={{ margin: '0' }}><strong>6.</strong> Obuka korisnika i predaja</p>
              </div>
            </div>
          </div>

          {/* Warranty Information */}
          <div className="mb-6">
            <h4 style={{ fontSize: '12px', fontWeight: '600', color: '#4C3BAE', marginBottom: '8px' }}>
              GARANCIJE I ODRŽAVANJE
            </h4>
            <div className="grid grid-cols-3 gap-4">
              <div style={{ 
                backgroundColor: '#f8f9fa',
                border: '1px solid #ddd',
                padding: '8px',
                borderRadius: '4px',
                textAlign: 'center'
              }}>
                <p style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', margin: '0 0 4px 0' }}>
                  25 godina
                </p>
                <p style={{ fontSize: '9px', color: '#333', margin: '0' }}>
                  Garancija na panele
                </p>
              </div>
              <div style={{ 
                backgroundColor: '#f8f9fa',
                border: '1px solid #ddd',
                padding: '8px',
                borderRadius: '4px',
                textAlign: 'center'
              }}>
                <p style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', margin: '0 0 4px 0' }}>
                  10 godina
                </p>
                <p style={{ fontSize: '9px', color: '#333', margin: '0' }}>
                  Garancija na inverter
                </p>
              </div>
              <div style={{ 
                backgroundColor: '#f8f9fa',
                border: '1px solid #ddd',
                padding: '8px',
                borderRadius: '4px',
                textAlign: 'center'
              }}>
                <p style={{ fontSize: '14px', fontWeight: '600', color: '#4C3BAE', margin: '0 0 4px 0' }}>
                  2 godine
                </p>
                <p style={{ fontSize: '9px', color: '#333', margin: '0' }}>
                  Garancija na ugradnju
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Contact Information */}
        <div style={{ marginTop: 'auto' }}>
          <h3 style={{ fontSize: '16px', fontWeight: '600', color: '#4C3BAE', marginBottom: '12px', textAlign: 'center' }}>
            KONTAKT INFORMACIJE
          </h3>
          
          <div className="grid grid-cols-2 gap-6 mb-8">
            <div style={{ 
              backgroundColor: '#f8f9fa',
              border: '1px solid #ddd',
              padding: '16px',
              borderRadius: '4px'
            }}>
              <h4 style={{ fontSize: '12px', fontWeight: '600', color: '#4C3BAE', margin: '0 0 8px 0' }}>
                TEHNIČKA PODRŠKA
              </h4>
              <div style={{ fontSize: '11px', lineHeight: '1.4', color: '#333' }}>
                <p style={{ margin: '0 0 4px 0' }}><strong>Ing. Marko Petrović</strong></p>
                <p style={{ margin: '0 0 4px 0' }}>Tel: +381 11 123 4567</p>
                <p style={{ margin: '0 0 4px 0' }}>Email: marko@lumino.rs</p>
                <p style={{ margin: '0' }}>Radno vreme: 08:00 - 16:00</p>
              </div>
            </div>
            
            <div style={{ 
              backgroundColor: '#f8f9fa',
              border: '1px solid #ddd',
              padding: '16px',
              borderRadius: '4px'
            }}>
              <h4 style={{ fontSize: '12px', fontWeight: '600', color: '#4C3BAE', margin: '0 0 8px 0' }}>
                KOMERCIJALNA PODRŠKA
              </h4>
              <div style={{ fontSize: '11px', lineHeight: '1.4', color: '#333' }}>
                <p style={{ margin: '0 0 4px 0' }}><strong>Ana Nikolić</strong></p>
                <p style={{ margin: '0 0 4px 0' }}>Tel: +381 11 123 4568</p>
                <p style={{ margin: '0 0 4px 0' }}>Email: ana@lumino.rs</p>
                <p style={{ margin: '0' }}>Radno vreme: 08:00 - 16:00</p>
              </div>
            </div>
          </div>
          
          {/* Company Footer */}
          <div 
            className="text-center py-4"
            style={{ 
              backgroundColor: '#4C3BAE',
              color: 'white',
              borderRadius: '4px',
              fontSize: '11px'
            }}
          >
            <p style={{ margin: '0 0 4px 0', fontWeight: '600' }}>
              LUMINO d.o.o.
            </p>
            <p style={{ margin: '0 0 4px 0' }}>
              Beogradska 123, 11000 Beograd | PIB: 123456789 | MB: 12345678
            </p>
            <p style={{ margin: '0 0 4px 0' }}>
              www.lumino.rs | info@lumino.rs | +381 11 123 4567
            </p>
            <p style={{ margin: '0', fontSize: '10px', opacity: 0.8 }}>
              Vaš partner za obnovljive izvore energije
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PdfPreview;