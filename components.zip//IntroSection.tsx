import React from 'react';
import { Card, CardContent } from './ui/card';
import { CheckCircle, Sun, Zap, Shield } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function IntroSection() {
  const benefits = [
    { icon: Sun, text: "Čista i obnovljiva energija" },
    { icon: Zap, text: "Značajno smanjenje računa za struju" },
    { icon: Shield, text: "25 godina garancije na panele" },
    { icon: CheckCircle, text: "Povrat investicije 6-8 godina" }
  ];

  return (
    <div className="min-h-screen bg-white p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Zašto izabrati solarnu energiju?
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Solarna energija predstavlja budućnost energetike. Naši sistemi ne samo da štede novac, 
            već i doprinose očuvanju životne sredine za buduće generacije.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Benefits List */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-purple-700 mb-6">
              Ključne prednosti
            </h2>
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-100 to-teal-100 rounded-full flex items-center justify-center">
                  <benefit.icon className="w-6 h-6 text-purple-700" />
                </div>
                <span className="text-lg text-gray-700">{benefit.text}</span>
              </div>
            ))}
          </div>

          {/* Hero Image */}
          <div className="relative">
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1664127379716-829859074475?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzb2xhciUyMGVuZXJneSUyMGJlbmVmaXRzJTIwZW52aXJvbm1lbnR8ZW58MXx8fHwxNzU3MjYyMzY5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Solar Energy Benefits"
              className="w-full h-80 object-cover rounded-2xl shadow-lg"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-purple-900/20 to-transparent rounded-2xl" />
          </div>
        </div>

        {/* Statistics Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center bg-gradient-to-br from-purple-50 to-white border-purple-100">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-purple-700 mb-2">25+</div>
              <div className="text-gray-600">Godina garancije</div>
            </CardContent>
          </Card>
          <Card className="text-center bg-gradient-to-br from-teal-50 to-white border-teal-100">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-teal-700 mb-2">80%</div>
              <div className="text-gray-600">Smanjenje računa</div>
            </CardContent>
          </Card>
          <Card className="text-center bg-gradient-to-br from-green-50 to-white border-green-100">
            <CardContent className="p-6">
              <div className="text-3xl font-bold text-green-700 mb-2">500+</div>
              <div className="text-gray-600">Instaliranih sistema</div>
            </CardContent>
          </Card>
        </div>

        {/* Process Overview */}
        <div className="bg-gray-50 rounded-2xl p-8">
          <h2 className="text-2xl font-bold text-center text-gray-900 mb-8">
            Naš proces u 4 koraka
          </h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: "01", title: "Konsultacija", desc: "Analiza vaših potreba i lokacije" },
              { step: "02", title: "Dizajn", desc: "Kreiranje optimalnog sistema" },
              { step: "03", title: "Instalacija", desc: "Profesionalna ugradnja sistema" },
              { step: "04", title: "Podrška", desc: "Kontinuirana tehnička podrška" }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-600 to-teal-600 text-white rounded-full flex items-center justify-center font-bold text-sm mx-auto mb-4">
                  {item.step}
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-sm text-gray-600">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}