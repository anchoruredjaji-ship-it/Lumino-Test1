import { Calendar, CheckCircle, Sun, Zap, Settings, LineChart, Shield, Wrench, Users, Award, QrCode } from 'lucide-react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { CoverPage } from './CoverPage';
import { IntroSection } from './IntroSection';
import { SystemSpecification } from './SystemSpecification';
import { FinancialSection } from './FinancialSection';
import { RealizationTimeline } from './RealizationTimeline';
import { ProductionAnalysis } from './ProductionAnalysis';
import { ROICalculation } from './ROICalculation';
import { ValidationProcess } from './ValidationProcess';
import { ClosingPage } from './ClosingPage';

interface ProposalAppProps {
  formData?: {
    godisnjaProizvodnja?: string;
    cenaKwh?: string;
    degradacijaNakon30?: string;
    cena?: string;
  };
}

export default function ProposalApp({ formData }: ProposalAppProps = { formData: {} }) {
  return (
    <div className="min-h-screen" style={{background: 'linear-gradient(180deg, #fafbfc 0%, #ffffff 50%, #f8fafc 100%)'}}>
      {/* Cover Page */}
      <CoverPage />
      
      {/* Intro Section */}
      <IntroSection />
      
      {/* System Specification */}
      <SystemSpecification />
      
      {/* Financial Section */}
      <FinancialSection />
      
      {/* Realization Timeline */}
      <RealizationTimeline />
      
      {/* Production Analysis */}
      <ProductionAnalysis />
      
      {/* ROI Calculation */}
      <ROICalculation 
        annualProduction={formData?.godisnjaProizvodnja}
        electricityPrice={formData?.cenaKwh}
        degradationAfter30={formData?.degradacijaNakon30}
        systemPrice={formData?.cena}
      />
      
      {/* Validation & Commissioning Process */}
      <ValidationProcess />
      
      {/* Closing Page */}
      <ClosingPage />
    </div>
  );
}