import React from 'react';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { Settings, Package, Wrench, CheckCircle, Clock } from 'lucide-react';

const iconMap = {
  Settings,
  Package,
  Wrench,
  CheckCircle
};

export function RealizationTimeline() {
  const timelineData = {
    phases: [
      { name: "Tehnička procena i projektovanje", duration: "7-10 dana", description: "Detaljna analiza lokacije i izrada tehničke dokumentacije", icon: "Settings" },
      { name: "Nabavka opreme", duration: "14-21 dan", description: "Nabavka i priprema sve potrebne opreme", icon: "Package" },
      { name: "Instalacija sistema", duration: "3-5 dana", description: "Profesionalna instalacija kompletnog solarnog sistema", icon: "Wrench" },
      { name: "Testiranje i puštanje u rad", duration: "1-2 dana", description: "Finalno testiranje i puštanje sistema u rad", icon: "CheckCircle" }
    ],
    totalDuration: "25-38 dana"
  };
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Timeline realizacije
          </h1>
          <p className="text-xl text-gray-600 mb-6">
            Transparentan pregled svih faza projekta
          </p>
          <Badge className="text-lg px-6 py-3 bg-gradient-to-r from-purple-600 to-teal-600 text-white">
            <Clock className="w-5 h-5 mr-2" />
            Ukupno vreme: {timelineData.totalDuration}
          </Badge>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-purple-400 to-teal-400 hidden md:block"></div>
          
          <div className="space-y-8">
            {timelineData.phases.map((phase, index) => {
              const IconComponent = iconMap[phase.icon as keyof typeof iconMap] || Settings;
              
              return (
                <div key={index} className="relative">
                  {/* Timeline dot */}
                  <div className="absolute left-6 w-4 h-4 bg-gradient-to-r from-purple-500 to-teal-500 rounded-full hidden md:block z-10"></div>
                  
                  <Card className="md:ml-16 shadow-lg hover:shadow-xl transition-shadow border-l-4 border-purple-400">
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-purple-100 to-teal-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <IconComponent className="w-6 h-6 text-purple-700" />
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-3">
                            <h3 className="text-xl font-semibold text-gray-900">
                              Faza {index + 1}: {phase.name}
                            </h3>
                            <Badge variant="outline" className="border-purple-300 text-purple-700">
                              {phase.duration}
                            </Badge>
                          </div>
                          
                          <p className="text-gray-600 leading-relaxed">
                            {phase.description}
                          </p>
                          
                          {/* Phase details based on type */}
                          <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                            {index === 0 && (
                              <>
                                <div className="text-sm bg-purple-50 p-3 rounded-lg">
                                  <div className="font-medium text-purple-800">Tehnički pregled</div>
                                  <div className="text-purple-600">Analiza lokacije i infrastrukture</div>
                                </div>
                                <div className="text-sm bg-purple-50 p-3 rounded-lg">
                                  <div className="font-medium text-purple-800">3D modeliranje</div>
                                  <div className="text-purple-600">Digitalni dizajn sistema</div>
                                </div>
                                <div className="text-sm bg-purple-50 p-3 rounded-lg">
                                  <div className="font-medium text-purple-800">Dozvole</div>
                                  <div className="text-purple-600">Priprema potrebnih dokumenata</div>
                                </div>
                              </>
                            )}
                            
                            {index === 1 && (
                              <>
                                <div className="text-sm bg-teal-50 p-3 rounded-lg">
                                  <div className="font-medium text-teal-800">Solarni paneli</div>
                                  <div className="text-teal-600">Premium kvalitet, 25 godina garancije</div>
                                </div>
                                <div className="text-sm bg-teal-50 p-3 rounded-lg">
                                  <div className="font-medium text-teal-800">Inverteri</div>
                                  <div className="text-teal-600">Najnovija tehnologija, 97% efikasnost</div>
                                </div>
                                <div className="text-sm bg-teal-50 p-3 rounded-lg">
                                  <div className="font-medium text-teal-800">Montaža</div>
                                  <div className="text-teal-600">Aluminijumski sistem, otporan na sve vremenske uslove</div>
                                </div>
                              </>
                            )}
                            
                            {index === 2 && (
                              <>
                                <div className="text-sm bg-blue-50 p-3 rounded-lg">
                                  <div className="font-medium text-blue-800">Profesionalni tim</div>
                                  <div className="text-blue-600">Sertifikovani instalacijski tehničari</div>
                                </div>
                                <div className="text-sm bg-blue-50 p-3 rounded-lg">
                                  <div className="font-medium text-blue-800">Bezbednost</div>
                                  <div className="text-blue-600">Sve mere zaštite na radu</div>
                                </div>
                                <div className="text-sm bg-blue-50 p-3 rounded-lg">
                                  <div className="font-medium text-blue-800">Čišća lokacija</div>
                                  <div className="text-blue-600">Kompletno uklanjanje građevinskog otpada</div>
                                </div>
                              </>
                            )}
                            
                            {index === 3 && (
                              <>
                                <div className="text-sm bg-green-50 p-3 rounded-lg">
                                  <div className="font-medium text-green-800">Testiranje</div>
                                  <div className="text-green-600">Sveobuhvatno funkcionalno testiranje</div>
                                </div>
                                <div className="text-sm bg-green-50 p-3 rounded-lg">
                                  <div className="font-medium text-green-800">Priključak</div>
                                  <div className="text-green-600">Zvanični priključak na mrežu</div>
                                </div>
                                <div className="text-sm bg-green-50 p-3 rounded-lg">
                                  <div className="font-medium text-green-800">Obuka</div>
                                  <div className="text-green-600">Detaljno uputstvo za korišćenje</div>
                                </div>
                              </>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              );
            })}
          </div>
        </div>

        {/* Summary Card */}
        <Card className="mt-16 bg-gradient-to-r from-green-50 to-blue-50 border-green-200">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              Sve je spremno za početak!
            </h3>
            <p className="text-lg text-gray-600 mb-6 max-w-2xl mx-auto">
              Naš iskusni tim će voditi projekat od početka do kraja, osiguravajući da sve bude 
              urađeno na vreme i sa najvišim standardima kvaliteta.
            </p>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-700">500+</div>
                <div className="text-gray-600">Uspešno završenih projekata</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-700">15</div>
                <div className="text-gray-600">Godina iskustva</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-purple-700">100%</div>
                <div className="text-gray-600">Zadovoljnih klijenata</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}