import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';

interface LuminoBrandIntroProps {
  onComplete: () => void;
}

export default function LuminoBrandIntro({ onComplete }: LuminoBrandIntroProps) {
  const [showContent, setShowContent] = useState(false);
  const [showSkip, setShowSkip] = useState(false);

  useEffect(() => {
    // Show content after initial delay
    const contentTimer = setTimeout(() => {
      setShowContent(true);
    }, 500);

    // Show skip button after 2 seconds
    const skipTimer = setTimeout(() => {
      setShowSkip(true);
    }, 2000);

    // Auto-advance after 4 seconds
    const autoTimer = setTimeout(() => {
      onComplete();
    }, 4000);

    return () => {
      clearTimeout(contentTimer);
      clearTimeout(skipTimer);
      clearTimeout(autoTimer);
    };
  }, [onComplete]);

  const handleClick = () => {
    onComplete();
  };

  return (
    <div 
      className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100 flex items-center justify-center relative cursor-pointer overflow-hidden"
      onClick={handleClick}
    >
      {/* Background animated elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {/* Floating gradients */}
        <motion.div
          className="absolute w-96 h-96 bg-gradient-to-r from-lumino-purple-start/20 to-lumino-turquoise/20 rounded-full blur-3xl"
          animate={{
            x: [0, 100, 0],
            y: [0, -50, 0],
            scale: [1, 1.2, 1],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          style={{ left: '10%', top: '10%' }}
        />
        <motion.div
          className="absolute w-80 h-80 bg-gradient-to-r from-lumino-turquoise/20 to-lumino-purple-end/20 rounded-full blur-3xl"
          animate={{
            x: [0, -80, 0],
            y: [0, 60, 0],
            scale: [1, 0.8, 1],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          style={{ right: '15%', bottom: '15%' }}
        />
        <motion.div
          className="absolute w-64 h-64 bg-gradient-to-r from-lumino-purple-end/15 to-lumino-turquoise/15 rounded-full blur-2xl"
          animate={{
            x: [0, 60, 0],
            y: [0, -40, 0],
            scale: [1, 1.3, 1],
          }}
          transition={{
            duration: 12,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          style={{ left: '60%', top: '60%' }}
        />
      </div>

      {/* Subtle grid pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: `radial-gradient(circle at 1px 1px, rgba(124, 58, 237, 0.3) 1px, transparent 0)`,
          backgroundSize: '40px 40px'
        }} />
      </div>

      {/* Main content */}
      <div className="relative z-10 text-center px-8">
        {showContent && (
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, ease: "easeOut" }}
            className="space-y-8"
          >
            {/* Logo container with luxury effects */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 1.2, ease: "easeOut", delay: 0.3 }}
              className="relative"
            >
              {/* Subtle glow behind logo */}
              <div className="absolute inset-0 bg-gradient-to-r from-lumino-purple-start/30 to-lumino-turquoise/30 blur-xl scale-110 rounded-full opacity-60" />
              
              {/* Logo */}
              <div className="relative bg-white/80 backdrop-blur-sm rounded-3xl p-12 shadow-2xl border border-white/20">
                <motion.div
                  className="h-32 w-auto mx-auto"
                  animate={{
                    filter: [
                      "drop-shadow(0 10px 25px rgba(124, 58, 237, 0.15))",
                      "drop-shadow(0 15px 35px rgba(28, 212, 212, 0.15))",
                      "drop-shadow(0 10px 25px rgba(124, 58, 237, 0.15))"
                    ]
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "easeInOut"
                  }}
                >
                  <svg 
                    width="128" 
                    height="86" 
                    viewBox="0 0 2345 1582" 
                    fill="none" 
                    xmlns="http://www.w3.org/2000/svg"
                    className="w-full h-full"
                  >
                    <path d="M1001.5 715H1014.5V858.25C1014.5 865.083 1016.17 869.833 1019.5 872.5C1023 875 1027.17 876.25 1032 876.25H1035.25V889.75H1030.75C1026.58 889.75 1022.67 889.167 1019 888C1015.5 886.667 1012.42 884.75 1009.75 882.25C1007.25 879.583 1005.25 876.167 1003.75 872C1002.25 867.833 1001.5 862.833 1001.5 857V715ZM1056.23 871.5C1054.23 867.333 1053.06 863.167 1052.73 859C1052.4 854.667 1052.23 850.25 1052.23 845.75V765H1065.23V853.5C1065.23 857.833 1065.81 861.667 1066.98 865C1068.31 868.167 1069.98 870.833 1071.98 873C1074.15 875.167 1076.56 876.833 1079.23 878C1081.9 879.167 1084.65 879.75 1087.48 879.75C1092.81 879.75 1098.15 878.833 1103.48 877C1108.98 875 1113.23 872.917 1116.23 870.75V765H1128.98V877.5L1134.48 882.75L1125.48 891.75L1117.98 884.25C1113.15 886.917 1107.98 888.833 1102.48 890C1096.98 891.333 1092.06 892 1087.73 892C1081.73 892 1075.81 890.5 1069.98 887.5C1064.15 884.333 1059.56 879 1056.23 871.5ZM1224.89 796C1224.89 793 1224.14 790.25 1222.64 787.75C1221.31 785.25 1219.39 783.083 1216.89 781.25C1214.56 779.417 1211.89 778 1208.89 777C1205.89 775.833 1202.89 775.25 1199.89 775.25C1198.39 775.25 1196.39 775.5 1193.89 776C1191.56 776.5 1189.14 777.167 1186.64 778C1184.14 778.833 1181.72 779.75 1179.39 780.75C1177.22 781.75 1175.39 782.833 1173.89 784V890H1161.14V777L1155.64 771.5L1164.64 762.75L1172.14 770.5C1176.47 768.167 1180.81 766.25 1185.14 764.75C1189.64 763.25 1193.97 762.5 1198.14 762.5C1205.64 762.5 1212.56 764.083 1218.89 767.25C1225.22 770.417 1229.64 775.333 1232.14 782C1234.47 778 1237.14 774.75 1240.14 772.25C1243.14 769.75 1246.22 767.833 1249.39 766.5C1252.72 765 1255.97 764 1259.14 763.5C1262.47 762.833 1265.64 762.5 1268.64 762.5C1274.64 762.5 1279.72 763.583 1283.89 765.75C1288.22 767.917 1291.72 770.75 1294.39 774.25C1297.06 777.583 1298.97 781.333 1300.14 785.5C1301.31 789.5 1301.89 793.5 1301.89 797.5V890H1288.89V799.25C1288.89 796.083 1288.47 793.083 1287.64 790.25C1286.97 787.417 1285.81 784.917 1284.14 782.75C1282.64 780.583 1280.47 778.833 1277.64 777.5C1274.97 776.167 1271.64 775.5 1267.64 775.5C1257.14 775.5 1249.56 778.5 1244.89 784.5C1240.22 790.333 1237.89 798.583 1237.89 809.25V890H1224.89V796ZM1333.25 715H1346.5V734.5H1333.25V715ZM1333.25 765H1346.5V890H1333.25V765ZM1451.42 783.25C1453.42 787.417 1454.58 791.667 1454.92 796C1455.25 800.167 1455.42 804.5 1455.42 809V890H1442.17V801.25C1442.17 792.75 1439.92 786.25 1435.42 781.75C1430.92 777.25 1425.83 775 1420.17 775C1417 775 1412.92 775.5 1407.92 776.5C1403.08 777.5 1397.58 780 1391.42 784V890H1378.67V777.25L1373.17 772L1382.17 763L1389.67 770.5C1398.83 765.333 1407.5 762.75 1415.67 762.75C1423.17 762.75 1430.17 764.333 1436.67 767.5C1443.17 770.5 1448.08 775.75 1451.42 783.25ZM1549.33 854V799.75C1549.33 794.25 1548.33 789.917 1546.33 786.75C1544.33 783.417 1541.91 780.917 1539.08 779.25C1536.41 777.417 1533.49 776.25 1530.33 775.75C1527.33 775.083 1524.74 774.75 1522.58 774.75C1520.41 774.75 1517.74 775.083 1514.58 775.75C1511.58 776.25 1508.66 777.417 1505.83 779.25C1502.99 780.917 1500.58 783.417 1498.58 786.75C1496.58 789.917 1495.58 794.25 1495.58 799.75V854C1495.58 859.5 1496.58 863.917 1498.58 867.25C1500.58 870.417 1502.99 872.917 1505.83 874.75C1508.66 876.583 1511.58 877.833 1514.58 878.5C1517.74 879 1520.41 879.25 1522.58 879.25C1524.74 879.25 1527.33 879 1530.33 878.5C1533.49 877.833 1536.41 876.583 1539.08 874.75C1541.91 872.917 1544.33 870.417 1546.33 867.25C1548.33 863.917 1549.33 859.5 1549.33 854ZM1560.83 855.75C1560.83 863.417 1559.41 869.583 1556.58 874.25C1553.74 878.917 1550.33 882.583 1546.33 885.25C1542.33 887.75 1538.16 889.417 1533.83 890.25C1529.49 891.083 1525.74 891.5 1522.58 891.5C1519.41 891.5 1515.66 891.083 1511.33 890.25C1506.99 889.417 1502.83 887.75 1498.83 885.25C1494.83 882.583 1491.41 878.917 1488.58 874.25C1485.74 869.583 1484.33 863.417 1484.33 855.75V798C1484.33 790.333 1485.74 784.167 1488.58 779.5C1491.41 774.833 1494.83 771.25 1498.83 768.75C1502.83 766.25 1506.99 764.583 1511.33 763.75C1515.66 762.917 1519.41 762.5 1522.58 762.5C1525.74 762.5 1529.49 762.917 1533.83 763.75C1538.16 764.583 1542.33 766.25 1546.33 768.75C1550.33 771.25 1553.74 774.833 1556.58 779.5C1559.41 784.167 1560.83 790.333 1560.83 798V855.75Z" fill="#46139A"/>
                    <g clipPath="url(#clip0_1_140)">
                      <path d="M1002.59 688.211C1005.83 688.487 1009.07 688.926 1012.3 689.521L1030.42 625.252C1033.09 615.76 1026.62 606.137 1016.82 605.043C1007.02 603.949 998.581 611.907 999.098 621.753L1002.59 688.211ZM880.409 667.389L929.015 711.155C931.635 708.991 934.351 706.965 937.158 705.089L905.031 647.709C900.211 639.107 888.829 636.877 881.125 643.038C873.42 649.193 873.084 660.789 880.409 667.389ZM924.357 592.221L968.912 690.958C970.246 690.621 971.586 690.309 972.933 690.026L962.47 582.069C961.28 569.788 949.357 561.505 937.434 564.679C925.511 567.853 919.285 580.969 924.363 592.221H924.357ZM1112.03 589.462C1101.35 583.277 1087.68 588.146 1083.32 599.693L1044.82 701.555C1044.82 701.555 1044.82 701.555 1044.82 701.555C1045.97 702.216 1047.08 702.902 1048.19 703.605L1117.44 619.463C1125.29 609.936 1122.71 595.648 1112.04 589.462H1112.03ZM909.111 733.305L826.45 665.237C816.925 657.392 802.64 659.971 796.456 670.647C790.272 681.322 795.14 695.003 806.684 699.367L906.671 737.176C907.458 735.86 908.276 734.567 909.117 733.305H909.111ZM943.42 877.941C943.227 877.833 943.035 877.731 942.849 877.617C941.521 876.847 940.217 876.048 938.936 875.224L872.212 956.294C864.37 965.822 866.948 980.11 877.621 986.295C888.3 992.48 901.972 987.611 906.335 976.064L943.426 877.935L943.42 877.941ZM828.739 783.605L892.537 780.257C892.861 776.734 893.36 773.218 894.057 769.72L832.237 752.282C822.748 749.607 813.126 756.087 812.033 765.885C810.939 775.682 818.896 784.128 828.739 783.611V783.605ZM894.207 810.047L789.064 820.242C776.787 821.432 768.506 833.358 771.679 845.284C774.852 857.209 787.964 863.437 799.214 858.357L895.349 814.958C894.929 813.329 894.55 811.688 894.213 810.041L894.207 810.047ZM854.689 877.701C846.089 882.521 843.859 893.906 850.019 901.612C856.173 909.318 867.765 909.655 874.364 902.328L916.419 855.604C914.027 852.797 911.797 849.882 909.748 846.864L854.695 877.707L854.689 877.701Z" fill="url(#paint0_linear_1_140)"/>
                    </g>
                    <defs>
                      <linearGradient id="paint0_linear_1_140" x1="1090.66" y1="843.574" x2="722.114" y2="630.075" gradientUnits="userSpaceOnUse">
                        <stop stopColor="#3AFFB8"/>
                        <stop offset="0.04" stopColor="#2CBFFE"/>
                        <stop offset="0.12" stopColor="#387DBC"/>
                        <stop offset="0.2" stopColor="#3EA6E1"/>
                        <stop offset="0.28" stopColor="#2280EF"/>
                        <stop offset="0.67" stopColor="#9548F8"/>
                        <stop offset="0.89" stopColor="#63369B"/>
                        <stop offset="1" stopColor="#3824B7"/>
                      </linearGradient>
                      <clipPath id="clip0_1_140">
                        <rect width="351" height="425" fill="white" transform="translate(771 564)"/>
                      </clipPath>
                    </defs>
                  </svg>
                </motion.div>
              </div>
            </motion.div>

            {/* Welcome text */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
              className="space-y-4"
            >
              <h1 className="text-3xl md:text-4xl font-light text-gray-800 tracking-wide">
                Dobrodošli u
              </h1>
              <div className="space-y-2">
                <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise bg-clip-text text-transparent">
                  LuminOne
                </h2>
                <p className="text-xl md:text-2xl font-light text-lumino-turquoise tracking-wide">
                  SOLARNI SISTEMI
                </p>
              </div>
            </motion.div>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 1.2 }}
              className="text-lg text-gray-600 max-w-md mx-auto leading-relaxed"
            >
              Profesionalni sistem za kreiranje ponuda i analizu solarnih projekata
            </motion.p>

            {/* Loading indicator */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 1.8 }}
              className="flex justify-center mt-12"
            >
              <div className="flex space-x-2">
                {[0, 1, 2].map((i) => (
                  <motion.div
                    key={i}
                    className="w-2 h-2 bg-gradient-to-r from-lumino-purple-start to-lumino-turquoise rounded-full"
                    animate={{
                      scale: [1, 1.5, 1],
                      opacity: [0.5, 1, 0.5]
                    }}
                    transition={{
                      duration: 1.5,
                      repeat: Infinity,
                      delay: i * 0.2,
                      ease: "easeInOut"
                    }}
                  />
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}

        {/* Skip button */}
        {showSkip && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="absolute bottom-8 right-8"
          >
            <button
              onClick={handleClick}
              className="text-gray-500 hover:text-gray-700 transition-colors duration-300 text-sm tracking-wide"
            >
              Kliknite bilo gde za nastavak
            </button>
          </motion.div>
        )}
      </div>

      {/* Subtle particles animation */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-lumino-turquoise/40 rounded-full"
            animate={{
              x: [
                Math.random() * window.innerWidth,
                Math.random() * window.innerWidth,
                Math.random() * window.innerWidth
              ],
              y: [
                Math.random() * window.innerHeight,
                Math.random() * window.innerHeight,
                Math.random() * window.innerHeight
              ],
              opacity: [0, 1, 0]
            }}
            transition={{
              duration: 8 + Math.random() * 4,
              repeat: Infinity,
              delay: Math.random() * 2,
              ease: "easeInOut"
            }}
          />
        ))}
      </div>
    </div>
  );
}