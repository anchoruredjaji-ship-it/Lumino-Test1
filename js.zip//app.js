// LuminOne Solar Project Quoting Application
// Vanilla JavaScript Implementation

class LuminOneApp {
    constructor() {
        // Application State
        this.state = {
            currentScreen: 'form', // 'form' | 'artikli'
            tipKupca: 'pravno',
            napomena: false,
            
            // Form Data
            formData: {
                nazivProjekta: '',
                snagaSistema: '138',
                datum: '',
                objekatLokacija: '',
                nazivKupca: '',
                adresaKupca: '',
                pib: '',
                mb: '',
                telefon: '',
                email: '',
                cena: '',
                cenaKwh: '',
                godisnjaProizvodnja: '',
                godisnjaUsteda: '',
                povratInvesticije: '',
                mesecnaProizvodnja: ''
            },

            // Stavke
            stavke: [
                { id: '1', tip: 'solarni-moduli', kolicina: '' },
                { id: '2', tip: 'inverter', kolicina: '' },
                { id: '3', tip: 'baterija', kolicina: '' },
                { id: '4', tip: 'ugradnja', kolicina: 'Da' },
                { id: '5', tip: 'eps', kolicina: 'Da' }
            ],

            // Krovovi
            krovovi: [
                { id: '1', brojModula: '', orijentacija: '', procenatNagiba: '' },
                { id: '2', brojModula: '', orijentacija: '', procenatNagiba: '' }
            ],

            // Uslovi Plaćanja
            usloviPlacanja: {
                prvi: '',
                drugi: '',
                treci: ''
            },

            // Artikli
            artikli: [
                { id: '1', naziv: 'Solarni panel 450W Monokristalin', opis: 'Visokoefikasni monokristalin panel sa 450W snage', garancija: '25 godina', tip: 'solarni-moduli' },
                { id: '2', naziv: 'Inverter Fronius Symo 10kW', opis: 'Trofazni string inverter za residential i commercial aplikacije', garancija: '5 godina', tip: 'inverter' },
                { id: '3', naziv: 'Litijum baterija 10kWh', opis: 'Visokokvalitetna LiFePO4 baterija za skladištenje energije', garancija: '10 godina', tip: 'baterija' },
                { id: '4', naziv: 'Kompletna ugradnja sistema', opis: 'Profesionalna ugradnja solarnog sistema sa svim potrebnim komponentama', garancija: '2 godine', tip: 'ugradnja' },
                { id: '5', naziv: 'Priključak na EPS mrežu', opis: 'Priključak solarnog sistema na elektroenergetsku mrežu', garancija: '1 godina', tip: 'eps' }
            ],

            // Artikal Dialog
            showArtikalDialog: false,
            editingArtikal: null,
            artikalForm: {
                naziv: '',
                opis: '',
                garancija: '',
                tip: 'solarni-moduli'
            }
        };

        this.init();
    }

    init() {
        this.render();
        this.bindEvents();
    }

    // State Management
    setState(updates) {
        Object.assign(this.state, updates);
        this.render();
    }

    updateFormData(field, value) {
        this.state.formData[field] = value;
        this.render();
    }

    updateUsloviPlacanja(field, value) {
        this.state.usloviPlacanja[field] = value;
        this.render();
    }

    // Stavke Management
    dodajStavku() {
        const newId = (this.state.stavke.length + 1).toString();
        this.state.stavke.push({ id: newId, tip: 'solarni-moduli', kolicina: '' });
        this.render();
    }

    ukloniStavku(id) {
        this.state.stavke = this.state.stavke.filter(stavka => stavka.id !== id);
        this.render();
    }

    updateStavka(id, field, value) {
        const stavka = this.state.stavke.find(s => s.id === id);
        if (stavka) {
            stavka[field] = value;
            this.render();
        }
    }

    // Krovovi Management
    dodajKrov() {
        const newId = (this.state.krovovi.length + 1).toString();
        this.state.krovovi.push({ id: newId, brojModula: '', orijentacija: '', procenatNagiba: '' });
        this.render();
    }

    ukloniKrov(id) {
        if (this.state.krovovi.length > 1) {
            this.state.krovovi = this.state.krovovi.filter(krov => krov.id !== id);
            this.render();
        }
    }

    updateKrov(id, field, value) {
        const krov = this.state.krovovi.find(k => k.id === id);
        if (krov) {
            krov[field] = value;
            this.render();
        }
    }

    // Artikli Management
    dodajArtikal() {
        if (this.state.editingArtikal) {
            const artikal = this.state.artikli.find(a => a.id === this.state.editingArtikal.id);
            if (artikal) {
                Object.assign(artikal, this.state.artikalForm);
            }
            this.state.editingArtikal = null;
        } else {
            const newArtikal = {
                id: (this.state.artikli.length + 1).toString(),
                ...this.state.artikalForm
            };
            this.state.artikli.push(newArtikal);
        }
        
        this.state.artikalForm = { naziv: '', opis: '', garancija: '', tip: 'solarni-moduli' };
        this.state.showArtikalDialog = false;
        this.render();
    }

    editArtikal(artikal) {
        this.state.editingArtikal = artikal;
        this.state.artikalForm = { ...artikal };
        this.state.showArtikalDialog = true;
        this.render();
    }

    ukloniArtikal(id) {
        this.state.artikli = this.state.artikli.filter(a => a.id !== id);
        this.render();
    }

    // Utility Functions
    getTipStavkeLabel(tip) {
        const labels = {
            'solarni-moduli': 'Solarni moduli',
            'inverter': 'Inverter',
            'baterija': 'Baterija',
            'ugradnja': 'Ugradnja',
            'eps': 'Priključak na EPS'
        };
        return labels[tip] || tip;
    }

    getArtikliByTip(tip) {
        return this.state.artikli.filter(a => a.tip === tip);
    }

    handleTipKupcaChange(value) {
        this.state.tipKupca = value;
        if (value === 'fizicko') {
            this.state.napomena = false;
        }
        this.render();
    }

    // Render Methods
    render() {
        const app = document.getElementById('app');
        
        if (this.state.currentScreen === 'form') {
            app.innerHTML = this.renderFormScreen();
        } else if (this.state.currentScreen === 'artikli') {
            app.innerHTML = this.renderArtikliScreen();
        }
        
        this.bindEvents();
    }

    renderFormScreen() {
        return `
            <div class="min-h-screen bg-gray-50">
                <!-- Header -->
                <header class="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div class="flex justify-between items-center h-16">
                            <div class="flex items-center">
                                <div class="h-8 w-32 bg-gradient-to-r from-purple-600 to-purple-800 rounded flex items-center justify-center text-white font-bold text-sm">
                                    LuminOne
                                </div>
                            </div>
                            <nav>
                                <a href="#" class="text-gray-600 hover:text-gray-900 transition-colors" aria-label="Pomoć i podrška">
                                    Pomoć
                                </a>
                            </nav>
                        </div>
                    </div>
                </header>

                <!-- Main Content -->
                <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-32">
                    <!-- Title Section -->
                    <div class="mb-8">
                        <h1 class="text-gray-900 mb-2">Unos podataka za ponudu</h1>
                        <p class="text-gray-600">
                            Popunite podatke o ponudi, kupcu i parametrima. Polja označena * su obavezna.
                        </p>
                    </div>

                    <!-- Form Grid -->
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <!-- Left Column -->
                        <div class="space-y-8">
                            ${this.renderZaglavljePonude()}
                            ${this.renderPodaciKupca()}
                            ${this.renderStavke()}
                        </div>

                        <!-- Right Column -->
                        <div class="space-y-8">
                            ${this.renderCenaUslovi()}
                            ${this.renderParametriLokacije()}
                            ${this.state.tipKupca === 'pravno' ? this.renderROIAnaliza() : ''}
                        </div>
                    </div>
                </main>

                <!-- Sticky Actions -->
                <div class="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-40">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
                        <div class="flex flex-col sm:flex-row gap-3 sm:justify-end">
                            <button class="btn-outline btn-lg border-purple-300 text-purple-700 hover:bg-purple-50 hover:border-purple-400" id="saveDraft">
                                Sačuvaj draft
                            </button>
                            <button class="btn-primary btn-lg bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white shadow-lg" id="generatePonuda">
                                <i data-lucide="file-text" class="h-4 w-4 mr-2"></i>
                                Generiraj ponudu
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderZaglavljePonude() {
        return `
            <div class="card shadow-sm">
                <div class="card-header">
                    <h3 class="card-title text-purple-700">Zaglavlje ponude</h3>
                </div>
                <div class="card-content space-y-4">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="label" for="nazivProjekta">Naziv projekta</label>
                            <input class="input" id="nazivProjekta" placeholder="Hotel Minerali" value="${this.state.formData.nazivProjekta}">
                        </div>
                        <div>
                            <label class="label" for="snagaSistema">Snaga sistema (kWp)</label>
                            <input class="input" id="snagaSistema" type="number" value="${this.state.formData.snagaSistema}">
                        </div>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="label" for="datum">Datum</label>
                            <input class="input" id="datum" type="date" value="${this.state.formData.datum}">
                        </div>
                        <div>
                            <label class="label" for="objekatLokacija">Objekat / Lokacija</label>
                            <input class="input" id="objekatLokacija" value="${this.state.formData.objekatLokacija}">
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderPodaciKupca() {
        return `
            <div class="card shadow-sm">
                <div class="card-header">
                    <h3 class="card-title text-purple-700">Podaci o kupcu</h3>
                </div>
                <div class="card-content space-y-4">
                    <div>
                        <label class="label">Tip kupca</label>
                        <div class="flex gap-6 mt-2">
                            <div class="flex items-center space-x-2">
                                <input type="radio" id="pravno" name="tipKupca" value="pravno" ${this.state.tipKupca === 'pravno' ? 'checked' : ''} class="radio">
                                <label for="pravno">Pravno lice</label>
                            </div>
                            <div class="flex items-center space-x-2">
                                <input type="radio" id="fizicko" name="tipKupca" value="fizicko" ${this.state.tipKupca === 'fizicko' ? 'checked' : ''} class="radio">
                                <label for="fizicko">Fizičko lice</label>
                            </div>
                        </div>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="label" for="nazivKupca">Naziv kupca *</label>
                            <input class="input" id="nazivKupca" required value="${this.state.formData.nazivKupca}">
                        </div>
                        <div>
                            <label class="label" for="adresaKupca">Adresa kupca *</label>
                            <input class="input" id="adresaKupca" required value="${this.state.formData.adresaKupca}">
                        </div>
                    </div>
                    ${this.state.tipKupca === 'pravno' ? `
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="label" for="pib">PIB</label>
                                <input class="input" id="pib" value="${this.state.formData.pib}">
                            </div>
                            <div>
                                <label class="label" for="mb">MB</label>
                                <input class="input" id="mb" value="${this.state.formData.mb}">
                            </div>
                        </div>
                    ` : ''}
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="label" for="telefon">Telefon</label>
                            <input class="input" id="telefon" type="tel" value="${this.state.formData.telefon}">
                        </div>
                        <div>
                            <label class="label" for="email">Email</label>
                            <input class="input" id="email" type="email" value="${this.state.formData.email}">
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderStavke() {
        return `
            <div class="card shadow-sm">
                <div class="card-header">
                    <div class="flex justify-between items-center">
                        <h3 class="card-title text-purple-700">Stavke (Artikli / Oprema)</h3>
                        <button class="btn-outline border-purple-300 text-purple-700 hover:bg-purple-50 hover:border-purple-400" id="upravljajArtiklima">
                            <i data-lucide="package" class="h-4 w-4 mr-2"></i>
                            Upravljaj artiklima
                        </button>
                    </div>
                </div>
                <div class="card-content space-y-4">
                    ${this.state.stavke.map((stavka, index) => this.renderStavka(stavka, index)).join('')}
                    <button class="btn-outline w-full border-dashed border-2 hover:border-purple-300 hover:bg-purple-50" id="dodajStavku">
                        <i data-lucide="plus" class="h-4 w-4 mr-2"></i>
                        Dodaj stavku
                    </button>
                </div>
            </div>
        `;
    }

    renderStavka(stavka, index) {
        return `
            <div class="flex items-end gap-4 p-4 bg-gray-50 rounded-lg">
                <div class="flex-1">
                    <label class="label" for="stavka-tip-${stavka.id}">Tip stavke</label>
                    <select class="select" id="stavka-tip-${stavka.id}" data-stavka-id="${stavka.id}" data-field="tip">
                        ${this.renderStavkaOptions(stavka.tip)}
                    </select>
                </div>
                <div class="flex-1">
                    <label class="label" for="stavka-kolicina-${stavka.id}">
                        ${stavka.tip === 'ugradnja' || stavka.tip === 'eps' ? 'Uključeno' : 'Količina'}
                    </label>
                    ${stavka.tip === 'ugradnja' || stavka.tip === 'eps' ? `
                        <div class="flex items-center space-x-2 h-10">
                            <input type="checkbox" class="switch" id="stavka-kolicina-${stavka.id}" ${stavka.kolicina === 'Da' ? 'checked' : ''} data-stavka-id="${stavka.id}" data-field="kolicina">
                            <label for="stavka-kolicina-${stavka.id}" class="text-sm">
                                ${stavka.kolicina === 'Da' ? 'Da' : 'Ne'}
                            </label>
                        </div>
                    ` : `
                        <input class="input" id="stavka-kolicina-${stavka.id}" type="number" value="${stavka.kolicina}" data-stavka-id="${stavka.id}" data-field="kolicina">
                    `}
                </div>
                ${index >= 5 ? `
                    <button class="btn-outline btn-icon text-red-600 hover:text-red-700" data-remove-stavka="${stavka.id}" aria-label="Ukloni stavku">
                        <i data-lucide="trash-2" class="h-4 w-4"></i>
                    </button>
                ` : ''}
            </div>
        `;
    }

    renderStavkaOptions(selectedValue) {
        let options = '';
        
        // Group by tip
        const tipovi = ['solarni-moduli', 'inverter', 'baterija', 'ugradnja', 'eps'];
        
        tipovi.forEach(tip => {
            const artikliByTip = this.getArtikliByTip(tip);
            if (artikliByTip.length > 0) {
                options += `<optgroup label="${this.getTipStavkeLabel(tip)}">`;
                artikliByTip.forEach(artikal => {
                    const value = `artikal-${artikal.id}`;
                    const selected = selectedValue === value ? 'selected' : '';
                    options += `<option value="${value}" ${selected}>${artikal.naziv}</option>`;
                });
                options += `</optgroup>`;
            }
        });
        
        return options;
    }

    renderCenaUslovi() {
        return `
            <div class="card shadow-sm">
                <div class="card-header">
                    <h3 class="card-title text-purple-700">Cena i uslovi</h3>
                </div>
                <div class="card-content space-y-4">
                    <div>
                        <label class="label" for="cena">Cena (EUR)</label>
                        <input class="input" id="cena" type="number" step="0.01" value="${this.state.formData.cena}">
                    </div>
                    <div class="space-y-3">
                        <label class="label">Uslovi plaćanja</label>
                        <div class="space-y-2">
                            <input class="input" placeholder="npr. 50% avans" value="${this.state.usloviPlacanja.prvi}" id="uslov1">
                            <input class="input" placeholder="npr. 50% nakon isporuke" value="${this.state.usloviPlacanja.drugi}" id="uslov2">
                            <input class="input" placeholder="npr. 10% račun puštenje" value="${this.state.usloviPlacanja.treci}" id="uslov3">
                        </div>
                    </div>
                    <div class="space-y-3">
                        <div class="flex items-center space-x-2">
                            <input type="checkbox" class="switch" id="napomena" ${this.state.napomena ? 'checked' : ''} ${this.state.tipKupca === 'fizicko' ? 'disabled' : ''}>
                            <label for="napomena" class="${this.state.tipKupca === 'fizicko' ? 'text-muted-foreground' : ''}">
                                Napomena (Član 10)
                                ${this.state.tipKupca === 'fizicko' ? '<span class="text-xs ml-2">(Ne primenjuje se na fizička lica)</span>' : ''}
                            </label>
                        </div>
                        ${this.state.napomena && this.state.tipKupca === 'pravno' ? `
                            <textarea class="textarea mt-2" placeholder="Član 10 se primenjuje">Član 10 se primenjuje</textarea>
                        ` : ''}
                    </div>
                </div>
            </div>
        `;
    }

    renderParametriLokacije() {
        return `
            <div class="card shadow-sm">
                <div class="card-header">
                    <h3 class="card-title text-purple-700">Parametri lokacije / Proračun</h3>
                </div>
                <div class="card-content space-y-4">
                    ${this.state.krovovi.map((krov, index) => this.renderKrov(krov, index)).join('')}
                    <button class="btn-outline w-full border-dashed border-2 hover:border-purple-300 hover:bg-purple-50" id="dodajKrov">
                        <i data-lucide="plus" class="h-4 w-4 mr-2"></i>
                        Dodaj krov
                    </button>
                    <div class="pt-4 border-t">
                        <div>
                            <label class="label" for="cenaKwh">Cena kWh</label>
                            <input class="input" id="cenaKwh" type="number" step="0.01" value="${this.state.formData.cenaKwh}" placeholder="npr. 0.07">
                        </div>
                    </div>
                    
                    <!-- Mesečna proizvodnja -->
                    <div class="pt-4 border-t">
                        <div class="space-y-3">
                            <label class="label" for="mesecnaProizvodnja">Mesečna proizvodnja (kWh)</label>
                            <p class="text-sm text-gray-600">
                                Unesite proizvodnju za svaki mesec (Jan-Dec), jedan broj po liniji:
                            </p>
                            <textarea class="textarea min-h-[200px] font-mono text-sm" id="mesecnaProizvodnja" placeholder="1,684&#10;2,527&#10;4,527&#10;6,052&#10;7,016&#10;7,685&#10;7,766&#10;6,807&#10;4,966&#10;3,503&#10;2,054&#10;1,284">${this.state.formData.mesecnaProizvodnja}</textarea>
                            <p class="text-xs text-gray-500">
                                Tip: Možete kopirati podatke iz Excel-a ili bilo kog izvora i nalepiti ovde
                            </p>
                        </div>
                    </div>

                    <!-- Godišnja ušteda CO₂ -->
                    <div class="pt-4 border-t">
                        <div>
                            <label class="label" for="godisnjaUsteda">Godišnja ušteda CO₂ (t)</label>
                            <input class="input" id="godisnjaUsteda" type="number" step="0.01" value="${this.state.formData.godisnjaUsteda}">
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    renderKrov(krov, index) {
        return `
            <div class="p-4 bg-gray-50 rounded-lg">
                <div class="flex items-center justify-between mb-3">
                    <h4 class="font-medium">Krov ${index + 1}</h4>
                    ${this.state.krovovi.length > 1 ? `
                        <button class="btn-outline btn-sm text-red-600 hover:text-red-700" data-remove-krov="${krov.id}">
                            <i data-lucide="trash-2" class="h-4 w-4"></i>
                        </button>
                    ` : ''}
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div>
                        <label class="label" for="krov-moduli-${krov.id}">Broj modula</label>
                        <input class="input" id="krov-moduli-${krov.id}" type="number" value="${krov.brojModula}" data-krov-id="${krov.id}" data-field="brojModula">
                    </div>
                    <div>
                        <label class="label" for="krov-orijentacija-${krov.id}">Orijentacija</label>
                        <select class="select" id="krov-orijentacija-${krov.id}" data-krov-id="${krov.id}" data-field="orijentacija">
                            <option value="">Odaberite orijentaciju</option>
                            <option value="jug" ${krov.orijentacija === 'jug' ? 'selected' : ''}>Jug</option>
                            <option value="jugoistok" ${krov.orijentacija === 'jugoistok' ? 'selected' : ''}>Jugoistok</option>
                            <option value="jugozapad" ${krov.orijentacija === 'jugozapad' ? 'selected' : ''}>Jugozapad</option>
                            <option value="istok" ${krov.orijentacija === 'istok' ? 'selected' : ''}>Istok</option>
                            <option value="zapad" ${krov.orijentacija === 'zapad' ? 'selected' : ''}>Zapad</option>
                            <option value="sever" ${krov.orijentacija === 'sever' ? 'selected' : ''}>Sever</option>
                        </select>
                    </div>
                    <div>
                        <label class="label" for="krov-nagib-${krov.id}">Procenat nagiba (%)</label>
                        <input class="input" id="krov-nagib-${krov.id}" type="number" step="0.1" value="${krov.procenatNagiba}" placeholder="npr. 35" data-krov-id="${krov.id}" data-field="procenatNagiba">
                    </div>
                </div>
            </div>
        `;
    }

    renderROIAnaliza() {
        return `
            <div class="card shadow-sm">
                <div class="card-header">
                    <h3 class="card-title text-purple-700">ROI Analiza</h3>
                </div>
                <div class="card-content space-y-4">
                    <div>
                        <label class="label" for="godisnjaProizvodnja">Godišnja proizvodnja (kWh)</label>
                        <input class="input" id="godisnjaProizvodnja" type="number" value="${this.state.formData.godisnjaProizvodnja}">
                    </div>
                    <div>
                        <label class="label" for="povratInvesticije">Povrat investicije</label>
                        <input class="input" id="povratInvesticije" placeholder="npr. 2 godine i 5 meseci" value="${this.state.formData.povratInvesticije}">
                    </div>
                </div>
            </div>
        `;
    }

    renderArtikliScreen() {
        return `
            <div class="min-h-screen bg-gray-50">
                <!-- Header -->
                <header class="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                        <div class="flex justify-between items-center h-16">
                            <div class="flex items-center gap-4">
                                <div class="h-8 w-32 bg-gradient-to-r from-purple-600 to-purple-800 rounded flex items-center justify-center text-white font-bold text-sm">
                                    LuminOne
                                </div>
                                <button class="btn-ghost flex items-center gap-2 text-gray-600 hover:text-gray-900" id="backToForm">
                                    <i data-lucide="arrow-left" class="h-4 w-4"></i>
                                    Nazad na formu
                                </button>
                            </div>
                            <nav>
                                <a href="#" class="text-gray-600 hover:text-gray-900 transition-colors" aria-label="Pomoć i podrška">
                                    Pomoć
                                </a>
                            </nav>
                        </div>
                    </div>
                </header>

                <!-- Artikli Content -->
                <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                    <div class="mb-8">
                        <h1 class="text-gray-900 mb-2">Upravljanje artiklima</h1>
                        <p class="text-gray-600">
                            Dodajte i upravljajte artiklima koji će biti dostupni za stavke u ponudama.
                        </p>
                    </div>

                    <div class="card shadow-sm">
                        <div class="card-header">
                            <div class="flex justify-between items-center">
                                <h3 class="card-title text-purple-700">Artikli</h3>
                                <button class="btn-primary bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white" id="dodajArtikalBtn">
                                    <i data-lucide="plus" class="h-4 w-4 mr-2"></i>
                                    Dodaj artikal
                                </button>
                            </div>
                        </div>
                        <div class="card-content">
                            ${this.renderArtikliTable()}
                        </div>
                    </div>
                </main>

                <!-- Artikal Dialog -->
                ${this.state.showArtikalDialog ? this.renderArtikalDialog() : ''}
            </div>
        `;
    }

    renderArtikliTable() {
        if (this.state.artikli.length === 0) {
            return `
                <div class="text-center py-8 text-gray-500">
                    <i data-lucide="package" class="h-12 w-12 mx-auto mb-4 text-gray-400"></i>
                    <p>Nema dodanih artikala</p>
                    <p class="text-sm">Dodajte prvi artikal da biste počeli</p>
                </div>
            `;
        }

        return `
            <table class="table">
                <thead>
                    <tr>
                        <th>Naziv</th>
                        <th>Opis</th>
                        <th>Garancija</th>
                        <th>Tip</th>
                        <th>Akcije</th>
                    </tr>
                </thead>
                <tbody>
                    ${this.state.artikli.map(artikal => `
                        <tr>
                            <td class="font-medium">${artikal.naziv}</td>
                            <td class="max-w-md">
                                <div class="truncate" title="${artikal.opis}">
                                    ${artikal.opis}
                                </div>
                            </td>
                            <td>${artikal.garancija}</td>
                            <td>
                                <span class="badge badge-outline text-purple-700 border-purple-300">
                                    ${this.getTipStavkeLabel(artikal.tip)}
                                </span>
                            </td>
                            <td>
                                <div class="flex gap-2">
                                    <button class="btn-ghost btn-icon h-8 w-8 text-blue-600 hover:text-blue-700 hover:bg-blue-50" data-edit-artikal="${artikal.id}">
                                        <i data-lucide="edit" class="h-4 w-4"></i>
                                    </button>
                                    <button class="btn-ghost btn-icon h-8 w-8 text-red-600 hover:text-red-700 hover:bg-red-50" data-remove-artikal="${artikal.id}">
                                        <i data-lucide="trash-2" class="h-4 w-4"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }

    renderArtikalDialog() {
        return `
            <div class="dialog-overlay" id="artikalDialog">
                <div class="dialog-content sm:max-w-md">
                    <div class="dialog-header">
                        <h3 class="dialog-title">
                            ${this.state.editingArtikal ? 'Izmeni artikal' : 'Dodaj novi artikal'}
                        </h3>
                    </div>
                    <div class="space-y-4">
                        <div>
                            <label class="label" for="artikal-naziv">Naziv artikla</label>
                            <input class="input" id="artikal-naziv" value="${this.state.artikalForm.naziv}" placeholder="Unesite naziv artikla">
                        </div>
                        <div>
                            <label class="label" for="artikal-opis">Opis artikla</label>
                            <textarea class="textarea min-h-[80px]" id="artikal-opis" placeholder="Unesite opis artikla">${this.state.artikalForm.opis}</textarea>
                        </div>
                        <div>
                            <label class="label" for="artikal-garancija">Garancija</label>
                            <input class="input" id="artikal-garancija" value="${this.state.artikalForm.garancija}" placeholder="npr. 25 godina, 5 godina">
                        </div>
                        <div>
                            <label class="label" for="artikal-tip">Tip artikla</label>
                            <select class="select" id="artikal-tip">
                                <option value="solarni-moduli" ${this.state.artikalForm.tip === 'solarni-moduli' ? 'selected' : ''}>Solarni moduli</option>
                                <option value="inverter" ${this.state.artikalForm.tip === 'inverter' ? 'selected' : ''}>Inverter</option>
                                <option value="baterija" ${this.state.artikalForm.tip === 'baterija' ? 'selected' : ''}>Baterija</option>
                                <option value="ugradnja" ${this.state.artikalForm.tip === 'ugradnja' ? 'selected' : ''}>Ugradnja</option>
                                <option value="eps" ${this.state.artikalForm.tip === 'eps' ? 'selected' : ''}>Priključak na EPS</option>
                            </select>
                        </div>
                        <div class="flex gap-3">
                            <button class="btn-outline flex-1" id="cancelArtikal">
                                Otkaži
                            </button>
                            <button class="btn-primary flex-1 bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900 text-white" id="saveArtikal">
                                ${this.state.editingArtikal ? 'Sačuvaj' : 'Dodaj'}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    // Event Binding
    bindEvents() {
        // Initialize Lucide icons
        if (typeof lucide !== 'undefined') {
            lucide.createIcons();
        }

        // Form Screen Events
        if (this.state.currentScreen === 'form') {
            this.bindFormEvents();
        } else if (this.state.currentScreen === 'artikli') {
            this.bindArtikliEvents();
        }
    }

    bindFormEvents() {
        // Header inputs
        const inputs = ['nazivProjekta', 'snagaSistema', 'datum', 'objekatLokacija', 
                       'nazivKupca', 'adresaKupca', 'pib', 'mb', 'telefon', 'email',
                       'cena', 'cenaKwh', 'godisnjaProizvodnja', 'godisnjaUsteda', 'povratInvesticije', 'mesecnaProizvodnja'];
        
        inputs.forEach(inputId => {
            const input = document.getElementById(inputId);
            if (input) {
                input.addEventListener('input', (e) => {
                    this.updateFormData(inputId, e.target.value);
                });
            }
        });

        // Tip kupca radio buttons
        const tipKupcaInputs = document.querySelectorAll('input[name="tipKupca"]');
        tipKupcaInputs.forEach(input => {
            input.addEventListener('change', (e) => {
                this.handleTipKupcaChange(e.target.value);
            });
        });

        // Uslovi placanja
        const uslov1 = document.getElementById('uslov1');
        const uslov2 = document.getElementById('uslov2');
        const uslov3 = document.getElementById('uslov3');
        
        if (uslov1) uslov1.addEventListener('input', (e) => this.updateUsloviPlacanja('prvi', e.target.value));
        if (uslov2) uslov2.addEventListener('input', (e) => this.updateUsloviPlacanja('drugi', e.target.value));
        if (uslov3) uslov3.addEventListener('input', (e) => this.updateUsloviPlacanja('treci', e.target.value));

        // Napomena switch
        const napomenaSwitch = document.getElementById('napomena');
        if (napomenaSwitch) {
            napomenaSwitch.addEventListener('change', (e) => {
                this.state.napomena = e.target.checked;
                this.render();
            });
        }

        // Stavke events
        document.addEventListener('click', (e) => {
            if (e.target.id === 'dodajStavku') {
                e.preventDefault();
                this.dodajStavku();
            }
            if (e.target.closest('[data-remove-stavka]')) {
                e.preventDefault();
                const id = e.target.closest('[data-remove-stavka]').dataset.removeStavka;
                this.ukloniStavku(id);
            }
        });

        // Stavke input events
        document.addEventListener('change', (e) => {
            if (e.target.dataset.stavkaId && e.target.dataset.field) {
                const id = e.target.dataset.stavkaId;
                const field = e.target.dataset.field;
                let value = e.target.value;
                
                if (e.target.type === 'checkbox') {
                    value = e.target.checked ? 'Da' : 'Ne';
                }
                
                this.updateStavka(id, field, value);
            }
        });

        // Krov events
        document.addEventListener('click', (e) => {
            if (e.target.id === 'dodajKrov') {
                e.preventDefault();
                this.dodajKrov();
            }
            if (e.target.closest('[data-remove-krov]')) {
                e.preventDefault();
                const id = e.target.closest('[data-remove-krov]').dataset.removeKrov;
                this.ukloniKrov(id);
            }
        });

        // Krov input events
        document.addEventListener('change', (e) => {
            if (e.target.dataset.krovId && e.target.dataset.field) {
                const id = e.target.dataset.krovId;
                const field = e.target.dataset.field;
                const value = e.target.value;
                this.updateKrov(id, field, value);
            }
        });

        // Action buttons
        const upravljajBtn = document.getElementById('upravljajArtiklima');
        if (upravljajBtn) {
            upravljajBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.setState({ currentScreen: 'artikli' });
            });
        }

        const generateBtn = document.getElementById('generatePonuda');
        if (generateBtn) {
            generateBtn.addEventListener('click', (e) => {
                e.preventDefault();
                alert('PDF generisanje će biti dodano kasnije!');
            });
        }

        const saveDraftBtn = document.getElementById('saveData');
        if (saveDraftBtn) {
            saveDraftBtn.addEventListener('click', (e) => {
                e.preventDefault();
                alert('Draft je sačuvan!');
            });
        }
    }

    bindArtikliEvents() {
        // Back to form
        const backBtn = document.getElementById('backToForm');
        if (backBtn) {
            backBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.setState({ currentScreen: 'form' });
            });
        }

        // Add artikal button
        const dodajBtn = document.getElementById('dodajArtikalBtn');
        if (dodajBtn) {
            dodajBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.state.editingArtikal = null;
                this.state.artikalForm = { naziv: '', opis: '', garancija: '', tip: 'solarni-moduli' };
                this.state.showArtikalDialog = true;
                this.render();
            });
        }

        // Edit/Remove artikal buttons
        document.addEventListener('click', (e) => {
            if (e.target.closest('[data-edit-artikal]')) {
                e.preventDefault();
                const id = e.target.closest('[data-edit-artikal]').dataset.editArtikal;
                const artikal = this.state.artikli.find(a => a.id === id);
                if (artikal) {
                    this.editArtikal(artikal);
                }
            }
            
            if (e.target.closest('[data-remove-artikal]')) {
                e.preventDefault();
                const id = e.target.closest('[data-remove-artikal]').dataset.removeArtikal;
                this.ukloniArtikal(id);
            }
        });

        // Dialog events
        if (this.state.showArtikalDialog) {
            this.bindArtikalDialogEvents();
        }
    }

    bindArtikalDialogEvents() {
        // Form inputs
        const nazivInput = document.getElementById('artikal-naziv');
        const opisInput = document.getElementById('artikal-opis');
        const garancijaInput = document.getElementById('artikal-garancija');
        const tipSelect = document.getElementById('artikal-tip');

        if (nazivInput) {
            nazivInput.addEventListener('input', (e) => {
                this.state.artikalForm.naziv = e.target.value;
            });
        }

        if (opisInput) {
            opisInput.addEventListener('input', (e) => {
                this.state.artikalForm.opis = e.target.value;
            });
        }

        if (garancijaInput) {
            garancijaInput.addEventListener('input', (e) => {
                this.state.artikalForm.garancija = e.target.value;
            });
        }

        if (tipSelect) {
            tipSelect.addEventListener('change', (e) => {
                this.state.artikalForm.tip = e.target.value;
            });
        }

        // Cancel button
        const cancelBtn = document.getElementById('cancelArtikal');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', (e) => {
                e.preventDefault();
                this.state.showArtikalDialog = false;
                this.state.editingArtikal = null;
                this.state.artikalForm = { naziv: '', opis: '', garancija: '', tip: 'solarni-moduli' };
                this.render();
            });
        }

        // Save button
        const saveBtn = document.getElementById('saveArtikal');
        if (saveBtn) {
            saveBtn.addEventListener('click', (e) => {
                e.preventDefault();
                if (this.state.artikalForm.naziv && this.state.artikalForm.opis && this.state.artikalForm.garancija) {
                    this.dodajArtikal();
                }
            });
        }

        // Close on overlay click
        const dialog = document.getElementById('artikalDialog');
        if (dialog) {
            dialog.addEventListener('click', (e) => {
                if (e.target === dialog) {
                    this.state.showArtikalDialog = false;
                    this.state.editingArtikal = null;
                    this.state.artikalForm = { naziv: '', opis: '', garancija: '', tip: 'solarni-moduli' };
                    this.render();
                }
            });
        }
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new LuminOneApp();
});