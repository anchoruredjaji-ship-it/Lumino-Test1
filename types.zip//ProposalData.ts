export interface ProposalData {
  client: {
    name: string;
    address: string;
    city: string;
    email?: string;
    phone?: string;
  };
  
  system: {
    totalPower: number;
    panelCount: number;
    panelType: string;
    panelPower: number;
    inverterType: string;
    inverterCount: number;
    inverterPower: number;
    rackingSystem: string;
    warranty: string;
  };
  
  financial: {
    totalPrice: number;
    pricePerKw: number;
    paymentOptions: string[];
  };
  
  location: {
    address: string;
    city: string;
    orientation: string;
    tilt: number;
    performanceRatio: number;
    degradationAfter30Years: number; // Procenat degradacije nakon 30 godina
  };
  
  production: {
    monthlyProduction: Array<{
      month: string;
      production: number;
    }>;
    annualProduction: number;
    co2Reduction: number;
  };
  
  timeline: {
    phases: Array<{
      name: string;
      duration: string;
      description: string;
      icon: string;
    }>;
    totalDuration: string;
  };
  
  roi: {
    paybackPeriod: string;
    firstYearSavings: number;
    annualSavings: number;
    twentyFiveYearSavings: number;
    electricityPrice: number;
    degradationAfter30Years: number; // Procenat degradacije nakon 30 godina za kalkulacije
    lifetimeSavingsWithDegradation: number; // Ukupne uštede sa uključenom degradacijom
  };
  
  company: {
    name: string;
    address: string;
    city: string;
    phone: string;
    email: string;
    website: string;
  };
  
  projectDate: string;
  validUntil: string;
}