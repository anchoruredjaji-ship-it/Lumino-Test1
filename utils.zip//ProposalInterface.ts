// Global interface for proposal data integration
declare global {
  interface Window {
    proposalData?: any;
    LuminoProposalGenerator?: {
      generate: (data: any) => void;
    };
  }
}

export {};