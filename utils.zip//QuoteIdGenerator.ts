// Quote ID generator utility

export function generateQuoteId(customDate?: string): string {
  const date = customDate ? new Date(customDate) : new Date();
  
  // Format date as YYYYMMDD
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  const dateString = `${year}${month}${day}`;
  
  // Generate a random 3-digit number for uniqueness
  const randomNumber = Math.floor(Math.random() * 900) + 100; // 100-999
  
  return `${dateString}-${randomNumber}`;
}

export function formatQuoteTitle(customDate?: string): string {
  const quoteId = generateQuoteId(customDate);
  
  // Add visual separator between "Ponuda" and "LUM" for better readability
  return `Ponuda • LUM-${quoteId}`;
}

export function formatQuoteCode(customDate?: string): string {
  const quoteId = generateQuoteId(customDate);
  return `LUM-${quoteId}`;
}